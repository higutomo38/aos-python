# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula


import json

from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector


class RouteCountCollector(BaseTelemetryCollector):
    """
    Returns number of routes for all networks contextualized by VRFs.
    """
    def collect(self):
        networks = self.service_config.input.split(
            ',') if self.service_config.input else ['0.0.0.0/0']

        def get_items(network_addr):
            info = self.device.get_json('show ip route vrf all %s' % network_addr)
            for vrf, vrf_info in info['vrfs'].iteritems():
                for dst_network, route_data in vrf_info['routes'].iteritems():
                    if route_data['routeType'] == 'connected':
                        continue

                    yield (
                        str(vrf) + "|" + str(dst_network),
                        str(sum(
                            1 for r in route_data['vias']
                            if r.get('nexthopAddr') is not None
                        )),
                    )

        self.post_data(json.dumps({
            'items': [
                dict(identity=key, value=value)
                for key, value in {
                    key: value
                    for network_addr in networks
                    for key, value in get_items(network_addr)
                }.iteritems()
            ]
        }))


def collector_plugin(_device):
    return RouteCountCollector
