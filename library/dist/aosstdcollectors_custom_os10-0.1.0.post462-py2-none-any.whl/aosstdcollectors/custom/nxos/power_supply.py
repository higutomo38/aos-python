# Copyright 2019-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

import logging
import json
from collections import namedtuple
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.data_util import to_extensible_postdata

LOGGER = logging.getLogger(__name__)


TABLE_PSINFO = 'TABLE_psinfo'
ROW_PSINFO = 'ROW_psinfo'
TABLE_FANINFO = 'TABLE_faninfo'
ROW_FANINFO = 'ROW_faninfo'
POWERSUP = 'powersup'
FANDETAILS = 'fandetails'


class PowerSupplyCollector(BaseTelemetryCollector):
    def _get_power_supply_status(self, ps_info):
        for ps in ps_info.supply:
            ps_status = ps['ps_status'].lower()
            if ps_status != 'ok':
                return 2
        return 1

    def _get_fan_status(self, ps_info):
        for fan in ps_info.fan:
            if fan['fanname'].strip().startswith('Fan_in_PS'):
                fan_status = fan['fanstatus'].lower()
                if fan_status != 'ok':
                    return 2
        return 1

    def _get_power_supply_count(self, ps_info):
        # We should skip `absent` supplies
        ps_count = 0
        for ps in ps_info.supply:
            ps_status = ps['ps_status'].lower()
            if ps_status != 'absent':
                ps_count += 1
        return ps_count

    def _get_ps_info(self, ps_info):
        # nxos doesn't not provide uptime, odm_manufacturer or
        # temp_sensors info
        fan_data_by_name = {
            fan['fanname']: fan
            for fan in ps_info.fan
        }

        def get_ps_fan_status_or_warn(fan_status):
            if not fan_status:
                LOGGER.warn('cannot get fanstatus')
            return fan_status

        def get_airflow(fandir):
            if not fandir:
                LOGGER.warn('cannot get airflow')
            if fandir == 'front-to-back':
                return 'F'
            return 'R'

        def get_fan_data_by_ps(psnum):
            return fan_data_by_name.get('Fan_in_PS{}'.format(psnum), {})

        return {
            ps['psnum']: {
                'status': ps['ps_status'],
                'airflow': get_airflow(
                    get_fan_data_by_ps(ps['psnum']).get('fandir')),
                'input_power': ps['actual_input'].strip(),
                'output_power': ps['actual_out'].strip(),
                'model_number': ps['psmodel'],
                'fan_status': get_ps_fan_status_or_warn(
                    get_fan_data_by_ps(ps['psnum']).get('fanstatus')),
            }
            for ps in ps_info.supply
        }

    def process_show_env(self, ps_info):
        # Publishing summary values since IBA cannot ingest telemetry
        # from unknown keys, and we don't have power-supply related info
        # available in the blueprint.
        return {
            'power_supply_status': self._get_power_supply_status(ps_info),
            'power_supply_fan_status': self._get_fan_status(ps_info),
            'power_supply_count': self._get_power_supply_count(ps_info),
            'power_supply_info': json.dumps(
                self._get_ps_info(ps_info), indent=2, sort_keys=True),
            'power_supply_temperature_status': 0
        }

    def collect(self):
        ps_info = namedtuple('ps_info', ['supply', 'fan', 'temperature'])
        ps_info.supply = self.device.get_json('show environment power')
        ps_info.fan = self.device.get_json('show environment fan')
        ps_info.supply = ps_info.supply[POWERSUP][TABLE_PSINFO][ROW_PSINFO]
        ps_info.fan = ps_info.fan[FANDETAILS][TABLE_FANINFO][ROW_FANINFO]

        self.post_data(to_extensible_postdata(self.process_show_env(ps_info)))


def collector_plugin(_device):
    return PowerSupplyCollector
