# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

from aosstdcollectors.utils.data_util import to_extensible_postdata
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.compat.aos.sdk.system_agent.device import \
    get_running_aos_version


class VlanCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(VlanCollector, self).__init__(*args, **kwargs)
        self.aos_version = get_running_aos_version()

    def parse_vlan_json(self, data):
        vlans = data.get('TABLE_vlanbrief', {}).get('ROW_vlanbrief', [])
        if isinstance(vlans, dict):
            # When system has only one vlan, cmd returns dict instead of list
            vlans = [vlans]

        return {
            vlan['vlanshowbr-vlanid']: {
                'vlan_id': int(vlan['vlanshowbr-vlanid']),
                'name': vlan.get('vlanshowbr-vlanname', ''),
                'interfaces': [x for x in (
                    vlan.get('vlanshowplist-ifidx', '').split(',')
                    # ifidx can be either string or list
                    if isinstance(vlan.get('vlanshowplist-ifidx', ''), basestring)
                    else ','.join(
                        vlan.get('vlanshowplist-ifidx', '')
                    ).split(',')
                ) if x]
            }
            for vlan in vlans
            if 'vlanshowbr-vlanid' in vlan and vlan['vlanshowbr-vlanid'].isdigit()
        }

    def collect(self):
        self.post_data(
            to_extensible_postdata(
                self.parse_vlan_json(self.device.get_json('show vlan')),
                aos_version=self.aos_version))


def collector_plugin(_device):
    return VlanCollector
