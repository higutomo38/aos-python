# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

"""

Discovers EVPN Type 3 (Multicast VTEP flood list) route expectations.

Pair with this query as IBA probe.

rd_vtep is:
 '%s:%s_%s' % (remote_loopback.ipv4_addr.split('/')[0],
               remote_vn_inst.vlan_id,
               remote_vtep.ipv4_addr.split('/')[0])

match(
  node('system', name='system', deploy_mode='deploy')
  .out('hosted_vn_instances')
  .node('vn_instance', name='local_vn_instance')
  .out('instantiates')
  .node('virtual_network', name='virtual_network', vn_type='vxlan'),

  node('security_zone', name='security_zone', sz_type='evpn')
  .out('member_vns')
  .node('virtual_network', name='virtual_network'),

  node('virtual_network', name='virtual_network')
  .out('instantiated_by')
  .node('vn_instance', name='remote_vn_inst')
  .in_('hosted_vn_instances')
  .node('system', name='remote_system'),

  node('system', name='remote_system', deploy_mode='deploy')
  .out('hosted_interfaces')
  .node('interface', if_type='loopback', loopback_id=0, name='remote_loopback'),

  node('system', name='remote_system')
  .out('hosted_interfaces')
  .node('interface', if_type='logical_vtep', name='remote_vtep')

).ensure_different('system', 'remote_system')
"""

from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
import re
import logging
from aosstdcollectors.utils.data_util import to_extensible_postdata, \
    format_generic_value
from aosstdcollectors.compat.aos.sdk.system_agent.device import \
    get_running_aos_version

LOG = logging.getLogger(__name__)


class EVPNType3Collector(BaseTelemetryCollector):

    def __init__(self, *args, **kwargs):
        super(EVPNType3Collector, self).__init__(*args, **kwargs)
        self.aos_version = get_running_aos_version()

    def collect(self):
        """  Collect EVPN Type 3 telemetry data. Result is a list of dictionary
             keys.

             We are interested in the key name, which is the route distinguisher,
             and the parsed prefix which is actually the EVPN Type 3 VTEP for remote
             leaf.

             For payload details, see the unit test fixtures.

         """
        data = self.device.get_json(
            'show bgp l2vpn evpn route-type 3')

        if not data:
            self.post_data(
                to_extensible_postdata({}, aos_version=self.aos_version))

        def get_prefix(prefix):
            pattern = re.compile(r'\[3\]:\[0\]:\[32\]:\[(?P<vtep>.+)\]')
            match = re.match(pattern, prefix)
            return match.group('vtep')

        # pylint: disable=unused-variable
        def get_hops(path):
            # Parse ROW_path
            # there are keys 'neighbor' (which is IP address of BGP peer)
            # and 'ipnexthop'.  The next-hop for EVPN routes in two_stage_l3clos is
            # the vtep IP address in BGP, and will be the same for every learned VNI
            # Instead, we have to look at the bgp update itself and look at the
            # multiple paths we can take to get _to_ the vtep.
            # Ideally it would be better to be able to obtain routing table telemetry
            # and use this information in a composed graph processor, but that
            # telemetry is not exposed, so we will attempt to derive it.

            hops = []
            if not path:
                return hops
            if isinstance(path, dict):
                hops.append(path['neighborid'])
            elif isinstance(path, list):
                for entry in path:
                    hops.append(entry['neighborid'])
            return list(set(hops))
        rd_rows = data.get('TABLE_vrf', {}).get('ROW_vrf', {}).\
            get('TABLE_afi', {}).get('ROW_afi', {}).get('TABLE_safi', {}).\
            get('ROW_safi', {}).get('TABLE_rd', {}).get('ROW_rd', [])
        vteps = {}

        def process_vtep(rd_data, prefix, prefix_item):
            # value = {
            #   'rd': rd_data['rd_val'],
            #    'vtep': get_prefix(prefix),
            #    'next_hops': get_hops(
            #        prefix_item.get('TABLE_path', {}).get('ROW_path'))
            # }
            identity = '%s|%s' % (rd, get_prefix(prefix))
            value = '1'
            vteps[identity] = format_generic_value(self.aos_version, value)

        for rd_data in rd_rows:
            rd = rd_data['rd_val']
            prefix_item = rd_data.get('TABLE_prefix', {}).get('ROW_prefix')

            if isinstance(prefix_item, dict):
                prefix = rd_data.get('TABLE_prefix').\
                    get('ROW_prefix').get('nonipprefix')
                process_vtep(rd_data, prefix, prefix_item)

            elif isinstance(prefix_item, list):
                for entry in prefix_item:
                    prefix = entry.get('nonipprefix')
                    process_vtep(rd_data, prefix, entry)

            else:
                raise ValueError('Invalid data type for %s' % prefix_item)

        self.post_data(to_extensible_postdata(vteps, aos_version=self.aos_version))


def collector_plugin(_device):
    return EVPNType3Collector

# EOF
