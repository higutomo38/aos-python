# Copyright 2019-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

import logging
import json
from collections import namedtuple
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.compat.aos.sdk.system_agent.device import \
    get_running_aos_version
from aosstdcollectors.utils.data_util import to_extensible_postdata

LOGGER = logging.getLogger(__name__)

OK_STATUS = 1
ERROR_STATUS = 2

PSInfo = namedtuple('PSInfo', ['supply', 'fan'])


class PowerSupplyCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(PowerSupplyCollector, self).__init__(*args, **kwargs)
        self.aos_version = get_running_aos_version()

    def _get_power_supply_status(self, ps_info):
        row_psinfo = ps_info.supply['powersup']['TABLE_psinfo']['ROW_psinfo']
        for ps in row_psinfo:
            ps_status = ps['ps_status'].lower()
            if ps_status != 'ok':
                return ERROR_STATUS
        return OK_STATUS

    def _get_fan_status(self, ps_info):
        fan_info = ps_info.fan['fandetails']['TABLE_faninfo']['ROW_faninfo']
        for fan in fan_info:
            if fan['fanname'].strip().startswith('PS-'):
                fan_status = fan['fanstatus'].lower()
                if fan_status != 'ok':
                    return ERROR_STATUS
        return OK_STATUS

    def _get_power_supply_count(self, ps_info):
        ps_count = 0
        row_psinfo = ps_info.supply['powersup']['TABLE_psinfo']['ROW_psinfo']
        for ps in row_psinfo:
            ps_status = ps['ps_status'].lower()
            if ps_status != 'absent':
                ps_count += 1
        return ps_count

    def _get_ps_fan_status(self, ps_info, psnum):
        fan_info = ps_info.fan['fandetails']['TABLE_faninfo']['ROW_faninfo']
        fanname = 'PS-' + psnum
        for fan in fan_info:
            if fan['fanname'].strip() == fanname:
                return fan['fanstatus']

        LOGGER.warn('cannot get fanstatus')
        return None

    def _get_ps_info(self, ps_info):
        row_psinfo = ps_info.supply['powersup']['TABLE_psinfo']['ROW_psinfo']
        # n3k doesn not provide uptime, airflow, odm_manufacturer
        # or temp_sensors info
        return {
            ps['psnum']: {
                'status': ps['ps_status'],
                'input_power': ps['watts'],
                'output_power': None,
                'model_number': ps['psmodel'],
                'fan_status': self._get_ps_fan_status(ps_info, ps['psnum'])
            }
            for ps in row_psinfo
        }

    def process_show_env(self, ps_info):
        # Publishing summary values since IBA cannot ingest telemetry
        # from unknown keys, and we don't have power-supply related info
        # available in the blueprint.
        return {
            'power_supply_status': self._get_power_supply_status(ps_info),
            'power_supply_fan_status': self._get_fan_status(ps_info),
            # n3k does not provide PS temperature info
            'power_supply_temperature_status': 0,
            'power_supply_count': self._get_power_supply_count(ps_info),
            'power_supply_info': json.dumps(
                self._get_ps_info(ps_info), indent=2, sort_keys=True),
        }

    def collect(self):
        ps_info = PSInfo(
            supply=self.device.get_json('show environment power'),
            fan=self.device.get_json('show environment fan')
        )

        self.post_data(to_extensible_postdata(
            self.process_show_env(ps_info)
        ))


def collector_plugin(_device):
    return PowerSupplyCollector
