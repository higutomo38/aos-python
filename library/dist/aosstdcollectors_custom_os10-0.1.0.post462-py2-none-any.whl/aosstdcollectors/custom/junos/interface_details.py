# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula
import json
import logging
import re

from netaddr import IPNetwork, AddrFormatError

from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.compat.aos.sdk.system_agent.device import \
    get_running_aos_version
from aosstdcollectors.utils.data_util import format_generic_value

# https://www.juniper.net/documentation/en_US/junos/topics/concept/interfaces-naming-conventions-qfx-series.html
# has details about interface naming
VALID_INTF_REGEX = re.compile(r'^(ge|xe|xle|fte|et|ae|lo|irb).*$')

LOG = logging.getLogger(__name__)


def speed_mbps(speed_str):
    if not speed_str:
        return None

    patterns = {
        r'^(\d+)mbps$': 1,
        r'^(\d+)Gbps$': 1000,
    }

    for pattern, multiplier in patterns.iteritems():
        result = re.match(pattern, speed_str)
        if result:
            return int(result.group(1)) * multiplier

    return None


def phy_intf_from_logical_intf_name(logical_intf_name):
    return logical_intf_name.split('.')[0]


def unit_number_from_logical_intf_name(logical_intf_name):
    return logical_intf_name.split('.')[1]


class InterfaceDetailsCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(InterfaceDetailsCollector, self).__init__(*args, **kwargs)
        self._spec = None
        self._vlan_spec = None
        self.aos_version = get_running_aos_version()

    @property
    def spec(self):
        if self._spec:
            return self._spec

        self._spec = self.device.load_table_view_spec({
            'InterfaceTable': {
                'rpc': 'get-interface-information',
                'item': 'physical-interface',
                'view': 'InterfaceView',
            },
            'InterfaceView': {
                'fields': {
                    'description': 'description',
                    'speed': 'speed',
                    'if_type': 'if-type',  # <if-type>Loopback</if-type>
                    'min_child_count': 'minimum-links-in-aggregate',
                    'mc_ae_status': 'mc-ae-status',
                    'logical_interfaces': '_LogicalInterfaceTable',
                },
            },
            '_LogicalInterfaceTable': {
                'item': 'logical-interface',
                'view': '_LogicalInterfaceView',
            },
            '_LogicalInterfaceView': {
                'fields': {
                    'description': 'description',
                    'vlan_name': 'irb-domain/irb-bridge',
                    'link_address': 'link-address',
                    'addr_families': '_AddressFamilyTable',
                }
            },
            '_AddressFamilyTable': {
                'item': 'address-family',
                'key': 'address-family-name',
                'view': '_AddressFamilyView'
            },
            '_AddressFamilyView': {
                'fields': {
                    'name': 'name',
                    'ae_bundle_name': 'ae-bundle-name',
                    'addresses': '_AddressTable',
                    'is_trunked': {
                        'address-family-flags/ifff-port-mode-trunk': 'flag'
                    }
                },
            },
            '_AddressTable': {
                'item': 'interface-address',
                'key': 'ifa-local',
                'view': '_AddressView',
            },
            '_AddressView': {
                'fields': {
                    'ip': 'ifa-local',
                    'network': 'ifa-destination',
                    'is_primary': {'ifa-flags/ifaf-current-primary': 'flag'},
                },
            }
        })

        return self._spec

    @property
    def vlan_spec(self):
        if self._vlan_spec:
            return self._vlan_spec

        self._vlan_spec = self.device.load_table_view_spec({
            'VlanTable': {
                'rpc': 'get-vlan-information',
                'args': {'verbosity': 'detail'},
                'item': 'l2ng-l2ald-vlan-instance-group',
                'key': 'l2ng-l2rtb-vlan-name',
                'view': 'VlanView',
            },
            'VlanView': {
                'fields': {
                    'vlan_id': 'l2ng-l2rtb-vlan-tag',
                    'members': '_VlanMemberTable',
                },
            },
            '_VlanMemberTable': {
                'item': 'l2ng-l2rtb-vlan-member',
                'key': 'l2ng-l2rtb-vlan-member-interface',
                'view': '_VlanMemberView',
            },
            '_VlanMemberView': {
                'fields': {
                    'tagness': 'l2ng-l2rtb-vlan-member-tagness',
                    'mode': 'l2ng-l2rtb-vlan-member-interface-mode',
                }
            },
        })

        return self._vlan_spec

    def subsume_logical_interface(self, logical_intf):
        # https://kb.juniper.net/InfoCenter/index?page=content&id=KB31774 talks
        # about unit number 16386 getting created for unconfigured interfaces
        return unit_number_from_logical_intf_name(logical_intf.name) in [
            '0', '16386']

    def build_interface(self, logical_intf, intf, vlans):
        def intf_name():
            return intf.name if self.subsume_logical_interface(
                logical_intf) else logical_intf.name

        def intf_ipv4():
            inet_af = next(
                (af for af in logical_intf.addr_families if af.name == 'inet'), None)
            if not inet_af or not inet_af.addresses:
                return None

            primary_addr = next(
                (a for a in inet_af.addresses if a.is_primary),
                inet_af.addresses[0]
            )

            if not primary_addr.ip:
                return None

            try:
                return '%s/%s' % (
                    primary_addr.ip, IPNetwork(primary_addr.network).prefixlen)
            except (AddrFormatError, TypeError) as e:
                LOG.debug("Primary address %s of logical interface %s does not "
                          "have valid network: %s", primary_addr.ip,
                          logical_intf.name, e)
                return None

        # pylint: disable=too-many-return-statements
        def intf_type():
            if logical_intf.vlan_name:
                return 'svi'

            if intf.min_child_count:
                return 'port_channel'

            if intf.if_type == 'Loopback':
                return 'loopback'

            if re.match(r'^em.*$', intf.name):
                return 'management'

            if not self.subsume_logical_interface(logical_intf):
                return 'subinterface'

            if not logical_intf.addr_families:
                return 'ip'  # assume layer3 by default? not clear

            for af in logical_intf.addr_families:
                if af.name in ['inet', 'inet6']:
                    return 'ip'

                if af.name in ['eth-switch', 'aenet']:
                    return 'ethernet'
            return None

        def intf_parent():
            if if_type == 'subinterface':
                return phy_intf_from_logical_intf_name(logical_intf.name)

            af_aenet = next(
                (af for af in logical_intf.addr_families if af.name == 'aenet'),
                None)
            if af_aenet:
                return phy_intf_from_logical_intf_name(af_aenet.ae_bundle_name)
            return None

        def intf_applicable():
            # https://kb.juniper.net/InfoCenter/index?page=content&id=KB2277 talks
            # about internal logical interface created..
            if unit_number_from_logical_intf_name(logical_intf.name) == '32767':
                return False

            if logical_intf.name == 'lo0.16385':
                # lo0.16385 is the loopback interface for the internal routing
                # instance
                return False

            return True

        def allowed_vlans():
            member_name = logical_intf.name + '*'
            return [
                int(vlan.vlan_id)
                for vlan in vlans
                if any(m for m in vlan.members if member_name == m.name)
            ]

        def native_vlan():
            member_name = logical_intf.name + '*'
            result = [
                int(vlan.vlan_id)
                for vlan in vlans
                if any(
                    m for m in vlan.members
                    if member_name == m.name and m.tagness == 'untagged'
                )
            ]
            if not result:
                return None
            assert len(result) == 1, 'More than one native vlan found: %s' % locals()
            return result[0]

        def mlag_id():
            if not intf.mc_ae_status:
                return None

            # We can avoid parsing by using 'show interfaces mc-ae extensive' to get
            # the mlag id, but doing this instead to reduce relying on a brand new
            # verbose command just for the mlag id
            m = re.match(r'\(MC-AE-(\d+),.*\)', intf.mc_ae_status)
            assert m, 'Interface %s in MLAG but unable to parse mlag id from %s' % (
                intf.items(), intf.mc_ae_status)
            return int(m.group(1))

        if_type = intf_type()
        if not intf_applicable():
            return None

        af_eth = next(
            (af for af in logical_intf.addr_families if af.name == 'eth-switch'),
            None)

        return {
            'name': intf_name(),
            'allowed_vlans': allowed_vlans(),
            'description': logical_intf.description or intf.description,
            'speed_mbps': speed_mbps(intf.speed),
            'ipv4_addr': intf_ipv4(),
            'type': intf_type(),
            'parent': intf_parent(),
            'native_vlan': native_vlan(),
            'mlag_id': mlag_id(),
            'subinterface_id': str(unit_number_from_logical_intf_name(
                logical_intf.name)) if if_type == 'subinterface' else None,
            'mode': 'access' if af_eth and not af_eth.is_trunked else 'trunk',
            # TODO (Rags): need to fill virtual ips and macs
            'virtual_ips': [],
            'virtual_macs': [],
            'vlan_id': int(next(
                v for v in vlans if v.name == logical_intf.vlan_name
            ).vlan_id) if logical_intf.vlan_name else None,
        }

    def get_interfaces(self, intfs, vlans):
        for intf in intfs:
            if not VALID_INTF_REGEX.match(intf.name):
                continue

            for logical_intf in intf.logical_interfaces:
                output_intf = self.build_interface(logical_intf, intf, vlans)
                if output_intf:
                    yield output_intf

    def collect(self):
        items = [
            {
                'identity': intf['name'],
                'value': format_generic_value(self.aos_version, intf),
            }
            for intf in self.get_interfaces(
                self.device.create_table(self.spec['InterfaceTable']).get(),
                self.device.create_table(self.vlan_spec['VlanTable']).get()
            )
        ]

        self.post_data(json.dumps(dict(items=items)))


def collector_plugin(_device):
    return InterfaceDetailsCollector
