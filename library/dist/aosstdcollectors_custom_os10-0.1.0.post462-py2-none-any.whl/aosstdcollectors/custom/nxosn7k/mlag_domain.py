# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula


from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.data_util import to_extensible_postdata
from aosstdcollectors.utils.nxosn7k_util import get_tree
from aosdevicedrivers.compat.aos.sdk.system_agent.device import DeviceError
import json
import logging

LOG = logging.getLogger(__name__)


class MlagDomainCollector(BaseTelemetryCollector):
    def collect(self):
        def get_domain_id():
            domain_id = info[0].find('.//aos:vpc-domain-id', nsmap).text
            if domain_id == 'not configured':
                return None
            return json.dumps(str(domain_id))

        try:
            collected = self.device.get_text('show vpc | xml')
        except DeviceError:
            LOG.warn('vpc feature not enabled')
            self.post_data(
                to_extensible_postdata({
                    'domain_id': None,
                    'system_id': None,
                    'domain_state': None,
                    'local_interface': None,
                    'local_interface_status': None,
                    'local_interface_vlan_id': None,
                    'peer_link': None,
                    'peer_link_status': None,
                    'peer_address': None,
                    'config_sanity': None,
                })
            )
            return

        tree, nsmap = get_tree(collected)
        info = tree.xpath('//aos:show/aos:vpc', namespaces=nsmap)

        self.post_data(to_extensible_postdata({
            # TODO (mhutt) need to poplulate the rest of the fields once
            # we get complete test data
            # without json.dumps the value becomes integer thus violating schema
            'domain_id': get_domain_id(),
            'system_id': None,
            'domain_state': 1 if info[0].find(
                './/aos:vpc-peer-status', nsmap).text == 'active' else 2,
            'local_interface': None,
            'local_interface_status': None,
            'local_interface_vlan_id': None,
            'peer_link': None,
            'peer_link_status': 1 if info[0].find(
                './/aos:vpc-peer-keepalive-status', nsmap).text == 'up' else 2,
            'peer_address': None,
            'config_sanity': 1 if info[0].find(
                './/aos:vpc-peer-consistency', nsmap).text == 'consistent' else 2,
        }))


def collector_plugin(_device):
    return MlagDomainCollector
