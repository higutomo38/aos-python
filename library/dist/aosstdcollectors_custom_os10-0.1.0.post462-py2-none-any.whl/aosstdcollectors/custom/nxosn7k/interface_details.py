# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula
import json

from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.nxosn7k_util import get_tree, get_value
from aosstdcollectors.compat.aos.sdk.system_agent.device import \
    get_running_aos_version
from aosstdcollectors.utils.data_util import format_generic_value

DEFAULT_BANDWIDTH_MB = 10000


def to_mbps(kbps):
    assert kbps, locals()
    return int(kbps) / 1000


def bandwidth(bw):
    # nxosn7k provides bw in kbps
    # 10G links appear as 10000000
    if bw == 0:
        return DEFAULT_BANDWIDTH_MB
    return to_mbps(bw)


def type_of(intf, intf_nsmap):
    """
    Possible interface types:

     - ip (L3)
     - ethernet (L2)
     - loopback
     - svi
     - port_channel
     - subinterface
     - management
    """

    intf_type = None

    if get_value(intf, intf_nsmap, 'type') == 'svi':
        intf_type = 'svi'

    elif get_value(intf, intf_nsmap, 'interface').startswith('mgmt'):
        intf_type = 'management'

    elif get_value(intf, intf_nsmap, 'eth_hw_desc') == 'Loopback':
        intf_type = 'loopback'

    elif get_value(intf, intf_nsmap, 'parent_interface') is not None:
        intf_type = 'subinterface'

    elif get_value(intf, intf_nsmap, 'eth_mode') == 'access':
        intf_type = 'ethernet'

    elif get_value(intf, intf_nsmap, 'eth_mode') == 'routed':
        if get_value(intf, intf_nsmap, 'eth_ip_addr') is not None:
            intf_type = 'ip'
        else:
            intf_type = 'ethernet'

    assert intf_type, locals()
    return intf_type


def intf_name(intf):
    # lower case to be consistent with the behavior of
    # lag and interface builtin collectors
    return intf.lower() \
        if intf.startswith('portChannel') else intf


def get_subinterface_id(intf, nsmap):
    parent = get_value(intf, nsmap, 'parent_interface')
    if parent is None:
        return None

    interface_name = get_value(intf, nsmap, 'interface')

    # for Ethernet1.100, return 100
    assert interface_name
    return interface_name[len(parent) + 1:]


def get_mode(intf, nsmap):
    if get_value(intf, nsmap, 'eth_ethertype') == '0x8100':
        return 'trunk'
    return 'access'


def get_vlan_id(intf, nsmap):
    vlan_id = get_value(intf, nsmap, 'eth_encap_vlan')
    if vlan_id is not None:
        return int(vlan_id)
    else:
        svi_vlan_id = get_value(intf, nsmap, 'vlan_id')
        if svi_vlan_id is not None:
            return int(svi_vlan_id)
    return None


def primary_ip(intf, intf_nsmap):
    if (get_value(intf, intf_nsmap, 'eth_ip_addr')) is None:
        return None

    ip = get_value(intf, intf_nsmap, 'eth_ip_addr')
    prefix = get_value(intf, intf_nsmap, 'eth_ip_mask')
    return '/'.join([ip, prefix])


def get_bw_value(intf, intf_nsmap):
    eth_bw = get_value(intf, intf_nsmap, 'eth_bw')
    if eth_bw is not None:
        return eth_bw
    else:
        svi_bw = get_value(intf, intf_nsmap, 'svi_bw')
        if svi_bw is not None:
            return svi_bw
    return 0


class InterfaceDetailsCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(InterfaceDetailsCollector, self).__init__(*args, **kwargs)
        self.aos_version = get_running_aos_version()

    def parse_interface_details(self, interfaces):
        intf_tree, intf_nsmap = get_tree(interfaces)
        intfs = intf_tree.xpath('//aos:show/aos:interface//aos:ROW_interface',
                                namespaces=intf_nsmap)

        def build(intf):
            # TODO (mhutt) - need to add missing fields
            return {
                'name': intf_name(get_value(intf, intf_nsmap, 'interface')),
                'description': get_value(intf, intf_nsmap, 'desc'),
                'speed_mbps': bandwidth(get_bw_value(intf, intf_nsmap)),
                'ipv4_addr': primary_ip(intf, intf_nsmap),
                'type': type_of(intf, intf_nsmap),
                'parent': get_value(intf, intf_nsmap, 'parent_interface'),
                'subinterface_id': get_subinterface_id(intf, intf_nsmap),
                'mode': get_mode(intf, intf_nsmap),
                'vlan_id': get_vlan_id(intf, intf_nsmap),
                'allowed_vlans': [],
                'mlag_id': None,
                'native_vlan': None,
                'virtual_ips': [],
                'virtual_macs': [],
            }

        return [
            {
                'identity': intf_name(get_value(intf, intf_nsmap, 'interface')),
                'value': format_generic_value(self.aos_version, build(intf))
            }
            for intf in intfs
        ]

    def collect(self):
        intfs = self.device.get_text('show interface | xml')
        details = self.parse_interface_details(intfs)
        self.post_data(json.dumps({'items': details}))


def collector_plugin(_device):
    return InterfaceDetailsCollector
