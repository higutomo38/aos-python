# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

"""Offbox deploment helper for Eos switches"""

import os
import re
import logging
from jnpr.junos.utils.config import Config
from jnpr.junos.exception import ConnectError, LockError, UnlockError, \
    CommitError, ConfigLoadError
from aosdevicedrivers.compat.aos.sdk.system_agent.base_telemetry_collector import \
    BaseOffBoxDeploymentHelper


LOGGER = logging.getLogger(__name__)


class JunosOffboxDeploymentHelper(BaseOffBoxDeploymentHelper):
    """Offbox Deployment helper for Juniper switches"""

    def __init__(self, sdk_device):
        super(JunosOffboxDeploymentHelper, self).__init__(sdk_device)

    def setup_device_connection(self):
        """Setup connectivity to the device
        """
        self.sdk_device.open()
        self.sdk_device.driver.bind(cu=Config)
        return True

    def get_running_config(self):
        """Queries the device for the running config and returns it as a single
           string.
        """
        config = self.sdk_device.driver.cu.rpc.get_config(
            options={'database': 'committed', 'format': 'text'})
        # Filter the commit timestamp line from the config string
        return re.sub(r"^\s## Last commit.*\n", "", config.text)

    def get_system_uptime(self):
        """Returns the system uptime in seconds (float)
        """
        uptime_info = self.sdk_device.driver.rpc.get_system_uptime_information()
        up_time = uptime_info.find(
            './/system-uptime-information/uptime-information/up-time').get('seconds')
        return float(up_time)

    def apply_complete_config(self, config_blob, pristine_config):
        """Overwrite the running config of the device with given config blob
        """
        config = pristine_config + os.linesep + config_blob
        try:
            self.sdk_device.driver.cu.lock()
        except (ConnectError, LockError) as ex:
            LOGGER.exception('Config lock failed %s', str(ex))
            raise

        try:
            self.sdk_device.driver.cu.load(config, format='text', overwrite=True)
        except ConnectError as ex:
            LOGGER.exception('Connect error during config load: %s', str(ex))
            raise
        except ConfigLoadError as ex:
            message = 'Apply config failed: %s' % str(ex)
            LOGGER.exception(message)
            self.sdk_device.driver.cu.unlock()
            return False, message

        try:
            self.sdk_device.driver.cu.commit()
        except ConnectError as ex:
            LOGGER.exception('Connect error during config commit: %s', str(ex))
            raise
        except CommitError as ex:
            message = 'Apply config failed: %s' % str(ex)
            LOGGER.exception(message)
            self.sdk_device.driver.cu.unlock()
            return False, message

        try:
            self.sdk_device.driver.cu.unlock()
        except (ConnectError, UnlockError) as ex:
            LOGGER.exception('Config unlock failed: %s', str(ex))
            raise

        return True, ''

    def apply_incremental_config(self, config_blob):
        """Apply the given incremental config blob on the device
        """
        # This should not be called, we only use complete config deploy
        assert False
