# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

import logging
from netaddr import EUI, mac_unix_expanded

from aos.sdk.system_agent.device import Device as AosDevice
from jnpr.junos import Device as JunosDriver
from jnpr.junos.utils.start_shell import StartShell
from jnpr.junos.factory import FactoryLoader
from jnpr.junos.exception import ConnectError
from aosdevicedrivers.compat.aos.sdk.system_agent.device import \
    DeviceError, DeviceNetworkError

# Set ncclient log level to ERROR so it doesn't spam
# aos agent log files for every driver call
# TODO(kaza) Set this at application config level RFE-838
NCCLIENT_LOG = logging.getLogger('ncclient')
level = logging.getLevelName('ERROR')
NCCLIENT_LOG.setLevel(level)

LOG = logging.getLogger(__name__)


class JunosDevice(AosDevice):
    def __init__(self, *args, **kwargs):
        super(JunosDevice, self).__init__(*args, **kwargs)
        assert not self.onbox, 'Junos supported only with offbox'
        self.driver = None
        self._shell = None

    def open(self):
        open_driver = dict(
            host=self.ip_address,
            user=self.username, passwd=self.password,
            timeout=60)

        open_driver['no_probe'] = True

        self.driver = JunosDriver(**open_driver)
        self.driver.open()

    def close(self):
        if self._shell:
            self._shell.close()
            self._shell = None
        self.driver.close()
        self.driver = None

    def _get_hw_model_and_version(self):
        hw_model = self.driver.facts['model']
        hw_version = ''

        got = self.driver.rpc.get_chassis_inventory()

        mod = got.xpath('.//chassis-module[serial-number="%s"]' %
                        self._serial_number())
        if mod:
            mod = mod[0]
            hw_model = mod.find('./model-number').text
            hw_version = mod.find('./version').text
        else:
            LOG.warning("Chassis model is not set for device!")

        return hw_model, hw_version

    def _get_chassis_mac_ranges(self):
        mac_addresses = self.driver.rpc.get_chassis_mac_addresses({'format': 'json'})
        if 'chassis-mac-addresses' not in mac_addresses or \
                not mac_addresses['chassis-mac-addresses']:
            LOG.warning("Failed to get chassis mac ranges")
            return ''
        mac_addresses = mac_addresses['chassis-mac-addresses'][0]
        if 'chassis-mac-addresses-edge-info' not in mac_addresses:
            LOG.warning("Failed to get chassis mac ranges")
            return ''
        mac_addresses = mac_addresses['chassis-mac-addresses-edge-info']
        chassis_mac_ranges = []
        for mac_range in mac_addresses:
            mac_range = mac_range['fpc-mac-address'][0]
            mac1 = EUI(mac_range['fpc-mac-base'][0]['data'],
                       dialect=mac_unix_expanded)
            mac_count = int(mac_range['fpc-mac-count'][0]['data'])
            mac2 = EUI(mac1.value + mac_count - 1, dialect=mac_unix_expanded)
            chassis_mac_ranges.append('%s-%s' % (mac1, mac2))
        return ','.join(chassis_mac_ranges)

    def _get_junos_mgmt_info(self):
        if_name, macaddr = None, None
        rpc = self.driver.rpc

        got = rpc.get_route_information(destination=self._mgmt_ip())
        if got is not None:
            if_name, _, _ = got.find('.//nh-local-interface').text.partition('.')
        else:
            LOG.warning("Failed to get route information")

        got = rpc.get_interface_information(media=True, interface_name=if_name)
        if got is not None:
            macaddr = got.find('.//current-physical-address').text.strip().upper()
        else:
            LOG.warning("Failed to get interfaces")

        return if_name, macaddr

    def _mgmt_ip(self):
        return self.ip_address

    def _get_version(self):
        version = {
            'major': None,
            'minor': None,
            'build': None,
            'text': None,
        }
        junos_info = self.driver.facts['junos_info']

        if junos_info:
            v = (junos_info.get('re0') or junos_info.get('fpc0')
                 or junos_info.get('localre'))
            if v:
                version['text'] = v['text']
                version['major'] = '%s.%s' % v['object'].major
                version['minor'] = str(v['object'].minor)
                version['build'] = str(v['object'].build)
        else:
            LOG.warning("junos_info is not available")

        return version

    def get_device_info(self):
        version = self._get_version()
        hw_model, hw_version = self._get_hw_model_and_version()
        mgmt_ifname, mgmt_mac = self._get_junos_mgmt_info()
        chassis_mac_ranges = self._get_chassis_mac_ranges()

        return {
            'chassis_mac_ranges': chassis_mac_ranges,
            'hw_model': hw_model,
            'hw_version': hw_version,
            'mgmt_ifname': mgmt_ifname,
            'mgmt_ipaddr': self._mgmt_ip(),
            'mgmt_macaddr': mgmt_mac,
            'os_arch': 'x86_64',  # TODO: get from facts
            'os_family': 'Junos',
            'os_version': version['text'],
            'os_version_info': {
                'build': version['build'],
                'major': version['major'],
                'minor': version['minor'],
            },
            'serial_number': self._serial_number(),
            'vendor': 'Juniper',
        }

    def _serial_number(self):
        model = self.driver.facts['model']
        if model and 'VQFX' in model:
            # For vQFX use mgmt interface mac address as the serical number
            # for compatibility with slicer logic
            _, mgmt_mac = self._get_junos_mgmt_info()
            return mgmt_mac.replace(':', '')

        return str(self.driver.facts['serialnumber'])

    def probe(self):
        try:
            self.driver.rpc.get_software_information()
        # pylint: disable=broad-except
        except Exception as ex:
            if isinstance(ex, ConnectError):
                raise DeviceNetworkError('Device network error', ex)
            else:
                raise DeviceError('Device error', ex)

    def create_table(self, table_clz, **kwargs):
        return table_clz(self.driver, **kwargs)

    # pylint: disable=keyword-arg-before-vararg
    def get_config(self, database='committed', *args, **kwargs):
        '''Args and keyword args are same as jnpr.junos.Device.rpc.get_config'''
        options = kwargs.setdefault('options', {})
        options['database'] = database
        return self.driver.rpc.get_config(*args, **kwargs)

    @staticmethod
    def load_table_view_spec(spec):
        return FactoryLoader().load(spec)

    @property
    def shell(self):
        assert self.driver
        if not self._shell:
            self._shell = StartShell(self.driver)
            self._shell.open()
        return self._shell

    def get_text(self, command):
        out = self.shell.run(command)
        # `out` is a tuple with first item True/False if exit-code is 0 and
        # second item the output of the command.
        if out[0]:
            return out[1]
        else:
            raise DeviceError(
                "Command '{}' failed with error: {}".format(command, out[1])
            )
