# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula
import json
import math
import datetime
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.textparsing import TextFsmParser
import logging
LOGGER = logging.getLogger(__name__)

PROCESS_METRICS = ['VmPeak', 'VmSize', 'VmLck', 'VmPin', 'VmHWM', 'VmRSS', 'VmData',
                   'VmStk', 'VmExe', 'VmLib', 'VmPTE', 'VmSwap']
VALUE_DEFS = '\n'.join('Value %s (\\d+)' % m for m in PROCESS_METRICS)
VALUE_PATTERNS = '\n'.join('  ^%s:\\s+${%s}' % (m, m) for m in PROCESS_METRICS)

process_memory_template = ''' #TextFSM
Value Name (\\S+)
''' + VALUE_DEFS + '''

Start
  ^Name:\\s+${Name}
''' + VALUE_PATTERNS + ''' -> Record

EOF
'''

system_memory_template = ''' #TextFSM
Value MemTotal (\\d+)
Value MemFree (\\d+)

Start
  ^MemTotal:\\s+${MemTotal}
  ^MemFree:\\s+${MemFree} -> Record

EOF
'''

PROCESS_MEMORY_USAGE_PARSER = TextFsmParser(process_memory_template)
SYSTEM_MEMORY_USAGE_PARSER = TextFsmParser(system_memory_template)


class ResourceUsageCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(ResourceUsageCollector, self).__init__(*args, **kwargs)
        self.prev_data = None
        self.prev_timestamp = None
        self.curr_data = None
        self.curr_timestamp = None

    def build_key(self, proc, metric, rate=False):
        if rate:
            return proc + '|memory_rate|' + metric
        return proc + '|memory|' + metric

    def calculate_rate(self, curr_data, prev_data):
        time_diff = (self.curr_timestamp - self.prev_timestamp).total_seconds()
        rate = int(math.ceil((curr_data - prev_data) / time_diff))
        return rate

    def parse_memory_data(self, data):
        parsed_data = PROCESS_MEMORY_USAGE_PARSER.parse(data)

        if not parsed_data:
            raise ValueError('Unable to parse: %s' % data)

        for row in parsed_data:
            proc = row[0].lower()
            for idx, metric_name in enumerate(PROCESS_METRICS, 1):
                key = self.build_key(proc, metric_name)
                self.curr_data[key] = row[idx] if row[idx] else 0
                if self.prev_data and key in self.prev_data:
                    self.curr_data[self.build_key(proc, metric_name, True)] =\
                        self.calculate_rate(int(self.curr_data[key]),
                                            int(self.prev_data[key]))

    def process_system_memory_data(self, data):
        parsed_data = SYSTEM_MEMORY_USAGE_PARSER.parse(data)

        if not parsed_data:
            raise ValueError('Unable to parse: %s' % data)

        mem_total, mem_free = parsed_data[0]
        mem_used = int(mem_total) - int(mem_free)
        key = 'system|memory'
        self.curr_data[key] = mem_used
        if self.prev_data:
            rate = self.calculate_rate(mem_used,
                                       int(self.prev_data[key]))
            self.curr_data['system|memory_rate'] = rate

    def collect_system_memory_usage(self):
        self.process_system_memory_data(self.get_meminfo())

    def get_meminfo(self):
        return self.device.get_text('cat /proc/meminfo')

    def collect_process_memory_usage(self):
        self.parse_memory_data(self.get_process_memory_usage())

    def get_process_memory_usage(self):
        return self.device.get_text('grep -shE "Name|Vm" /proc/*/status || true')

    def collect(self):
        self.curr_timestamp = datetime.datetime.now()
        self.curr_data = {}

        self.collect_system_memory_usage()
        self.collect_process_memory_usage()

        self.prev_data = self.curr_data
        self.prev_timestamp = self.curr_timestamp

        result = {
            'items': [
                {
                    'identity': key,
                    'value': str(value)
                }
                for key, value in self.curr_data.iteritems()
            ]
        }
        self.post_data(json.dumps(result))


def collector_plugin(_device):
    return ResourceUsageCollector
