# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula
from aosstdcollectors.common_collectors.device_info import DeviceInfoCollector


def collector_plugin(_device):
    return DeviceInfoCollector
