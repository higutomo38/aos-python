# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula


import json
import logging
import re
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.nxosn7k_util import get_tree, get_value
from aosstdcollectors.utils.nxosn7k_vrf_util import read_vrfs
from collections import defaultdict

LOG = logging.getLogger(__name__)
IPROUTE_REGEX = re.compile(r'Total number of routes:\s+(\d+)')
IPMROUTE_REGEX = re.compile(r'Total number of routes:\s+(\d+)')
GROUP_REGEX = re.compile(r'Total number of \(\*,G\) routes:\s+(\d+)')
SOURCE_REGEX = re.compile(r'Total number of \(S,G\) routes:\s+(\d+)')


class TableUsage(BaseTelemetryCollector):
    def get_arp_entries(self, vrfs):
        results = defaultdict(lambda: dict(num_arp_entries=0))

        for vrf in vrfs:
            arp_tree, arp_nsmap = get_tree(
                self.device.get_text('show ip arp vrf ' + vrf + ' | xml'))

            # row is a list but only contains data for a single vrf row[0]
            row = arp_tree.xpath('//aos:show//aos:ROW_vrf', namespaces=arp_nsmap)
            arp_count = get_value(row[0], arp_nsmap, 'cnt-total')

            results[vrf]['num_arp_entries'] = int(arp_count)
            results['total']['num_arp_entries'] += int(arp_count)

        return [
            {
                'identity': '%s|num_arp_entries' % vrf,
                'value': str(results[vrf]['num_arp_entries'])
            }
            for vrf in results
        ]

    def get_ip_routes(self, vrfs):
        results = defaultdict(lambda: dict(num_ip_routes=0))

        for vrf in vrfs:
            data = self.device.get_text('show ip route summary vrf ' + vrf)
            iproute_count = IPROUTE_REGEX.search(data)
            if iproute_count:
                results[vrf]['num_ip_routes'] = int(iproute_count.group(1))
                results['total']['num_ip_routes'] += int(iproute_count.group(1))

        return [
            {
                'identity': '%s|num_ip_routes' % vrf,
                'value': str(results[vrf]['num_ip_routes'])
            }
            for vrf in results
        ]

    def get_mcast_table(self, vrfs):
        results = defaultdict(lambda: dict(
            num_mcast_routes=0,
            num_mcast_sources=0,
            num_mcast_groups=0
        ))

        for vrf, vrf_info in vrfs.iteritems():
            if vrf_info['multicast_mode'] == 'enabled':
                data = self.device.get_text('show ip mroute summary vrf ' + vrf)
                ipmroute_count = IPMROUTE_REGEX.search(data)
                if ipmroute_count:
                    results[vrf]['num_mcast_routes'] = int(ipmroute_count.group(1))
                    results['total']['num_mcast_routes'] += \
                        int(ipmroute_count.group(1))

                source_count = SOURCE_REGEX.search(data)
                if source_count:
                    results[vrf]['num_mcast_sources'] = int(source_count.group(1))
                    results['total']['num_mcast_sources'] += \
                        int(source_count.group(1))

                group_count = GROUP_REGEX.search(data)
                if group_count:
                    results[vrf]['num_mcast_groups'] = int(group_count.group(1))
                    results['total']['num_mcast_groups'] += int(group_count.group(1))

        return [
            {
                'identity': '%s|%s' % (vrf, metric),
                'value': str(results[vrf][metric])
            }
            for vrf in results
            for metric in results[vrf]
        ]

    def create_breakdown(self, data, key):
        breakdown = defaultdict(dict)

        for e in data:
            vrf = e['identity'].split('|')[0]
            value = e['value']
            breakdown[vrf] = value

        return [
            {
                'identity': key,
                'value': json.dumps(breakdown, indent=2)
            }
        ]

    def create_mcast_breakdown(self, data):
        breakdown = defaultdict(dict)
        for e in data:
            key, metric = e['identity'].split('|')
            value = e['value']
            breakdown[metric][key] = value

        return [
            {
                'identity': 'mcast_data',
                'value': json.dumps(breakdown, indent=2)
            }
        ]

    def collect(self):
        vrfs = read_vrfs(self.device)
        arp_entries = self.get_arp_entries(vrfs)
        arp_breakdown = self.create_breakdown(arp_entries, 'arp_entries')
        ip_routes = self.get_ip_routes(vrfs)
        ip_route_breakdown = self.create_breakdown(ip_routes, 'ip_routes')
        mcast_data = self.get_mcast_table(vrfs)
        mcast_breakdown = self.create_mcast_breakdown(mcast_data)
        self.post_data(json.dumps({
            'items':
                arp_entries + arp_breakdown
                + ip_routes + ip_route_breakdown
                + mcast_data + mcast_breakdown
        }))


def collector_plugin(_device):
    return TableUsage
