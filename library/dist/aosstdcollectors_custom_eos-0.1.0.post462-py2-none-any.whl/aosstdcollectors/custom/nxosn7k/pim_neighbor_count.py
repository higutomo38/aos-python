# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

import json
import logging
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.nxosn7k_util import get_tree, get_value
from aosstdcollectors.utils.nxosn7k_vrf_util import read_vrfs

LOG = logging.getLogger(__name__)


class PimNeighborCountCollector(BaseTelemetryCollector):
    def get_pim_neighbors_in_vrf(self, vrf):
        pim_tree, pim_nsmap = get_tree(
            self.device.get_text('show ip pim interface vrf ' + vrf + ' | xml'))

        if pim_tree is not None:
            return {
                get_value(intf, pim_nsmap, 'if-name'):
                get_value(intf, pim_nsmap, 'nbr-cnt')
                for intf in pim_tree.xpath(
                    '//aos:show//aos:interface//aos:ROW_iod', namespaces=pim_nsmap)
            }
        return {}

    def collect(self):
        """
        For all VRFs, collect:
            Identity = { VRF-name }}|{{ interface }}
            Value = Count of PIM neighbors
        """
        vrfs = read_vrfs(self.device)
        self.post_data(json.dumps({
            'items': [
                {
                    'identity': '%s|%s' % (vrf, interface),
                    'value': neighbor_count
                }
                for vrf, vrf_info in vrfs.iteritems()
                if vrf_info['role'] != 'management' and
                vrf_info['multicast_mode'] == 'enabled'
                for interface, neighbor_count in self.get_pim_neighbors_in_vrf(
                    vrf).iteritems()
            ]
        }))


def collector_plugin(_device):
    return PimNeighborCountCollector
