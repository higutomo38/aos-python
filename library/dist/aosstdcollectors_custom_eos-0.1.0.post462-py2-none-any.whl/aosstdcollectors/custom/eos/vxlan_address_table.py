# Copyright 2019-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.data_util import to_extensible_postdata
import logging
from collections import defaultdict

LOGGER = logging.getLogger('vxlan_addr_table')


def process(vxlan_addr_table):
    vxlan_table = defaultdict(int)
    for addr in vxlan_addr_table:
        mac_addr = addr['macAddress'].lower()
        vlan = addr['vlanId']
        vxlan_table['vlan=%s|table_size' % vlan] += 1
        vxlan_table['vlan=%s|%s|moves' % (vlan, mac_addr)] = addr['moves']

        if addr['moves'] <= 1:
            vxlan_table.setdefault(
                'vlan=%s|count_of_macs_with_multiple_moves' % vlan, 0)
            vxlan_table.setdefault('vlan=%s|macs_with_multiple_moves' % vlan, [])
            continue

        vxlan_table['vlan=%s|count_of_macs_with_multiple_moves' % vlan] += 1
        vxlan_table.setdefault('vlan=%s|macs_with_multiple_moves' % vlan, []).append(
            '%s|%s' % (mac_addr, addr['moves']))

    return vxlan_table


class VxlanAddressTableCollector(BaseTelemetryCollector):
    def collect(self):
        vxlan_addr_table = self.device.get_json(
            'show vxlan address-table')['addresses']
        self.post_data(to_extensible_postdata(process(vxlan_addr_table)))


def collector_plugin(_device):
    return VxlanAddressTableCollector
