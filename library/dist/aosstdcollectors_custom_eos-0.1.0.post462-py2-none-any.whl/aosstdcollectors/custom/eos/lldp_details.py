# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

import json
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.compat.aos.sdk.system_agent.device import \
    get_running_aos_version
from aosstdcollectors.utils.data_util import format_generic_value
from aosstdcollectors.utils.eos_util import make_item_lldp_nei


# pylint: disable=anomalous-backslash-in-string
class LldpDetailCollector(BaseTelemetryCollector):
    """
    Extends built-in `lldp` collector with

     - chassis_id
     - chassis_id_type

    Chassis ID is required to generate single system node during topology discovery
    process in case when server is connected to more than one leaf switches, e.g. in
    case of MLAG.

    +--------+  MLAG  +--------+
    | leaf1a |========| Leaf1b |
    +---+----+        +--+-----+
          \           /
           \        /
          +---------+
          | Server1 |
          +---------+

    In this scenario LLDP data available on `leaf1a` would have two interfaces
    discovered on `Server1`, and the same will be on `leaf1b`, and there would be no
    way of determining these two interfaces belong to the same system, unless we
    have chassis ID which would be the same for both interfaces, and thus would allow
    to create valid graph representing the system.

    Uses generic collector schema.
    """
    def __init__(self, *args, **kwargs):
        super(LldpDetailCollector, self).__init__(*args, **kwargs)
        self.aos_version = get_running_aos_version()

    def process_lldp_details(self, collected):
        def lldp_chassis_data(nei):
            return {
                'chassis_id': nei['chassisId'],
                'chassis_id_type': nei['chassisIdType'],
            }

        def lldp_nei(data):
            return data['lldpNeighborInfo']

        def first(data):
            # each interface is expected to have only one LLDP neighbor
            return data[0]

        not_mgmt_ifs = (item for item in collected['lldpNeighbors'].iteritems()
                        if not first(item).startswith('Management'))

        # some items will exist but not have LLDP neighbors, those are ignored to
        # match the onbox agent behavior

        return json.dumps({
            'items': [
                {
                    'identity': if_name,
                    'value': format_generic_value(self.aos_version, dict(
                        make_item_lldp_nei(if_name, first(lldp_nei(if_data))),
                        **lldp_chassis_data(first(lldp_nei(if_data)))
                    ))
                } for if_name, if_data in not_mgmt_ifs if lldp_nei(if_data)
            ]
        })

    def collect(self):
        lldp_detail = self.device.get_json('show lldp neighbors detail')
        self.post_data(self.process_lldp_details(lldp_detail))


def collector_plugin(_device):
    return LldpDetailCollector
