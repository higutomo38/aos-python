# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula
from aosstdcollectors.custom.linux.resource_usage import ResourceUsageCollector


class EosResourceUsageCollector(ResourceUsageCollector):
    def get_meminfo(self):
        return self.device.get_text('bash timeout 10 cat /proc/meminfo')

    def get_process_memory_usage(self):
        return self.device.get_text(
            'bash timeout 10 find /proc -maxdepth 2 -name status ' +
            '-execdir grep -E "Name|Vm" {} \\;')


def collector_plugin(_device):
    return EosResourceUsageCollector
