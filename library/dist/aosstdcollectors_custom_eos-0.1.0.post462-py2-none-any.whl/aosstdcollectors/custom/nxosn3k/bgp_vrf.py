# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula


import json
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.compat.aos.sdk.system_agent.device import \
    get_running_aos_version
from aosstdcollectors.utils.data_util import format_generic_value


class BgpVrfCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(BgpVrfCollector, self).__init__(*args, **kwargs)
        self.aos_version = get_running_aos_version()

    def parse_vrf(self, data):
        vrfs = data['TABLE_vrf']['ROW_vrf']

        def _get_neighbors(vrf):
            return vrf['TABLE_af'][
                'ROW_af'][0]['TABLE_saf'][
                    'ROW_saf'][0][
                        'TABLE_neighbor'][
                            'ROW_neighbor']
        data = {
            'items': [
                {
                    'identity': '{}_{}'.format(vrf['vrf-name-out'],
                                               neighbor['neighborid']),
                    'value': format_generic_value(self.aos_version, {
                        'vrf': vrf['vrf-name-out'],
                        'dest_ip': neighbor['neighborid'],
                        'dest_asn': neighbor['neighboras'],
                        'value': 'up' if neighbor['state'] ==
                                 'Established' else 'down',
                        'source_asn': vrf['vrf-local-as']
                    })

                }
                for vrf in vrfs
                for neighbor in _get_neighbors(vrf)

            ]
        }

        default_asn = None

        for item in data['items']:
            if isinstance(item['value'], str):
                val = json.loads(item['value'])
            else:
                val = item['value']
            if val['vrf'] == 'default':
                default_asn = val['source_asn']
        data['global'] = json.dumps(dict(asn=default_asn))

        return data

    def collect(self):
        data = self.device.get_json('show bgp ipv4 unicast summary vrf all')

        self.post_data(json.dumps(self.parse_vrf(data)))


def collector_plugin(_device):
    return BgpVrfCollector
