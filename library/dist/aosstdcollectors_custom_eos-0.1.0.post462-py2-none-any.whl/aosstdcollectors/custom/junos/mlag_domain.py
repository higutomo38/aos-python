# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula


import json
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.data_util import to_extensible_postdata
from aosstdcollectors.utils.junos_util import intf_name


class MlagDomainCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(MlagDomainCollector, self).__init__(*args, **kwargs)
        self._iccp_spec = None

    @property
    def iccp_spec(self):
        if self._iccp_spec:
            return self._iccp_spec

        self._iccp_spec = self.device.load_table_view_spec({
            'IccpTable': {
                'rpc': 'get-inter-chassis-control-protocol-information',
                'item': 'iccp-peer',
                'key': 'peer-address',
                'view': 'IccpPeerView',
            },
            'IccpPeerView': {
                'fields': {
                    'peer_address': 'peer-address',
                    # only 1 rg is supported, but junos model is just flexible
                    # add second rg error - 'number of elements exceeds limit of 1'
                    'rg_id': 'rg-groups/rg-group-entry/redundancy-group',
                    'rg_state': 'rg-groups/rg-group-entry/rg-state',
                }
            },
        })

        return self._iccp_spec

    def collect(self):
        iccp_peers = self.device.create_table(self.iccp_spec['IccpTable']).get()
        assert len(iccp_peers) <= 1, locals()
        iccp_peer = iccp_peers[0] if iccp_peers else None
        if not iccp_peer:
            self.post_data(to_extensible_postdata({
                'domain_id': None,
                'system_id': None,
                'domain_state': None,
                'local_interface': None,
                'local_interface_vlan_id': None,
                'peer_link': None,
                'peer_address': None,
                'config_sanity': None,
            }))
            return

        multi_chassis_cfg = self.device.get_config(filter_xml='multi-chassis')
        iccp_protocol_cfg = self.device.get_config(filter_xml='protocols/iccp')
        local_address = iccp_protocol_cfg.find('protocols/iccp/local-ip-addr').text
        # Junos doesn't seem to have a system-id like other Switch OSes
        system_id = ','.join(sorted((local_address, iccp_peer.peer_address)))
        peer_link = multi_chassis_cfg.find(
            'multi-chassis/multi-chassis-protection/interface').text

        # interface name is not directly available anywhere. only way is to reverse
        # lookup interface from local ip
        intf_list = self.device.driver.rpc.get_interface_information(
            terse=True)
        local_interface = intf_name(
            intf_list.xpath(
                'physical-interface/logical-interface['
                './address-family/interface-address/ifa-local['
                'contains(text(), "%s/")]]' % local_address
            )[0].find('name').text.strip()
        )

        self.post_data(to_extensible_postdata({
            # without json.dumps the value becomes integer thus violating schema
            'domain_id': json.dumps(str(iccp_peer.rg_id)) if iccp_peer else None,
            'system_id': system_id if iccp_peer else None,
            'domain_state': 1 if (
                iccp_peer and iccp_peer.rg_state.lower() == 'up') else 2,
            'local_interface': local_interface,
            'local_interface_vlan_id':
                int(local_interface.split('.')[1])
                if local_interface.startswith('irb.')
                else None,
            'peer_link': peer_link if iccp_peer else None,
            'peer_address': iccp_peer.peer_address if iccp_peer else None,
            # config consistency check is only support on qfx10000 as per
            # https://www.juniper.net/documentation/en_US/junos/topics/concept/mc-lag-config-consistency-check-understanding.html
            # For now just return 3 to indicate unknown/unsupported
            'config_sanity': 3,
        }))


def collector_plugin(_device):
    return MlagDomainCollector
