# Copyright 2018, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

import json
# pylint: disable=no-name-in-module
from distutils.version import LooseVersion as Version

from aosstdcollectors.compat.aos.sdk.system_agent.device import UNKNOWN_VERSION


def format_generic_value(aos_version, value):
    """ AOS 2.3 accepts generic collector to return value as a dictionary.
        For version < AOS 2.3, the value has to be a string. Utility function
        to take care of this behavior.
    """
    if Version(aos_version) < Version('2.3.0'):
        return json.dumps(value)
    return value


def to_extensible_postdata(collected_dict, global_value=None,
                           aos_version=UNKNOWN_VERSION):
    """
    This function transforms the given postdata dictionary
    into the JSON string required by the AOS framework for
    storing this content into the AOS server

    Parameters
    ----------
    collected_dict: dict
        The dictionary of data that the User wants to store
        in the AOS server

    Returns
    -------
    str
        The JSON-string version of the data structured in the
        way required by the AOS framework
    """
    postdata = list()

    if not isinstance(collected_dict, dict):
        raise TypeError('collected_dict must be a dict, instead got %s' %
                        type(collected_dict))

    def _to_native(_v):
        if _v is None or isinstance(_v, basestring):
            return _v
        if isinstance(_v, dict):
            return format_generic_value(aos_version, _v)
        return json.dumps(_v)

    for key, value in collected_dict.iteritems():
        postdata.append(dict(
            identity=key,
            value=_to_native(value)
        ))

    if global_value:
        return json.dumps({
            "items": postdata,
            "global": global_value
        })
    return json.dumps(dict(items=postdata))
