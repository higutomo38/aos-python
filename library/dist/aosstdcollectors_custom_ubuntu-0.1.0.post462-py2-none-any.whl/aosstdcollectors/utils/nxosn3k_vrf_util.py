# Copyright 2019-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

import re
from collections import defaultdict

MGMT_INTF_REGEX = re.compile('mgmt')


def read_vrfs(device):
    def build(vrf):
        role = 'data'
        if any(MGMT_INTF_REGEX.match(i) for i in intf_data[vrf['vrf_name']]):
            role = 'management'

        return {
            'rd': vrf['rd'],
            'interfaces': intf_data[vrf['vrf_name']],
            'role': role,
            'multicast_mode': 'enabled' if vrf['vrf_name'] in
                              pim_vrfs else 'disabled'
        }

    vrf_data = device.get_json(
        'show vrf detail').get('TABLE_vrf', {}).get('ROW_vrf', [])
    vrfs = [vrf.get('vrf_name') for vrf in vrf_data]

    intfs = device.get_json(
        'show vrf interface').get('TABLE_if', {}).get('ROW_if', [])
    intf_data = defaultdict(list)
    for i in intfs:
        intf_data[i.get('vrf_name')].append(i.get('if_name'))

    pim_vrfs = [
        vrf for vrf in vrfs
        if device.get_json('show ip pim rp vrf ' + vrf).get(
            'TABLE_vrf', {}).get('ROW_vrf')
    ]

    return {
        vrf['vrf_name']: build(vrf) for vrf in vrf_data
    }
