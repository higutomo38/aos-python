
# Copyright 2019-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.platform_independent import is_valid_mac_address
from aosstdcollectors.utils.junos_util import intf_name


class Dot1xCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(Dot1xCollector, self).__init__(*args, **kwargs)
        self._spec = None

    @property
    def spec(self):
        if self._spec:
            return self._spec

        self._spec = self.device.load_table_view_spec(
            {
                "Dot1xTable": {
                    "rpc": "get-dot1x-interface-information",
                    "item": "interface",
                    "key": "interface-name",
                    "view": "Dot1xTableView",
                },
                "Dot1xTableView": {
                    "fields": {
                        "interface_name": "interface-name",
                        "mac_address": "user-mac-address",
                        "state": "state",
                    }
                },
            }
        )
        return self._spec

    def collect(self):
        value_map = {
            'authenticated': 'authorized',
            'authenticating': 'blocked',
            'connecting': 'blocked',
            'held': 'blocked'
        }

        def get_auth_state(data):
            return value_map.get(data.state.lower(), 'blocked')

        def get_mac(data):
            return data.mac_address if is_valid_mac_address(data.mac_address) \
                else 'n/a'

        self.post_data([
            {
                'key': {
                    'interface': intf_name(data.interface_name),
                    'type': key_type
                },
                'value': {
                    'Auth': get_auth_state,
                    'Mac': get_mac
                }[key_type](data)
            }
            for data in self.device.create_table(self.spec['Dot1xTable']).get()
            for key_type in ['Auth', 'Mac']
        ])


def collector_plugin(_):
    return Dot1xCollector
