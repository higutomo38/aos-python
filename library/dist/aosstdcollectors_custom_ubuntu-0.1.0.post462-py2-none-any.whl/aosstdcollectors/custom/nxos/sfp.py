# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.data_util import to_extensible_postdata
from aosstdcollectors.utils.nxos_util import listify
from aosstdcollectors.utils.cisco_util import SFP_METRICS

METRIC_WITHIN_THRESHOLD = 1
METRIC_OUTSIDE_THRESHOLD = 2


class SfpCollector(BaseTelemetryCollector):
    def process(self, xcvr_output):
        def process_metric(info, lane_data):
            if not lane_data.get(info.value_field):
                return {}

            def evaluate_has_flag_output(matching_len):
                # per https://tinyurl.com/y5vaj6dl, *_flag fields in input uses +,
                # ++, -, -- to indicate high warn, high alarm, low warn and low alarm
                # respectively.
                input_flag_value_field = '%s_flag' % info.threshold_field_prefix
                if input_flag_value_field not in lane_data:
                    return None

                if len(lane_data[input_flag_value_field] or '') == matching_len:
                    return METRIC_OUTSIDE_THRESHOLD

                return METRIC_WITHIN_THRESHOLD

            return {
                info.output_field: lane_data[info.value_field],
                '%s_low_warn' % info.output_field: lane_data.get(
                    '%s_warn_lo' % info.threshold_field_prefix),
                '%s_high_warn' % info.output_field: lane_data.get(
                    '%s_warn_hi' % info.threshold_field_prefix),
                '%s_low_alarm' % info.output_field: lane_data.get(
                    '%s_alrm_lo' % info.threshold_field_prefix),
                '%s_high_alarm' % info.output_field: lane_data.get(
                    '%s_alrm_hi' % info.threshold_field_prefix),
                '%s_has_warn' % info.output_field: evaluate_has_flag_output(1),
                '%s_has_alarm' % info.output_field: evaluate_has_flag_output(2),
            }

        def process_intf(intf_data, lane_data):
            if intf_data.get('sfp') != 'present':
                return None, {}

            if lane_data and lane_data.get('lane_number'):
                intf_name = '%s/%s' % (
                    intf_data['interface'], lane_data['lane_number'])
            else:
                intf_name = intf_data['interface']

            output = {
                'media_type': intf_data.get('type'),
                'vendor_sn': intf_data.get('serialnum'),
            }

            if not lane_data:
                return intf_name, output

            metric_output = {
                k: v
                for info in SFP_METRICS
                if lane_data.get(info.value_field)
                for k, v in process_metric(info, lane_data).iteritems()
            }

            return intf_name, dict(metric_output, **output)

        return {
            '%s|%s' % (intf_name, intf_key): intf_value
            for intf_data in listify(xcvr_output.get('TABLE_interface', {}).get(
                'ROW_interface'))
            for lane_data in listify(intf_data.get('TABLE_lane', {}).get('ROW_lane'))
            for intf_name, intf_output in [process_intf(intf_data, lane_data)]
            if intf_name
            for intf_key, intf_value in intf_output.iteritems()
            if intf_value
        }

    def collect(self):
        self.post_data(to_extensible_postdata(self.process(self.device.get_json(
            'show interface transceiver detail'))))


def collector_plugin(device):
    return SfpCollector
