# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

import json
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.data_util import to_extensible_postdata
from aosstdcollectors.utils.nxos_util import get_interface_fullname


class MlagDomainCollector(BaseTelemetryCollector):
    def collect(self):
        try:
            info = self.device.get_json('show vpc')
        except RuntimeError:
            self.post_data(
                to_extensible_postdata({
                    'domain_id': None,
                    'system_id': None,
                    'domain_state': None,
                    'local_interface': None,
                    'local_interface_status': None,
                    'local_interface_vlan_id': None,
                    'peer_link': None,
                    'peer_link_status': None,
                    'peer_address': None,
                    'config_sanity': None,
                })
            )
            return

        domain_id = json.dumps(str(info["vpc-domain-id"]))
        self.post_data(to_extensible_postdata({
            'domain_id': domain_id,
            # TODO(Rags): Need to investigate finding a fabric-wide unique id
            'system_id': domain_id,
            'domain_state':
                1 if info["vpc-peer-status"] == 'peer-ok' else 2,
            'local_interface': get_interface_fullname(
                info.get("TABLE_peerlink", {}).get("ROW_peerlink", {})
                .get("peerlink-ifindex")),
            'local_interface_status': info.get("TABLE_peerlink", {}).get(
                "ROW_peerlink", {}).get("peer-link-port-state"),
            'local_interface_vlan_id':
                int(info.get("dual-active-excluded-vlans", 0)) or None,
            'peer_link': get_interface_fullname(
                info.get("TABLE_peerlink", {}).get("ROW_peerlink", {})
                .get("peerlink-ifindex")),
            'peer_link_status':
                1 if info["vpc-peer-keepalive-status"] == 'peer-alive' else 2,
            'config_sanity':
                1 if info["vpc-peer-consistency"] == 'consistent' else 2,
        }))


def collector_plugin(_device):
    return MlagDomainCollector
