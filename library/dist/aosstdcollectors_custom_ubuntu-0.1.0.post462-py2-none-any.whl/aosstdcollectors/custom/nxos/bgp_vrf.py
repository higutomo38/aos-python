# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.data_util import to_extensible_postdata
from aosstdcollectors.utils.nxos_util import build_bgp_neighbors
from aosstdcollectors.compat.aos.sdk.system_agent.device import \
    get_running_aos_version


class BgpVrfCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(BgpVrfCollector, self).__init__(*args, **kwargs)
        self.aos_version = get_running_aos_version()

    def _parse_bgp_neighbors(self, data, addr_family):
        neighbors = build_bgp_neighbors(data, addr_family)
        return {
            '%s_%s' % (neighbor['vrf_name'], neighbor['dest_ip']): {
                'source_asn': neighbor['source_asn'],
                'dest_ip': neighbor['dest_ip'],
                'dest_asn': neighbor['dest_asn'],
                'vrf': neighbor['vrf_name'],
                'value': neighbor['value']
            }
            for neighbor in neighbors
        }

    def collect(self):
        bgp_cmds = {
            'ipv4': 'show bgp ipv4 unicast summary vrf all',
            'ipv6': 'show bgp ipv6 unicast summary vrf all',
            'evpn': 'show bgp l2vpn evpn summary vrf all'
        }

        output = {}
        for addr_family, cmd in bgp_cmds.iteritems():
            try:
                cmd_output = self.device.get_json(cmd)
            except RuntimeError:
                # eapi returns cli error to 'show bgp l2vpn' when evpn not enabled
                pass
            else:
                parsed_data = self._parse_bgp_neighbors(cmd_output, addr_family)
                output.update(parsed_data)

        self.post_data(to_extensible_postdata(output, aos_version=self.aos_version))


def collector_plugin(_device):
    return BgpVrfCollector
