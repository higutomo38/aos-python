# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

import json
from pyeapi.eapilib import CommandError
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
import logging
logging.basicConfig(level=logging.DEBUG)
LOGGER = logging.getLogger('vxlan_vtep')


def process(intf_vxlan):
    def process_intf_vxlan_data():
        if intf_vxlan is None:
            return {'protocol_status': None}

        vxlan_detail = intf_vxlan['interfaces']['Vxlan1']
        if vxlan_detail is None:
            return {'protocol_status': None}

        def get_vlan_to_vni():
            return {
                'vlan=%s|vni=%s' % (vlan_id, vni['vni']): '1'
                for vlan_id, vni in vxlan_detail['vlanToVniMap'].iteritems()
            }

        def get_vlan_to_vtep():
            vlan_vtep = {}
            for vlan_id, vtep_info in vxlan_detail['vlanToVtepList'].iteritems():
                vtep_list = vtep_info['remoteVtepAddr']
                vlan_vtep['vlan=%s|vtep_count=%s' % (vlan_id, len(vtep_list))] = '1'
                vlan_vtep['vlan=%s|vteps' % vlan_id] = ','.join(sorted(vtep_list))
                for vtep_ip in vtep_list:
                    vlan_vtep['vlan=%s|vtep=%s' % (vlan_id, vtep_ip)] = '1'
            return vlan_vtep

        def vxlan_status_mapping(status):
            if status == 'down':
                return '2'
            if status == 'up':
                return '1'
            return None

        data = {
            'protocol_status': vxlan_status_mapping(
                vxlan_detail['lineProtocolStatus'])
        }
        data.update(get_vlan_to_vni())
        data.update(get_vlan_to_vtep())
        return data

    return {
        'items': [
            {
                'identity': key,
                'value': value
            }
            for key, value in process_intf_vxlan_data().iteritems()
        ]
    }


class VxlanInfoCollector(BaseTelemetryCollector):
    def collect(self):
        intf_vxlan = None
        try:
            intf_vxlan = self.device.get_json('show interfaces vxlan 1')
        except CommandError:
            LOGGER.warn("VXLAN is not setup on device.")
        self.post_data(
            json.dumps(
                process(intf_vxlan)
            )
        )


def collector_plugin(_device):
    return VxlanInfoCollector
