# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
import json


def process(info):
    return {
        'items': [
            {
                'identity': '%s_%s' % (vrf_info['vrfName'], peer_ip),
                'value': str(
                    1 if session_info.get('state', '') == 'Established' else 2)
            }
            for unicast in info.itervalues()
            for vrf in unicast.itervalues()
            for vrf_info in vrf.itervalues()
            if 'peers' in vrf_info
            for peer_ip, session_info in vrf_info['peers'].iteritems()
        ]
    }


class BgpIbaCollector(BaseTelemetryCollector):
    def collect(self):
        collected = self.device.get_json('sudo net show bgp vrf all summary json')
        self.post_data(json.dumps(process(collected)))


def collector_plugin(_device):
    return BgpIbaCollector
