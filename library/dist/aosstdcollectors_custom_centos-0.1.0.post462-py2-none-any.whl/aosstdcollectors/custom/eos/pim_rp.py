# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula


import json
import logging
from collections import defaultdict
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.eos_util import try_get_json
from aosstdcollectors.utils.eos_vrf_util import read_vrfs

LOG = logging.getLogger(__name__)


class PimRPCollector(BaseTelemetryCollector):
    def get_pim_rps_in_vrf(self, vrf):
        pim_data = try_get_json(self.device, 'show ip pim vrf ' + vrf + ' rp') \
            .get('sparseMode', {}).get('crpSet', {})

        rp_to_groups = defaultdict(list)
        for group, group_info in pim_data.iteritems():
            for crp in group_info.get('crp', {}):
                rp_to_groups[crp].append(group)

        return rp_to_groups

    def collect(self):
        '''For each VRF+RP, return list of groups in sorted order separated by comma
        '''
        vrfs = read_vrfs(self.device)
        self.post_data(json.dumps({
            'items': [
                {
                    'identity': '%s|%s|%s' % (vrf, rp, '|'.join(sorted(groups))),
                    'value': '1'
                }
                for vrf, vrf_info in vrfs.iteritems()
                if vrf_info['role'] != 'management' and
                vrf_info['multicast_mode'] == 'enabled'
                for rp, groups in self.get_pim_rps_in_vrf(vrf).iteritems()
            ]
        }))


def collector_plugin(_device):
    return PimRPCollector
