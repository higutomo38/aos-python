# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

# The collector will compute the delta rate per second of the dropped packets count
# between the current and previous output from show interfaces counters queue,
# and will produce a dictionary, where:
#     key = <if_name>|<counter_type>
#     value = dropped packets rate (round up if it has division) for unicast or
#             multicast per interface
#     counter_type: out_drop_uc_pkts, out_drop_mc_pkts
#     key = <if_name>|out_uc_and_mc_has_pkt_drops
#     value =
#        1: if both <if_name>|out_drop_uc_pkts, <if_name>|out_drop_uc_pkts are
#           non-zero
#        0: otherwise - this may mean no drops at all or drops in uc or mc
#     counter_type: out_drop_uc_pkts, out_drop_mc_pkts
#
# Certain eos platforms will return json output. The 7050 specifically, will
# return empty json output as of versions: 4.20.11M and 4.21.4F. In this
# case we will rely on processing the text output shown below.

import datetime
import math
from collections import defaultdict
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.data_util import to_extensible_postdata
from aosstdcollectors.utils.textparsing import TextFsmParser

# This template extracts 'Port', 'DestType' and 'OutDropPkts' columns from the text
# output of EOS command: show interfaces counters queue
# And format the data in a table as in the following example:
#
# Port               InDropPkts    OutUcDropPkts    OutMcDropPkts
# ---------------------------------------------------------------
# Et1                         0                0                0
# Et2                         0                0                0
template = r''' #TextFSM
Value Port ((\w+)(\d+)(/\d+)*)
Value OutUcDropPkts (\d+)
Value OutMcDropPkts (\d+)

Start
  ^Port -> TABLE

TABLE
  ^\s*${Port}\s+\d+\s+${OutUcDropPkts}\s+${OutMcDropPkts}\s* -> Record

EOF
'''

Buffer_parser = TextFsmParser(template)


def parse_buffer_text(collected):
    buffer_data = defaultdict(int)
    parsed_data = Buffer_parser.parse(collected)
    for intf_name, out_uc_drop_pkts, out_mc_drop_pkts in parsed_data:
        intf_name = normalize_interface_name(intf_name)
        uc_drop_pkts = int(out_uc_drop_pkts)
        mc_drop_pkts = int(out_mc_drop_pkts)

        key_uc_pkts = '{}|out_drop_uc_pkts'.format(intf_name)
        key_mc_pkts = '{}|out_drop_mc_pkts'.format(intf_name)

        buffer_data[key_uc_pkts] += uc_drop_pkts
        buffer_data[key_mc_pkts] += mc_drop_pkts
    return buffer_data


def normalize_interface_name(prev_intf_name):
    if 'Ethernet' in prev_intf_name:
        return prev_intf_name
    return prev_intf_name.replace('Et', 'Ethernet')


class InterfaceBufferCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(InterfaceBufferCollector, self).__init__(*args, **kwargs)
        self.prev_counters = {}
        self.prev_time_stamp = None

    def process(self, queue_counters):
        buffer_data = defaultdict(int)
        for intf_name, queue in queue_counters.get(
                'egressQueueCounters', {}).get('interfaces', {}).iteritems():
            for queue_type, traffic in queue.iteritems():
                if queue_type == 'mcastQueues':
                    key = '{}|out_drop_mc_pkts'.format(intf_name)
                else:
                    key = '{}|out_drop_uc_pkts'.format(intf_name)
                for tclass in traffic['trafficClasses'].itervalues():
                    for data in tclass['dropPrecedences'].itervalues():
                        buffer_data[key] += data['droppedPackets']
        return buffer_data

    def collect(self):
        cmd = 'show interfaces counters queue'
        if not self.prev_counters:
            queue_counters = self.device.get_json(cmd)
            if not queue_counters.get('egressQueueCounters').get('interfaces'):
                self.prev_counters = parse_buffer_text(self.device.get_text(cmd))
            else:
                self.prev_counters = self.process(queue_counters)
            self.prev_time_stamp = datetime.datetime.now()
            return

        queue_counters = self.device.get_json(cmd)
        if not queue_counters.get('egressQueueCounters').get('interfaces'):
            curr_counters = parse_buffer_text(self.device.get_text(cmd))
        else:
            curr_counters = self.process(self.device.get_json(cmd))
        curr_time_stamp = datetime.datetime.now()

        # calculates the delta dropped packets count for both unicast and
        # multicast per interface
        delta_time_secs = (curr_time_stamp - self.prev_time_stamp).total_seconds()
        delta_counters_rates = {
            key: max(0, int(math.ceil(
                (curr_counters[key] - self.prev_counters.get(key,
                                                             0)) / delta_time_secs)))
            for key in curr_counters}

        self.prev_counters = curr_counters
        self.prev_time_stamp = curr_time_stamp

        # using keys() here as we are adding entries to the dict while iterating
        for key in delta_counters_rates.keys():
            intf_name = key.split('|')[0]

            uc_and_mc_key = '{}|out_uc_and_mc_has_pkt_drops'.format(intf_name)
            if uc_and_mc_key in delta_counters_rates:
                continue

            uc_drop_rate = delta_counters_rates[
                '{}|out_drop_uc_pkts'.format(intf_name)]
            mc_drop_rate = delta_counters_rates[
                '{}|out_drop_mc_pkts'.format(intf_name)]

            delta_counters_rates[uc_and_mc_key] = '1' if (
                uc_drop_rate > 0 and mc_drop_rate > 0) else '0'

        self.post_data(to_extensible_postdata(delta_counters_rates))


def collector_plugin(device):
    return InterfaceBufferCollector
