# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

"""
Collector to check the state of anycast-rp on all devices
"""

import json
import logging
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.eos_util import try_get_json
from aosstdcollectors.utils.eos_vrf_util import read_vrfs

LOG = logging.getLogger(__name__)


class AnycastRPCollector(BaseTelemetryCollector):
    def get_anycast_rps_in_vrf(self, vrf):
        anycast_data = try_get_json(self.device,
                                    'show ip pim vrf ' + vrf + ' anycast-rp')
        anycast_rp = anycast_data.get('anycastRpAddrs', [])

        return {
            str(rp_address): {
                'anycast_peers': anycast_data.get('peerAddrs', [])
            }
            for rp_address in anycast_rp
        }

    def get_peers(self, vrfs):
        for vrf, vrf_info in vrfs.iteritems():
            vrf_multicast_enabled = (vrf_info['role'] != 'management' and
                                     vrf_info['multicast_mode'] == 'enabled')
            if vrf_multicast_enabled:
                rp_info = self.get_anycast_rps_in_vrf(vrf)
                for rp_address, data in rp_info.iteritems():
                    for peer_ip in data['anycast_peers']:
                        yield {
                            'identity': '%s|%s|peer|%s' % (vrf, rp_address, peer_ip),
                            'value': '1'
                        }
                    yield {
                        'identity': '%s|%s|peer_count' % (vrf, rp_address),
                        'value': str(len(data['anycast_peers']))
                    }

                yield {
                    'identity': '%s|rp_role' % vrf,
                    'value': str(1 if rp_info else 2)
                }

    def collect(self):
        vrfs = read_vrfs(self.device)
        self.post_data(json.dumps({
            'items': list(self.get_peers(vrfs))
        }))


def collector_plugin(_device):
    return AnycastRPCollector
