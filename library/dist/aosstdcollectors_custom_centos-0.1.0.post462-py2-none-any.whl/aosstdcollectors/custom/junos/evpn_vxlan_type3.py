# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

import re
import logging
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector


LOGGER = logging.getLogger(__name__)


class EvpnVxlanType3Collector(BaseTelemetryCollector):
    route_target_regex = re.compile(r"target:(\d+:\d+) encapsulation:vxlan")

    def __init__(self, *args, **kwargs):
        super(EvpnVxlanType3Collector, self).__init__(*args, **kwargs)
        self._spec = None

    @property
    def spec(self):
        if self._spec:
            return self._spec

        self._spec = self.device.load_table_view_spec(
            {
                "EvpnTable": {
                    "rpc": "get-route-information",
                    "args": {
                        "level": "extensive",   # 'Extensive' to fetch route target
                        "table": "bgp.evpn.0",  # Fetch data only from bgp.evpn.0
                    },
                    "item": "route-table/rt",
                    "key": "rt-destination",
                    "view": "RouteView",
                },
                "RouteView": {
                    "fields": {
                        "route_destination": "rt-destination",
                        "protocol_header": "tsi",   # 'tsi' tag get us route target
                    }
                },
            }
        )
        return self._spec

    def collect(self):
        def process_route(route):
            """Fetch rd, vni and next-hop from the string
            Input Format - type:rd::vni::nexthop
            Input Example - 3:10.0.0.2:65534::10000::10.0.0.2
            """
            rt = get_route_target(route.protocol_header)
            if not rt:
                LOGGER.info(
                    'Unable to read route_target for %s', route.protocol_header)
                return None

            split_text = route.route_destination.split(":")
            return {
                "rd": "{}:{}".format(split_text[1], split_text[2]),
                "vni": split_text[4],
                "nexthop": split_text[6],
                "route_target": rt
            }

        def get_route_target(protocol_header):
            """Fetch route target from TSI (Protocol header information) for VXLAN
            Input Example - Communities: target:10000:1 encapsulation:vxlan(0x8)

            Raise:
                AttributeError, if regex do not match (if encapsulation is not VXLAN)
            """
            try:
                return self.route_target_regex.search(protocol_header).group(1)
            except AttributeError:
                # Encapsulation is not vxlan, so no need to collect route info
                return None

        return self.post_data([
            {
                "key": route_key,
                "value": 1,
            }
            for route in self.device.create_table(self.spec["EvpnTable"]).get()
            if route.route_destination.startswith("3:")
            for route_key in [process_route(route)]
            if route_key
        ])


def collector_plugin(_):
    return EvpnVxlanType3Collector
