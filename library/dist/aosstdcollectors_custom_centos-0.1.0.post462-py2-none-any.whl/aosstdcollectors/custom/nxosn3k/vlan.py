# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula
import json

from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.compat.aos.sdk.system_agent.device import \
    get_running_aos_version
from aosstdcollectors.utils.data_util import format_generic_value


class VlanCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(VlanCollector, self).__init__(*args, **kwargs)
        self.aos_version = get_running_aos_version()

    def process_show_vlans(self, collected):
        vlans = collected['TABLE_vlanbrief']['ROW_vlanbrief']
        return [
            {
                'identity': vlan['vlanshowbr-vlanid'],
                'value': format_generic_value(self.aos_version, {
                    'vlan_id': int(vlan['vlanshowbr-vlanid']),
                    'name': vlan['vlanshowbr-vlanname'],
                    'interfaces':
                        vlan['vlanshowplist-ifidx'].split(',')
                })
            }
            for vlan in vlans
        ]

    def collect(self):
        show_vlans = self.device.get_json('show vlan')
        self.post_data(json.dumps({
            'items': self.process_show_vlans(show_vlans)
        }))


def collector_plugin(_device):
    """
    Collects information about all VLANs on a box
    """

    return VlanCollector
