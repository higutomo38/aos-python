# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

# This file contains an updated vrf collector that parses the vrf info from
# the running config which provides json output. The show vrf command is still
# an unconverted command and requires screen scraping with textfsm.


import datetime
import logging
import re
from aosstdcollectors.utils.eos_util import MGMT_INTF_PATTERN
from collections import defaultdict

LOG = logging.getLogger(__name__)

VRF_CACHE = {'data': {}, 'time': None}


def update_cache(cache_time, cache_data):
    VRF_CACHE['data'] = cache_data
    VRF_CACHE['time'] = cache_time


def read_vrfs(device, no_cache=False):
    def should_fetch():
        if no_cache or not VRF_CACHE['time']:
            return True
        return (datetime.datetime.now() - VRF_CACHE['time']).total_seconds() > 14400

    if should_fetch():
        LOG.info('Updating VRF_CACHE')
        update_cache(datetime.datetime.now(),
                     collect_vrfs(device.get_json('show running-config')))

    return VRF_CACHE['data']


def collect_vrfs(config):
    def get_intfs(vrfs):
        intf_re = re.compile('^interface (.*)$')
        vrf_re = re.compile('^vrf forwarding (.*)$')
        results = defaultdict(lambda: dict(interfaces=list(), role='data'))

        intf_name_to_key = {
            m.group(1): k for k in config['cmds']
            for m in [intf_re.match(k)]
            if m
        }
        intf_names = intf_name_to_key.keys()

        for intf_name, intf_key in intf_name_to_key.iteritems():
            for intf_cmd in config['cmds'][intf_key]['cmds']:
                vrf_match = vrf_re.match(intf_cmd)
                if vrf_match:
                    vrf = vrf_match.group(1)
                    results[vrf]['interfaces'].append(intf_name)
                    intf_names.remove(intf_name)
                    if MGMT_INTF_PATTERN.match(intf_name):
                        results[vrf]['role'] = 'management'

        # the intfs left belong to the default vrf
        results['default']['interfaces'] = intf_names
        return results

    def get_mcast_mode():
        mcast_mode = defaultdict(lambda: 'disabled')
        pim_vrf_re = re.compile('^vrf (.*)$')
        pim_default_vrf_re = re.compile('^ip pim rp-address')
        pim_config = config.get('cmds', {}).get('router pim sparse-mode', {})

        for pim_cmd in pim_config.get('cmds', {}):
            vrf_match = pim_vrf_re.match(pim_cmd)
            if vrf_match:
                vrf = vrf_match.group(1)
                mcast_mode[vrf] = 'enabled'
                continue
            if pim_default_vrf_re.match(pim_cmd):
                mcast_mode['default'] = 'enabled'
        return mcast_mode

    def get_vrfs():
        vrf_re = re.compile('^vrf definition (.*)$')
        rd_re = re.compile('^rd (.*)$')
        return {
            vrf_match.group(1): {
                'rd': rd_match.group(1)
            }
            for k, v in config['cmds'].iteritems()
            for vrf_match in [vrf_re.match(k)]
            if vrf_match
            for vrf_subcmd in v['cmds']
            for rd_match in [rd_re.match(vrf_subcmd)]
            if rd_match
        }

    vrfs = get_vrfs()
    vrfs['default'] = {'rd': ''}
    vrf_intfs = get_intfs(vrfs)  # keys include 'interfaces' and 'role'
    vrf_mcast_mode = get_mcast_mode()

    vrf_data = {
        k: {
            'rd': v['rd'],
            'multicast_mode': vrf_mcast_mode.get(k, 'disabled'),
            'role': vrf_intfs[k]['role'],
            'interfaces': vrf_intfs[k]['interfaces'],
        }
        for k, v in vrfs.iteritems()
    }

    return vrf_data
