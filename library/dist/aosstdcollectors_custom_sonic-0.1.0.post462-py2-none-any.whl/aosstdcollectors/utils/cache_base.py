# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

import datetime
import threading


class SingletonFactory(type):
    _instances = {}
    _lock = threading.Lock()

    def __call__(cls, *args, **kwargs):
        if cls not in cls._instances:
            with cls._lock:
                if cls not in cls._instances:
                    cls._instances[cls] = {
                        'args': args,
                        'kwargs': kwargs,
                        'instance': super(SingletonFactory,
                                          cls).__call__(*args, **kwargs)
                    }

        # assume the args and kwargs don't have custome objects
        if (args != cls._instances[cls]['args'] or
                kwargs != cls._instances[cls]['kwargs']):
            raise ValueError('Use SingletonFactory with different args or kwargs: '
                             'class %s, args (%s, %s), kwargs (%s, %s)' %
                             (cls, args, cls._instances[cls]['args'],
                              kwargs, cls._instances[cls]['kwargs']))

        return cls._instances[cls]['instance']


class CacheBase(object):
    ''' Base cache class for caching data

    Base cache provides singleton and helper function get_data() which will check if
    the data is still valid. If the data is outdated, user-defined
    fetch_data will be executed to get the new data.
    '''
    __metaclass__ = SingletonFactory

    def __init__(self):
        self.last_updated = None
        self.lock = threading.Lock()
        self.data = None

    def fetch_data(self):
        '''Fetch the data and return it. You MUST create new objects and not modify
        existing data'''
        raise NotImplementedError()

    def get_data(self, interval):
        with self.lock:
            if (not self.last_updated or
                    (datetime.datetime.now() - self.last_updated).seconds
                    >= interval):
                # this forces fetch_data to not depend on existing data
                self.data = None
                self.data = self.fetch_data()
                self.last_updated = datetime.datetime.now()

            # it is assumed for the data to be safe for reading outside the lock
            return self.data
