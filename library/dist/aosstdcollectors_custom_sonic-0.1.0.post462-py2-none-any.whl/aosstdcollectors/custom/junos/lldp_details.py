# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

from aosstdcollectors.utils.data_util import to_extensible_postdata
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.junos_util import is_management_interface
from aosstdcollectors.compat.aos.sdk.system_agent.device import \
    get_running_aos_version


class LldpDetailsCollector(BaseTelemetryCollector):
    """
    Extends LLDP collector by adding 2 attributes:
     - chassis_id
     - chassis_id_type
    """
    def __init__(self, *args, **kwargs):
        super(LldpDetailsCollector, self).__init__(*args, **kwargs)
        self.aos_version = get_running_aos_version()

    @property
    def lldp_neighbors_spec(self):
        return self.device.load_table_view_spec(
            {
                "LldpNeighborTable": {
                    "rpc": "get-lldp-neighbors-information",
                    "item": "lldp-neighbor-information",
                    "key": "lldp-local-port-id",
                    "view": "LldpNeighborView",
                },
                "LldpNeighborView": {
                    "fields": {
                        "interface_name": "lldp-local-port-id",
                        "neighbor_interface_name": "lldp-remote-port-id",
                        "neighbor_system_id": "lldp-remote-system-name",
                        "neighbor_chassis_id": "lldp-remote-chassis-id",
                        "neighbor_chassis_id_type": "lldp-remote-chassis-id-subtype",
                    }
                },
            }
        )

    def _lldp_info(self, lldp):
        def sys_description(_lldp):
            """The actual LLDP system description on Junos is only available by
            executing additional get-lldp-interface-neighbors RPC call per interface.
            Since LLDP collector is run every 10 seconds by default, switches
            often have several dozens of connected interfaces, and system description
            not being used in network discovery code in AOS CLI, it was decided
            to use combination of chassis ID type and chassis ID as system
            description to save resources."""
            return ": ".join(
                [_lldp.neighbor_chassis_id_type, _lldp.neighbor_chassis_id]
            )

        return {
            "interface_name": lldp.interface_name,
            "neighbor_interface_name": lldp.neighbor_interface_name,
            "neighbor_system_id": (
                lldp.neighbor_system_id or lldp.neighbor_chassis_id
            ),
            "sys_description": sys_description(lldp),
            "chassis_id": lldp.neighbor_chassis_id,
            "chassis_id_type": lldp.neighbor_chassis_id_type,
        }

    def collect(self):
        lldp_neighbors = self.device.create_table(
            self.lldp_neighbors_spec["LldpNeighborTable"]
        )

        items = {
            lldp.interface_name: self._lldp_info(lldp)
            for lldp in lldp_neighbors.get()
            if not is_management_interface(lldp.interface_name)
        }

        self.post_data(to_extensible_postdata(items, aos_version=self.aos_version))


def collector_plugin(_device):
    return LldpDetailsCollector
