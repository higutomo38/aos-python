# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.compat.aos.sdk.system_agent.device import \
    get_running_aos_version
from aosstdcollectors.utils.data_util import to_extensible_postdata
from aosstdcollectors.utils.junos_util import intf_name, vrf_name


class VrfCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(VrfCollector, self).__init__(*args, **kwargs)
        self._spec = None
        self._pim_rp_spec = None
        self.aos_version = get_running_aos_version()

    @property
    def spec(self):
        if self._spec:
            return self._spec

        self._spec = self.device.load_table_view_spec(
            {
                "RouteInstanceTable": {
                    "rpc": "get-instance-information",
                    "item": "instance-core",
                    "key": "instance-name",
                    "args": {"detail": True},
                    "view": "RouteInstanceView",
                },
                "RouteInstanceView": {
                    "fields": {
                        "instance_name": "instance-name",
                        "instance_type": "instance-type",
                        "rd": "instance-vrf/route-distinguisher",
                        "interfaces": "instance-interface/interface-name",
                    }
                },
            }
        )

        return self._spec

    @property
    def pim_rps_spec(self):
        if self._pim_rp_spec:
            return self._pim_rp_spec

        self._pim_rp_spec = self.device.load_table_view_spec(
            {
                "PimRpsInstanceTable": {
                    "rpc": "get-pim-rps-information",
                    "item": "rp-family",
                    "key": "address-family",
                    "view": "PimRpsInstanceView",
                },
                "PimRpsInstanceView": {
                    "fields": {
                        "address_family": "address-family",
                    }
                },
            }
        )
        return self._pim_rp_spec

    def collect(self):
        def applicable(_vrf):
            return _vrf.instance_type in ["evpn", "evpn-vpws", "virtual-router",
                                          "virtual-switch", "vrf"] \
                   or _vrf.instance_name in ["mgmt_junos", "master"]

        def interfaces(_vrf):
            if not _vrf.interfaces:
                return []
            if isinstance(_vrf.interfaces, basestring):
                return [intf_name(_vrf.interfaces)]
            return [
                intf_name(intf)
                for intf in _vrf.interfaces
            ]

        def multicast_mode(_vrf):
            if any(rp.address_family for rp in self.device.create_table(
                    self.pim_rps_spec["PimRpsInstanceTable"]).get(
                        instance=_vrf.instance_name)):
                return "enabled"
            return "disabled"

        def role(_vrf):
            # mgmt_junos is the default management route instance. See:
            # https://www.juniper.net/documentation/en_US/junos/topics/topic-map
            # /management-interface-in-non-default-instance.html
            if _vrf.instance_name == "mgmt_junos":
                return "management"
            return "data"

        items = {
            vrf_name(vrf.instance_name):
                {
                    "rd": vrf.rd,
                    "multicast_mode": multicast_mode(vrf),
                    "role": role(vrf),
                    "interfaces": interfaces(vrf),
                    "type": vrf.instance_type
                }
            for vrf in
            self.device.create_table(self.spec["RouteInstanceTable"]).get()
            if applicable(vrf)
        }

        self.post_data(to_extensible_postdata(items, aos_version=self.aos_version))


def collector_plugin(_):
    return VrfCollector
