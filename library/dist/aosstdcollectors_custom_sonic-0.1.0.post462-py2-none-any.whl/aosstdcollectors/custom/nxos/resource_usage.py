# Copyright 2019-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

from aosstdcollectors.custom.linux.resource_usage import ResourceUsageCollector


class NxosResourceUsageCollector(ResourceUsageCollector):
    def get_meminfo(self):
        if hasattr(self.device, 'get_bash'):
            return self.device.get_bash('cat /proc/meminfo', timeout=10)

        return self.device.get_text('run bash timeout 10 cat /proc/meminfo')

    def get_process_memory_usage(self):
        if hasattr(self.device, 'get_bash'):
            return self.device.get_bash(
                "grep  -h -E 'Name|Vm' /proc/*/status", timeout=10)

        return self.device.get_text(
            'run bash timeout 10 find /proc -maxdepth 2 -name status ' +
            '-execdir grep -E "Name|Vm" {} \\;')


def collector_plugin(_device):
    return NxosResourceUsageCollector
