# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
import re
import logging
from aosstdcollectors.utils.data_util import to_extensible_postdata, \
    format_generic_value
from aosstdcollectors.compat.aos.sdk.system_agent.device import \
    get_running_aos_version

LOG = logging.getLogger(__name__)


class EVPNType5Collector(BaseTelemetryCollector):

    def __init__(self, *args, **kwargs):
        super(EVPNType5Collector, self).__init__(*args, **kwargs)
        self.aos_version = get_running_aos_version()

    def collect(self):
        data = self.device.get_json(
            'show bgp l2vpn evpn route-type 5')

        if not data:
            self.post_data(
                to_extensible_postdata({}, aos_version=self.aos_version))
        # Some routes will be missing gateway on NXOS 9.2
        pattern = re.compile(
            r'\[5\]:'  # Route type
            r'\[0\]:'  # ESI ID
            r'\[0\]:'  # Ethernet tag ID
            r'\[(?P<prefix_len>\d+)\]:'
            r'\[(?P<subnet>.+?)\]:?'  # : is optional when gateway is not present
            r'(\[(?P<gateway>.+?)\])?'  # When not present, use gateway recursive
                                        # resolution. NXOS 9.2 workaround
            r'/(?P<field_len>\d+)'
        )  # noqa: E501 pylint: disable=line-too-long

        def get_subnet(prefix):
            match = re.match(pattern, prefix)
            if not match:
                LOG.warn('Could not parse prefix %s', prefix)
                return None, None
            network = '%s/%s' % (match.group('subnet'), match.group('prefix_len'))
            if int(match.group('field_len')) == 224:
                ip_version = 'ipv4'
            elif int(match.group('field_len')) == 416:
                ip_version = 'ipv6'
            else:
                return None, None
            return network, ip_version

        rd_rows = data.get('TABLE_vrf', {}).get('ROW_vrf', {}).\
            get('TABLE_afi', {}).get('ROW_afi', {}).get('TABLE_safi', {}).\
            get('ROW_safi', {}).get('TABLE_rd', {}).get('ROW_rd', [])
        vteps = {}

        def process_vtep(rd_data, prefix, prefix_item):
            # value = {
            #   'rd': rd_data['rd_val'],
            #    'vtep': get_prefix(prefix),
            #    'next_hops': get_hops(
            #        prefix_item.get('TABLE_path', {}).get('ROW_path'))
            # }
            subnet, ip_version = get_subnet(prefix)
            if not subnet:
                return
            identity = '%s|%s|%s' % (rd, ip_version, subnet)
            value = '1'
            vteps[identity] = format_generic_value(self.aos_version, value)

        for rd_data in rd_rows:
            rd = rd_data['rd_val']
            prefix_item = rd_data.get('TABLE_prefix', {}).get('ROW_prefix')

            if isinstance(prefix_item, dict):
                prefix = rd_data.get('TABLE_prefix').\
                    get('ROW_prefix').get('nonipprefix')
                process_vtep(rd_data, prefix, prefix_item)

            elif isinstance(prefix_item, list):
                for entry in prefix_item:
                    prefix = entry.get('nonipprefix')
                    process_vtep(rd_data, prefix, entry)

            else:
                raise ValueError('Invalid data type for %s' % prefix_item)

        self.post_data(to_extensible_postdata(vteps, aos_version=self.aos_version))


def collector_plugin(_device):
    return EVPNType5Collector

# EOF
