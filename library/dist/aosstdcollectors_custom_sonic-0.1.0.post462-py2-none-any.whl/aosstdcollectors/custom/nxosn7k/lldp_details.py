# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

import json
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.nxosn7k_util import get_value, get_tree, \
    MGMT_INTF_REGEX, normalize_intf_name
from aosstdcollectors.compat.aos.sdk.system_agent.device import \
    get_running_aos_version
from aosstdcollectors.utils.data_util import format_generic_value


# pylint: disable=anomalous-backslash-in-string
class LldpDetailCollector(BaseTelemetryCollector):
    """
    Extends built-in `lldp` collector with

     - chassis_id
     - chassis_id_type
    """
    def __init__(self, *args, **kwargs):
        super(LldpDetailCollector, self).__init__(*args, **kwargs)
        self.aos_version = get_running_aos_version()

    def process_lldp_neighbors(self, neighbors, nsmap):
        # some items will exist but not have LLDP neighbors, those are ignored to
        # match the onbox agent behavior

        return json.dumps({
            'items': [
                {
                    'identity': normalize_intf_name(nbor, nsmap, 'l_port_id'),
                    'value': format_generic_value(self.aos_version, {
                        'sys_description': '%s: %s' %
                                           (get_value(nbor, nsmap, 'chassis_type'),
                                            get_value(nbor, nsmap, 'chassis_id')),
                        'neighbor_system_id': get_value(nbor, nsmap, 'chassis_id'),
                        'chassis_id_type': get_value(nbor, nsmap, 'chassis_type'),
                        'neighbor_interface_name': normalize_intf_name(
                            nbor, nsmap, 'port_id'),
                        'chassis_id': get_value(nbor, nsmap, 'chassis_id'),
                        'interface_name': normalize_intf_name(
                            nbor, nsmap, 'l_port_id'),
                    })
                }
                for n in neighbors
                for nbor in n.xpath('.//aos:ROW_nbor', namespaces=nsmap)
                if not MGMT_INTF_REGEX.match(nbor.find('./aos:l_port_id',
                                                       nsmap).text)
            ]
        })

    def collect(self):
        lldp_nbors = self.device.get_text('show lldp neighbors | xml')
        tree, nsmap = get_tree(lldp_nbors)
        neighbors = tree.xpath('//aos:show/aos:lldp/aos:neighbors', namespaces=nsmap)
        self.post_data(self.process_lldp_neighbors(neighbors, nsmap))


def collector_plugin(_device):
    return LldpDetailCollector
