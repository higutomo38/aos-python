# Copyright 2019-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

import logging
import json
from collections import namedtuple
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.compat.aos.sdk.system_agent.device import \
    get_running_aos_version
from aosstdcollectors.utils.data_util import to_extensible_postdata
from aosstdcollectors.utils.nxosn7k_util import get_tree, get_value

LOGGER = logging.getLogger(__name__)


class PowerSupplyCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(PowerSupplyCollector, self).__init__(*args, **kwargs)
        self.aos_version = get_running_aos_version()

    def _get_power_supply_status(self, ps_info):
        row_psinfo = ps_info.ps_tree.xpath(
            '//aos:show//aos:powersup//aos:ROW_psinfo', namespaces=ps_info.ps_nsmap)

        for ps in row_psinfo:
            ps_status = get_value(ps, ps_info.ps_nsmap, 'ps_status')
            if ps_status != 'Ok':
                return 2
        return 1

    def _get_fan_status(self, ps_info):
        fan_info = ps_info.fan_tree.xpath(
            '//aos:show//aos:fandetails//aos:ROW_faninfo',
            namespaces=ps_info.fan_nsmap)

        for fan in fan_info:
            if get_value(fan, ps_info.fan_nsmap, 'fanname')\
             .strip().startswith('Fan_in_PS'):
                fan_status = get_value(fan, ps_info.fan_nsmap, 'fanstatus')
                if fan_status != 'Ok':
                    return 2
        return 1

    def _get_power_supply_count(self, ps_info):
        ps_count = 0
        row_psinfo = ps_info.ps_tree.xpath(
            '//aos:show//aos:powersup//aos:ROW_psinfo', namespaces=ps_info.ps_nsmap)

        for ps in row_psinfo:
            ps_status = get_value(ps, ps_info.ps_nsmap, 'ps_status')
            if ps_status != 'Absent':
                ps_count += 1
        return ps_count

    def _get_ps_fan_status(self, ps_info, psnum):
        fan_info = ps_info.fan_tree.xpath(
            '//aos:show//aos:fandetails//aos:ROW_faninfo',
            namespaces=ps_info.fan_nsmap)
        fanname = 'Fan_in_PS' + psnum

        for fan in fan_info:
            if get_value(fan, ps_info.fan_nsmap, 'fanname')\
             .strip() == fanname:
                return get_value(fan, ps_info.fan_nsmap, 'fanstatus')

        LOGGER.warn('cannot get fanstatus')
        return None

    def _get_ps_info(self, ps_info):
        row_psinfo = ps_info.ps_tree.xpath(
            '//aos:show//aos:powersup//aos:ROW_psinfo', namespaces=ps_info.ps_nsmap)

        # n7k doesn not provide uptime, airflow, odm_manufacturer
        # or temp_sensors info
        return {
            get_value(ps, ps_info.ps_nsmap, 'psnum'): {
                'status': get_value(ps, ps_info.ps_nsmap, 'ps_status'),
                'input_power': get_value(ps, ps_info.ps_nsmap, 'tot_capa').strip(),
                'output_power': get_value(
                    ps, ps_info.ps_nsmap, 'actual_out').strip(),
                'model_number': get_value(ps, ps_info.ps_nsmap, 'psmodel'),
                'fan_status': self._get_ps_fan_status(
                    ps_info, get_value(ps, ps_info.ps_nsmap, 'psnum'))
            }
            for ps in row_psinfo
        }

    def process_show_env(self, ps_info):
        # Publishing summary values since IBA cannot ingest telemetry
        # from unknown keys, and we don't have power-supply related info
        # available in the blueprint.
        return {
            'power_supply_status': self._get_power_supply_status(ps_info),
            'power_supply_fan_status': self._get_fan_status(ps_info),
            # n7k does not provide PS temperature info
            'power_supply_temperature_status': 0,
            'power_supply_count': self._get_power_supply_count(ps_info),
            'power_supply_info': json.dumps(
                self._get_ps_info(ps_info), indent=2, sort_keys=True),
        }

    def collect(self):
        ps_info = namedtuple('ps_info', 'ps_tree ps_nsmap \
            fan_tree fan_nsmap inv_tree inv_nsmap')
        ps_info.ps_tree, ps_info.ps_nsmap = get_tree(
            self.device.get_text('show environment power detail | xml'))
        ps_info.fan_tree, ps_info.fan_nsmap = get_tree(
            self.device.get_text('show environment fan | xml'))
        ps_info.inv_tree, ps_info.inv_nsmap = get_tree(
            self.device.get_text('show inventory power_supply | xml'))

        self.post_data(to_extensible_postdata(
            self.process_show_env(ps_info)
        ))


def collector_plugin(_device):
    return PowerSupplyCollector
