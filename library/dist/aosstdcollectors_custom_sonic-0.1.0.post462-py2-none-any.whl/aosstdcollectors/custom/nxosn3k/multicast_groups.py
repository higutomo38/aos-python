# Copyright 2019-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

"""
Collector to check the number of sources per group
"""

import re
import json
import logging
from collections import defaultdict
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.nxosn3k_vrf_util import read_vrfs
from aosstdcollectors.compat.aos.sdk.system_agent.device import \
    get_running_aos_version

LOG = logging.getLogger(__name__)
SG_REGEX = re.compile(r'\((\d+\.\d+\.\d+\.\d+).*,\s+(\d+\.\d+\.\d+\.\d+).*')


class MulticastGroupsCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(MulticastGroupsCollector, self).__init__(*args, **kwargs)
        self.aos_version = get_running_aos_version()

    def get_groups(self, vrf):
        def _get_sg(elem):
            sg = SG_REGEX.match(elem.get('mcast-addrs'))
            if sg:
                return {
                    'source': sg.group(1),
                    'group': sg.group(2)
                }
            return None

        sg_data = self.device.get_json('show ip mroute vrf ' + vrf)[
            'TABLE_vrf']['ROW_vrf'][0]['TABLE_one_route']['ROW_one_route']

        groups = defaultdict(lambda: dict(sources=list()))
        for elem in sg_data:
            sg = _get_sg(elem)
            if sg is not None:
                groups[sg['group']]['sources'].append(sg['source'])

        groups_by_source_count = defaultdict(list)
        for group, group_data in groups.iteritems():
            groups_by_source_count[len(group_data['sources'])].append(group)

        return {
            'groups': groups,
            'groups_by_source_count': groups_by_source_count,
        }

    def collect(self):
        self.post_data(json.dumps({
            'items': [
                {
                    'identity': vrf,
                    'value': json.dumps(
                        self.get_groups(vrf), indent=2, sort_keys=True)
                }
                for vrf, vrf_info in read_vrfs(self.device).iteritems()
                if vrf_info['role'] != 'management' and
                vrf_info['multicast_mode'] == 'enabled'
            ]
        }, sort_keys=True))


def collector_plugin(_device):
    return MulticastGroupsCollector
