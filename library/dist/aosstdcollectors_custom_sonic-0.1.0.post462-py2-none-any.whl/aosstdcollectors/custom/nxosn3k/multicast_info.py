# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula


"""
Collector used for multicast discovery
"""

import json
import logging
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.nxosn3k_vrf_util import read_vrfs
from aosstdcollectors.compat.aos.sdk.system_agent.device import \
    get_running_aos_version
from aosstdcollectors.utils.data_util import format_generic_value

LOG = logging.getLogger(__name__)


class MulticastInfoCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(MulticastInfoCollector, self).__init__(*args, **kwargs)
        self.aos_version = get_running_aos_version()

    def get_multicast_config(self, vrf):
        rp_info = self.device.get_json(
            'show ip pim rp vrf ' + vrf).get('TABLE_vrf', {}).get('ROW_vrf', [])

        if rp_info:
            anycast_rp = rp_info[0].get('TABLE_anycast_rp', {})\
                .get('ROW_anycast_rp', {})[0].get('anycast-rp-addr')
            anycast_peers = rp_info[0].get('TABLE_anycast_rp', {})\
                .get('ROW_anycast_rp', {})[0].get('TABLE_arp_rp', {})\
                .get('ROW_arp_rp', [])
            rps = rp_info[0].get('TABLE_rp', {}).get('ROW_rp', [])

        def get_group_mode(is_bidir):
            if is_bidir == 'TRUE':
                return 'bidir'

            return 'pim-sparse'

        return {
            # we currently support a single anycast-rp for the entire group
            # range: 224.0.0.0/4
            'sparse_mode': {
                'groups': {
                    '%s/%s' % (
                        rp['TABLE_grange']['ROW_grange'][0]['grange-grp'],
                        rp['TABLE_grange']['ROW_grange'][0]['grange-masklen']
                        ): {
                            'mode': get_group_mode(
                                rp['TABLE_grange']['ROW_grange'][0]['is-bidir-grp']),
                            'rps': {
                                anycast_rp: {
                                    # version 7.0.(3)I7(6) no longer has the
                                    # is-rp-static field available
                                    'discovery_mode': 'static'
                                    }
                            },
                        }
                },
                'anycast_rps': [
                    anycast_rp
                ],
                'anycast_peers': [
                    r['arp-rp-addr'] for r in anycast_peers if 'arp-rp-addr' in r
                ]
            }
            for rp in rps
        }

    def collect(self):
        vrfs = read_vrfs(self.device)
        self.post_data(json.dumps({
            'items': [
                {
                    'identity': vrf,
                    'value': format_generic_value(self.aos_version,
                                                  self.get_multicast_config(vrf))
                }
                for vrf, vrf_info in vrfs.iteritems()
                if vrf_info['role'] != 'management' and
                vrf_info['multicast_mode'] == 'enabled'
            ]
        }))


def collector_plugin(_device):
    return MulticastInfoCollector
