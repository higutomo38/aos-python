# Copyright 2018, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

import re
from netaddr import IPNetwork
from netaddr.core import AddrFormatError


DEFAULT_VRF_NAME = "default"


def valid_ipv4_addr(ip):
    try:
        IPNetwork(ip, version=4)
        return True
    except AddrFormatError:
        return False


def split_ip_prefix_len(ip, version=4):
    nw = IPNetwork(ip, version=version)
    return str(nw.ip), str(nw.prefixlen)


def is_valid_mac_address(address):
    mac_address_format = re.compile(r'^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})|'
                                    '([0-9A-Fa-f]{4}[.]){2}([0-9A-Fa-f]{4})$')

    if mac_address_format.match(address) is None:
        return False
    return True
