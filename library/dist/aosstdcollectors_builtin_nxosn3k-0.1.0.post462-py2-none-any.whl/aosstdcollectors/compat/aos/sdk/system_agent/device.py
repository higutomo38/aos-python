#! /usr/bin/python
# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

import re
from aos.sdk.system_agent.device import Device

UNKNOWN_VERSION = "0.0"

if hasattr(Device, 'get_device_aos_version_number'):
    get_running_aos_version = Device.get_device_aos_version_number
else:
    def get_running_aos_version():
        try:
            with open('/etc/aos/version') as fd:
                version_info = fd.read()
        except IOError:
            return UNKNOWN_VERSION

        try:
            match = re.search(r'%s=(\S+)' % re.escape('VERSION'), version_info)
            return match.group(1)
        except AttributeError:
            return UNKNOWN_VERSION
