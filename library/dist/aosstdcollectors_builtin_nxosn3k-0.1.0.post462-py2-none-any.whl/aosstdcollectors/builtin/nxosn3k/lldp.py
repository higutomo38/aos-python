# Copyright 2019-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula


import json
import re
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.textparsing import TextFsmParser
from aosstdcollectors.compat.aos.sdk.system_agent.device import \
    get_running_aos_version
from collections import namedtuple
from aosstdcollectors.utils.cisco_util import convert_mac_address
from aosstdcollectors.utils.platform_independent import is_valid_mac_address

MGMT_INTF_REGEX = re.compile('mgmt')
ETH_REGEX = re.compile(r'Eth(\d+\/.*$)')

template = r''' #TextFSM
Value Required CHASSIS_ID (\w+?\.\w+?\.\w+?)
Value Required NEIGHBOR_INTERFACE (\S+)
Value Required LOCAL_INTERFACE (\S+)
Value Required NEIGHBOR (\S+)
Value Required SYSTEM_DESCRIPTION (.*)

Start
  ^[Cc]hassis\s[idID]{2}\:\s${CHASSIS_ID}$$
  ^[Pp]ort\s[idID]{2}\:\s${NEIGHBOR_INTERFACE}$$
  ^[Ll]ocal\s[Pp]ort\s[idID]{2}\:\s${LOCAL_INTERFACE}$$
  ^[Ss]ystem\s[Nn]ame\:\s${NEIGHBOR}$$
  ^[Ss]ystem\s[Dd]escription\:\s${SYSTEM_DESCRIPTION}$$ -> Record

EOF
'''

lldp_buffer = TextFsmParser(template)


def normalize_intf_name(intf_name, sys_description):
    intf_match = ETH_REGEX.match(intf_name)
    if intf_match and sys_description.startswith('Cisco'):
        return 'Ethernet%s' % intf_match.group(1)

    return intf_name


class LldpCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(LldpCollector, self).__init__(*args, **kwargs)
        self.aos_version = get_running_aos_version()

    def process_lldp_neighbors(self, lldp_data):
        lldp_data = lldp_buffer.parse(lldp_data)
        lldp_cols = namedtuple('lldp_cols', lldp_buffer.headers)

        return json.dumps({
            'items': [
                {
                    'chassis_id':
                        convert_mac_address(row.CHASSIS_ID)
                        if is_valid_mac_address(convert_mac_address(row.CHASSIS_ID))
                        else '',
                    'sys_description': row.SYSTEM_DESCRIPTION,
                    'neighbor_system_id': row.NEIGHBOR,
                    'neighbor_interface_name': normalize_intf_name(
                        row.NEIGHBOR_INTERFACE, row.SYSTEM_DESCRIPTION),
                    'interface_name': normalize_intf_name(
                        row.LOCAL_INTERFACE, row.SYSTEM_DESCRIPTION)
                }
                for row in [lldp_cols(*data) for data in lldp_data]
                if not MGMT_INTF_REGEX.match(row.LOCAL_INTERFACE)
            ]
        })

    def collect(self):
        lldp_data = self.device.get_text('show lldp neighbors detail')
        self.post_data(self.process_lldp_neighbors(lldp_data))


def collector_plugin(_device):
    return LldpCollector
