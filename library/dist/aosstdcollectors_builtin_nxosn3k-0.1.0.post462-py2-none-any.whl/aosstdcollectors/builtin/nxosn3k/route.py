# Copyright 2019-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

import json
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from netaddr import IPNetwork


class RouteCollector(BaseTelemetryCollector):

    def _process_routes(self, data):
        def get_route_type(nexthop):
            # the n3k route data we have has types: direct, local, ospf-1
            # the schema only supports: 'unknown', 'direct', 'bgp', 'stat'
            route_types = {
                'local': 'direct',
                'direct': 'direct',
                'ospf-1': 'unknown'
            }
            client_name = nexthop['clientname']
            if 'bgp' in client_name:
                route_type = 'bgp'
            # TODO(mhutt): The onbox collector is checking for 'stat' instead of
            # static. Currently, we don't have output with static routes or
            # unknown routes; hence following what was implemented in cisco on box
            # collector and EOS off box collector.
            elif 'stat' in client_name:
                route_type = 'stat'
            else:
                route_type = route_types.get(client_name, 'unknown')
            return route_type

        def make_nexthop_item(nexthop):
            nexthop_addr = nexthop['ipnexthop']
            nexthop_info = None
            if nexthop_addr:
                nexthop_info = {
                    'prefix': nexthop_addr,
                    # show ip route has an ip address for nexthop
                    # without prefix length; hence setting prefix len as
                    # 32, as the nexthop always will be a host route.
                    'prefix_len': '32',
                    'tag': nexthop['ifname'],
                    'type': get_route_type(nexthop),
                    # show ip route doesn't have nexthop status.
                    # The EOS collector is setting status as up and
                    # hence we are following the same here.
                    'status': 'up'
                }
            return nexthop_info

        def get_nexthops(prefix):
            nexthops = prefix.get('TABLE_path', {}).get('ROW_path', [])
            return [
                nh
                for nh in (make_nexthop_item(item) for item in nexthops)
                if nh is not None
            ]

        def get_route(prefix):
            value = prefix['ipprefix']
            if value:
                ipprefix = IPNetwork(value)
                route = {
                    'prefix': str(ipprefix.ip),
                    'prefix_len': str(ipprefix.prefixlen),
                    'next_hops': get_nexthops(prefix)
                }
                # There is no route status in "show ip route". EOS offbox
                # collector is setting route_status to 'up' if next hops
                # doesn't exist, hence following the same here.
                if route['next_hops']:
                    route['route_status'] = 'up'
                    return route
            return None

        afs = data['TABLE_vrf']['ROW_vrf'][0]['TABLE_addrf']['ROW_addrf']
        routes = [
            get_route(row_prefix)
            for af in afs
            for row_prefix in af['TABLE_prefix']['ROW_prefix']
            # TODO(mhutt): need to support ipv6 once ipv6 dumps are available
            if af['addrf'] == 'ipv4'
        ]
        routes = [r for r in routes if r is not None]
        return json.dumps({
            'items': routes
        })

    def collect(self):
        data = self.device.get_json('show ip route')
        self.post_data(self._process_routes(data))


def collector_plugin(_device):
    return RouteCollector
