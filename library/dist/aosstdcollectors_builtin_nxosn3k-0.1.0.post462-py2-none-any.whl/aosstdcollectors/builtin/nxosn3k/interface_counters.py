# Copyright 2019-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula


import json
import datetime
import math
import collections
import copy
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector

RATE_INTERVAL_IN_SECONDS = 5


class InterfaceCounterRateCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(InterfaceCounterRateCollector, self).__init__(*args, **kwargs)
        self._prev_data = None
        self._prev_timestamp = None
        self._curr_data = collections.defaultdict(dict)
        self._delta_secs = 0

    def _update_counter(self, element, intf_name, interface, counter):
        # create intf_name key even when val is None
        intf_data = self._curr_data[intf_name]
        val = interface.get(element)
        if val is not None:
            if isinstance(val, (str, unicode)):
                intf_data[counter] = long(val)
            elif isinstance(val, list):
                intf_data[counter] = long(val[1]) - long(val[0])

    def _parse_counters(self):
        counters = self.device.get_json('show interface counters')
        errors = self.device.get_json('show interface counters errors')

        def parse_rx_counters():
            interfaces = counters['TABLE_rx_counters']['ROW_rx_counters']

            def update_curr_data(interface):
                intf_name = interface.get('interface_rx')
                if intf_name:
                    self._update_counter('eth_inucast',
                                         intf_name, interface,
                                         'rx_unicast_packets')
                    self._update_counter('eth_inbcast',
                                         intf_name, interface,
                                         'rx_broadcast_packets')
                    self._update_counter('eth_inmcast',
                                         intf_name, interface,
                                         'rx_multicast_packets')
                    self._update_counter('eth_inbytes',
                                         intf_name, interface, 'rx_bytes')

            map(update_curr_data, interfaces)

        def parse_tx_counters():
            interfaces = counters['TABLE_tx_counters']['ROW_tx_counters']

            def update_curr_data(interface):
                intf_name = interface.get('interface_tx')
                if intf_name:
                    self._update_counter('eth_outucast',
                                         intf_name, interface,
                                         'tx_unicast_packets')
                    self._update_counter('eth_outbcast',
                                         intf_name, interface,
                                         'tx_broadcast_packets')
                    self._update_counter('eth_outmcast',
                                         intf_name, interface,
                                         'tx_multicast_packets')
                    self._update_counter('eth_outbytes',
                                         intf_name, interface,
                                         'tx_bytes')

            map(update_curr_data, interfaces)

        def parse_errors():

            interfaces = errors['TABLE_interface']['ROW_interface']

            def update_curr_data(interface):
                intf_name = interface.get('interface')
                if intf_name:
                    self._update_counter('eth_rcv_err',
                                         intf_name, interface,
                                         'rx_error_packets')
                    self._update_counter('eth_xmit_err',
                                         intf_name, interface,
                                         'tx_error_packets')

                    self._update_counter('eth_outdisc',
                                         intf_name, interface,
                                         'tx_discard_packets')
                    self._update_counter('eth_align_err',
                                         intf_name, interface,
                                         'alignment_errors')
                    self._update_counter('eth_fcs_err',
                                         intf_name, interface,
                                         'fcs_errors')
                    self._update_counter('eth_symbol_err',
                                         intf_name, interface,
                                         'symbol_errors')
                    self._update_counter('eth_runts',
                                         intf_name, interface,
                                         'runts')
                    self._update_counter('eth_giants',
                                         intf_name, interface,
                                         'giants')
            map(update_curr_data, interfaces)

        parse_rx_counters()
        parse_tx_counters()
        parse_errors()

    def _process(self):

        def data(intf_name):
            curr_intf_data = self._curr_data[intf_name]
            prev_intf_data = self._prev_data.get(intf_name, {})

            def rate(counter_name):
                value = curr_intf_data.get(counter_name, 0)
                prev_value = prev_intf_data.get(counter_name, 0)
                if value <= prev_value:
                    # this can happen when counters are reset
                    return 0L
                # IBA and other parts of AOS assume counters are expressed in rate
                # per 5 seconds
                return long(math.ceil(((value - prev_value) / self._delta_secs)
                                      * RATE_INTERVAL_IN_SECONDS))

            return {
                'interface_name': intf_name,
                'rx_unicast_packets': rate('rx_unicast_packets'),
                'rx_broadcast_packets': rate('rx_broadcast_packets'),
                'rx_multicast_packets': rate('rx_multicast_packets'),
                'rx_error_packets': rate('rx_error_packets'),
                'rx_discard_packets': 0,
                'rx_bytes': rate('rx_bytes'),
                'tx_unicast_packets': rate('tx_unicast_packets'),
                'tx_broadcast_packets': rate('tx_broadcast_packets'),
                'tx_multicast_packets': rate('tx_multicast_packets'),
                'tx_error_packets': rate('tx_error_packets'),
                'tx_discard_packets': rate('tx_discard_packets'),
                'tx_bytes': rate('tx_bytes'),
                'alignment_errors': rate('alignment_errors'),
                'fcs_errors': rate('fcs_errors'),
                'symbol_errors': rate('symbol_errors'),
                'runts': rate('runts'),
                'giants': rate('giants'),
            }

        self.post_data(
            json.dumps({
                'items': [
                    data(intf_name)
                    for intf_name in self._curr_data
                    # new interfaces (ex: port-channels, port breakouts) can get
                    # added dynamically. We need at-least a baseline to publish a
                    # rate
                    if intf_name in self._prev_data
                ],
                'delta_seconds': RATE_INTERVAL_IN_SECONDS
            })
        )

    def collect(self):
        self._parse_counters()
        timestamp = datetime.datetime.now()

        if not self._prev_timestamp:
            self._prev_data = copy.deepcopy(self._curr_data)
            self._prev_timestamp = timestamp
            return

        self._delta_secs = (timestamp - self._prev_timestamp).seconds

        self._process()

        self._prev_data = copy.deepcopy(self._curr_data)
        self._prev_timestamp = timestamp


def collector_plugin(_device):
    return InterfaceCounterRateCollector
