# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula
import json
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.echo_util import get_none_for_empty_string


class BgpCollector(BaseTelemetryCollector):
    def collect(self):
        input_tac_json = json.loads(self.service_config.input) \
            if self.service_config.input else {}

        self.post_data(json.dumps({
            'items': [
                {
                    'source_ip': get_none_for_empty_string(
                        entry['session']['sourceIp']),
                    'source_asn': entry['session']['sourceAsn'],
                    'dest_ip': entry['session']['destIp'],
                    'dest_asn': entry['session']['destAsn'],
                    # to allow for pre-2.2 show-tech to load into 2.2 and above
                    'vrf_name': entry['session'].get('vrfName', 'default'),
                    'addr_family': entry['session'].get('addrFamily', 'ipv4'),
                    'value': entry['value'],
                }
                for entry in input_tac_json.get('state', {}).itervalues()
            ]
        }))


def collector_plugin(_device):
    return BgpCollector
