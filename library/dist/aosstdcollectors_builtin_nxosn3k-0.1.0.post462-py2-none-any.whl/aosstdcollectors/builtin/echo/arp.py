# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula
import json
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.echo_util import build_mac


class ArpCollector(BaseTelemetryCollector):
    def collect(self):
        input_tac_json = json.loads(self.service_config.input) \
            if self.service_config.input else {}

        self.post_data(json.dumps({
            'items': [
                {
                    'ip_address': entry.get(
                        'ipAddress', entry['arpKey']['ipAddress']),
                    'mac_address': build_mac(entry['macAddress']),
                    'interface_name': entry['l3IntfName'],
                    'type': entry['type'],
                    'l2_info': entry['l2Info'],
                    # to allow for pre-2.2 show-tech to load into 2.2 and above
                    'vrf_name': entry.get(
                        'vrf_name', entry['arpKey'].get('vrf_name', 'default')),
                }
                for entry in input_tac_json.get('entry', {}).itervalues()
            ]
        }))


def collector_plugin(_device):
    return ArpCollector
