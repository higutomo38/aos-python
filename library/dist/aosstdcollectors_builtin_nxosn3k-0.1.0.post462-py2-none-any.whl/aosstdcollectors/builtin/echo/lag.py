# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula
import json
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector


class LagCollector(BaseTelemetryCollector):
    def collect(self):
        input_tac_json = json.loads(self.service_config.input) \
            if self.service_config.input else {}

        self.post_data(json.dumps({
            'items': [
                {
                    'lag_name': entry['lagName'],
                    'value': entry['value'],
                    'interfaces': [
                        {
                            'interface_name': member['intfName'],
                            'value': member['value'],
                        }
                        for member in entry['memberState'].itervalues()
                    ],
                }
                for entry in input_tac_json.get('lagChannel', {}).itervalues()
            ]
        }))


def collector_plugin(_device):
    return LagCollector
