# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula
import json
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.echo_util import get_none_for_empty_string


class MlagCollector(BaseTelemetryCollector):
    def collect(self):
        input_tac_json = json.loads(self.service_config.input) \
            if self.service_config.input else {}

        self.post_data(json.dumps({
            'mlag_global': {
                'domain_id': input_tac_json['state']['domainId'],
                'domain_state': input_tac_json['state']['domainState'],
                'local_interface': get_none_for_empty_string(
                    input_tac_json['state']['localInterface']),
                'local_intf_status': get_none_for_empty_string(
                    input_tac_json['state']['localIntfStatus']),
                'peer_link': get_none_for_empty_string(
                    input_tac_json['state']['peerLink']),
                'peer_link_status': get_none_for_empty_string(
                    input_tac_json['state']['peerLinkStatus']),
                'peer_address': get_none_for_empty_string(
                    input_tac_json['state']['peerAddress']),
                'config_sanity': get_none_for_empty_string(
                    input_tac_json['state']['configSanity']),
            } if input_tac_json.get('state') else None,
            'mlag_interface': [
                {
                    'intf_name': entry['pairName'],
                    'mlag_id': entry['mlagId'],
                    'intf_state': entry['mlagIntfState'],
                }
                for entry in input_tac_json.get('mlagIntfEntry', {}).itervalues()
            ]
        }))


def collector_plugin(_device):
    return MlagCollector
