# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula


import json
import datetime
import math
import collections
import copy
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.nxosn7k_util import get_tree, get_value


RATE_INTERVAL_IN_SECONDS = 5


class InterfaceCounterRateCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(InterfaceCounterRateCollector, self).__init__(*args, **kwargs)
        self._prev_data = None
        self._prev_timestamp = None
        self._curr_data = collections.defaultdict(dict)
        self._delta_secs = 0

    def _update_counter(self, tree, nsmap, element, intf_name, counter):
        val = get_value(tree, nsmap, element)
        # create intf_name key even when val is None
        intf_data = self._curr_data[intf_name]
        if val is not None:
            intf_data[counter] = long(val)

    def _parse_counters(self):
        counters = self.device.get_text('show interface counters | xml')
        errors = self.device.get_text('show interface counters errors | xml')

        def parse_rx_counters():
            tree, nsmap = get_tree(counters)
            interfaces = tree.xpath('//aos:ROW_rx_counters', namespaces=nsmap)

            def update_curr_data(interface):
                intf_name = get_value(interface, nsmap, 'interface_rx')
                if intf_name:
                    self._update_counter(interface, nsmap, 'eth_inucast',
                                         intf_name, 'rx_unicast_packets')
                    self._update_counter(interface, nsmap, 'eth_inbcast',
                                         intf_name, 'rx_broadcast_packets')
                    self._update_counter(interface, nsmap, 'eth_inmcast',
                                         intf_name, 'rx_multicast_packets')
                    self._update_counter(interface, nsmap, 'eth_inbytes',
                                         intf_name, 'rx_bytes')

            map(update_curr_data, interfaces)

        def parse_tx_counters():
            tree, nsmap = get_tree(counters)
            interfaces = tree.xpath('//aos:ROW_tx_counters', namespaces=nsmap)

            def update_curr_data(interface):
                intf_name = get_value(interface, nsmap, 'interface_tx')
                if intf_name:
                    self._update_counter(interface, nsmap, 'eth_outucast',
                                         intf_name, 'tx_unicast_packets')
                    self._update_counter(interface, nsmap, 'eth_outbcast',
                                         intf_name, 'tx_broadcast_packets')
                    self._update_counter(interface, nsmap, 'eth_outmcast',
                                         intf_name, 'tx_multicast_packets')
                    self._update_counter(interface, nsmap, 'eth_outbytes',
                                         intf_name, 'tx_bytes')

            map(update_curr_data, interfaces)

        def parse_errors():
            tree, nsmap = get_tree(errors)
            interfaces = tree.xpath('//aos:ROW_interface', namespaces=nsmap)

            def update_curr_data(interface):
                intf_name = get_value(interface, nsmap, 'interface')
                if intf_name:
                    self._update_counter(interface, nsmap, 'eth_rcv_err',
                                         intf_name, 'rx_error_packets')
                    self._update_counter(interface, nsmap, 'eth_xmit_err',
                                         intf_name, 'tx_error_packets')
                    self._update_counter(interface, nsmap, 'eth_outdisc',
                                         intf_name, 'tx_discard_packets')
                    self._update_counter(interface, nsmap, 'eth_align_err',
                                         intf_name, 'alignment_errors')
                    self._update_counter(interface, nsmap, 'eth_fcs_err',
                                         intf_name, 'fcs_errors')
                    self._update_counter(interface, nsmap, 'eth_symbol_err',
                                         intf_name, 'symbol_errors')
                    self._update_counter(interface, nsmap, 'eth_runts',
                                         intf_name, 'runts')
                    self._update_counter(interface, nsmap, 'eth_giants',
                                         intf_name, 'giants')

            map(update_curr_data, interfaces)

        parse_rx_counters()
        parse_tx_counters()
        parse_errors()

    def _process(self):

        def data(intf_name):
            curr_intf_data = self._curr_data[intf_name]
            prev_intf_data = self._prev_data.get(intf_name, {})

            def rate(counter_name):
                value = curr_intf_data.get(counter_name, 0)
                prev_value = prev_intf_data.get(counter_name, 0)
                if value <= prev_value:
                    # this can happen when counters are reset
                    return 0
                # IBA and other parts of AOS assume counters are expressed in rate
                # per 5 seconds
                return long(math.ceil(((value - prev_value) / self._delta_secs)
                                      * RATE_INTERVAL_IN_SECONDS))

            return {
                'interface_name': intf_name,
                'rx_unicast_packets': rate('rx_unicast_packets'),
                'rx_broadcast_packets': rate('rx_broadcast_packets'),
                'rx_multicast_packets': rate('rx_multicast_packets'),
                'rx_error_packets': rate('rx_error_packets'),
                'rx_discard_packets': 0,
                'rx_bytes': rate('rx_bytes'),
                'tx_unicast_packets': rate('tx_unicast_packets'),
                'tx_broadcast_packets': rate('tx_broadcast_packets'),
                'tx_multicast_packets': rate('tx_multicast_packets'),
                'tx_error_packets': rate('tx_error_packets'),
                'tx_discard_packets': rate('tx_discard_packets'),
                'tx_bytes': rate('tx_bytes'),
                'alignment_errors': rate('alignment_errors'),
                'fcs_errors': rate('fcs_errors'),
                'symbol_errors': rate('symbol_errors'),
                'runts': rate('runts'),
                'giants': rate('giants'),
            }

        self.post_data(
            json.dumps({
                'items': [
                    data(intf_name)
                    for intf_name in self._curr_data
                    # new interfaces (ex: port-channels, port breakouts) can get
                    # added dynamically. We need at-least a baseline to publish a
                    # rate
                    if intf_name in self._prev_data
                ],
                'delta_seconds': RATE_INTERVAL_IN_SECONDS
            })
        )

    def collect(self):
        self._parse_counters()
        timestamp = datetime.datetime.now()

        if not self._prev_timestamp:
            self._prev_data = copy.deepcopy(self._curr_data)
            self._prev_timestamp = timestamp
            return

        self._delta_secs = (timestamp - self._prev_timestamp).seconds

        self._process()

        self._prev_data = copy.deepcopy(self._curr_data)
        self._prev_timestamp = timestamp


def collector_plugin(_device):
    return InterfaceCounterRateCollector
