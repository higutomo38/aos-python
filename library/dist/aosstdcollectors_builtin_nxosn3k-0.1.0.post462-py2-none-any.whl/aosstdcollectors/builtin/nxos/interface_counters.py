# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula


import json
import datetime
import math
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
import copy
from collections import defaultdict
import logging


DEFAULT_DELTA_SECONDS = 5
LOGGER = logging.getLogger(__name__)


class InterfaceCounterRateCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(InterfaceCounterRateCollector, self).__init__(*args, **kwargs)
        self.prev_data = dict()
        self.prev_timestamp = None
        self.curr_data = defaultdict(dict)

    def collect(self):
        counters = self.device.get_json('show interface counters')
        errors = self.device.get_json('show interface counters errors')
        # NXAPI intermittently returns the output for error counters as "".
        # This happens mostly post a switch reload.
        if errors == '':
            LOGGER.info('Error in retrieving error counters. Skip update')
            # As this is a temporary failure, do not update to sysdb.
            return

        timestamp = datetime.datetime.now()

        def process(data, key):
            for intf_data in data:
                for intf_metric, value in intf_data.iteritems():
                    self.curr_data[intf_data[key]][intf_metric] = value

        process(counters["TABLE_rx_counters"]["ROW_rx_counters"], key='interface_rx')
        process(counters["TABLE_tx_counters"]["ROW_tx_counters"], key='interface_tx')
        process(errors["TABLE_interface"]["ROW_interface"], key='interface')

        if not self.prev_timestamp:
            self.prev_data = copy.deepcopy(self.curr_data)
            self.prev_timestamp = timestamp
            return

        delta_seconds = (timestamp - self.prev_timestamp).total_seconds()

        def calc_rate(value, prev_value):
            if value <= prev_value:
                return 0

            return int(math.ceil((
                (value - prev_value) / delta_seconds) * DEFAULT_DELTA_SECONDS))

        def data(intf_name):
            def rate(counter_name):
                return calc_rate(int(self.curr_data[intf_name].get(counter_name, 0)),
                                 int(self.prev_data[intf_name].get(counter_name, 0)))

            return {
                'interface_name': intf_name,
                'rx_unicast_packets': rate('eth_inucast'),
                'rx_broadcast_packets': rate('eth_inbcast'),
                'rx_multicast_packets': rate('eth_inmcast'),
                'rx_error_packets': rate('eth_rcv_err'),
                'rx_bytes': rate('eth_inbytes'),
                # There is no entry for receive discard packets
                'rx_discard_packets': 0,
                'tx_unicast_packets': rate('eth_outucast'),
                'tx_broadcast_packets': rate('eth_outbcast'),
                'tx_multicast_packets': rate('eth_outmcast'),
                'tx_error_packets': rate('eth_xmit_err'),
                'tx_discard_packets': rate('eth_outdisc'),
                'tx_bytes': rate('eth_outbytes'),
                'alignment_errors': rate('eth_align_err'),
                'fcs_errors': rate('eth_fcs_err'),
                'symbol_errors': rate('eth_symbol_err'),
                'runts': rate('eth_runts'),
                'giants': rate('eth_giants'),
            }

        self.post_data(
            json.dumps({
                'items': [
                    data(intf_name)
                    for intf_name in self.curr_data.keys()
                ],
                'delta_seconds': DEFAULT_DELTA_SECONDS
            })
        )

        self.prev_data = copy.deepcopy(self.curr_data)
        self.prev_timestamp = timestamp


def collector_plugin(_device):
    return InterfaceCounterRateCollector
