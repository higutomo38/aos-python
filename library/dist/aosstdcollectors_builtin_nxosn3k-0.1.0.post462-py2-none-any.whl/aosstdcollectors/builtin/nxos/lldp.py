# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

import json
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.nxos_util import build_lldp_neighbor
from aosstdcollectors.utils.cisco_util import convert_mac_address


class LldpCollector(BaseTelemetryCollector):
    def parse_lldp(self, data):
        neighbors = data.get('TABLE_nbor_detail', {}).get('ROW_nbor_detail', [])
        if not isinstance(neighbors, list):
            neighbors = [neighbors]

        return json.dumps({
            'items': [dict({
                'chassis_id':
                    convert_mac_address(neighbor.get('chassis_id'))
                    if neighbor.get('chassis_type') == '4' or
                    neighbor.get('chassis_type') == 'Mac Address' else ''
            }, **build_lldp_neighbor(neighbor)) for neighbor in neighbors]
        })

    def collect(self):
        try:
            data = self.device.get_json('show lldp neighbors detail')
        except RuntimeError as exception:
            # Scenario where feature lldp is not enabled.
            if exception.message == '% Invalid command\n':
                self.post_data(json.dumps(dict(items=[])))
                return
            raise

        self.post_data(
            self.parse_lldp(data)
        )


def collector_plugin(_device):
    return LldpCollector
