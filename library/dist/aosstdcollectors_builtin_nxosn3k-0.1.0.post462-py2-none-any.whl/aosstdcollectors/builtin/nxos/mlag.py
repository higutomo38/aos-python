# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula
import json
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.nxos_util import get_interface_fullname


class MlagCollector(BaseTelemetryCollector):
    def collect(self):
        try:
            vpc_data = self.device.get_json('show vpc')
        except RuntimeError as re:
            if 'Invalid command' in str(re):
                self.post_data(json.dumps({}))
                return
            raise

        def sanitize(l):
            return l if isinstance(l, list) else [l]

        def domain_state(peer_status):
            if peer_status == 'peer-ok':
                return 'active'
            if peer_status == 'peer-link-down':
                return 'inactive'

            return 'unknown'

        def mlag_intf_state(port_state):
            if port_state == '1':
                return 'active_full'
            if port_state == '0':
                return 'disabled'

            return 'unknown'

        peer_link_data = vpc_data.get('TABLE_peerlink', {}).get('ROW_peerlink', {})

        self.post_data(json.dumps({
            'mlag_global': {
                'domain_id': vpc_data['vpc-domain-id'],
                'domain_state': domain_state(vpc_data['vpc-peer-status']),
                'local_interface': get_interface_fullname(
                    peer_link_data['peerlink-ifindex']
                ) if peer_link_data else None,
                'local_intf_status': 'up' if peer_link_data.get(
                    'peer-link-port-state'
                ) == '1' else 'down',
                'peer_link': get_interface_fullname(
                    peer_link_data['peerlink-ifindex']
                ) if peer_link_data else None,
                'peer_link_status': 'up' if vpc_data[
                    'vpc-peer-keepalive-status'] == 'peer-alive' else vpc_data[
                        'vpc-peer-keepalive-status'],
                'peer_address': None,
                'config_sanity': vpc_data['vpc-peer-consistency'],
            },
            'mlag_interface':
            [
                {
                    'intf_name': get_interface_fullname(mi['vpc-ifindex']),
                    'mlag_id': int(mi['vpc-id']),
                    'intf_state': mlag_intf_state(mi['vpc-port-state']),
                }
                for mi in sanitize(vpc_data.get('TABLE_vpc', {}).get('ROW_vpc', []))
            ],
        }))


def collector_plugin(_device):
    return MlagCollector
