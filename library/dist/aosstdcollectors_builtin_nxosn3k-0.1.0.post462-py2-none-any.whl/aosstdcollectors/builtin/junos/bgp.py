# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula
import json

from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.junos_util import (
    bgp_neighbor_state, vrf_name, bgp_address_family)


class BgpCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(BgpCollector, self).__init__(*args, **kwargs)
        self._spec = None

    @property
    def spec(self):
        if self._spec:
            return self._spec

        self._spec = self.device.load_table_view_spec(
            {
                "BgpNeighborTable": {
                    "rpc": "get-bgp-neighbor-information",
                    "item": "bgp-peer",
                    "view": "BgpNeighborView",
                    "key": "peer-address",
                },
                "BgpNeighborView": {
                    "fields": {
                        "source_ip": "local-address",
                        "source_asn": "local-as",
                        "dest_ip": "peer-address",
                        "dest_asn": "peer-as",
                        "state": "peer-state",
                        "vrf_name": "peer-cfg-rti",
                        "addr_family": "nlri-type-session",
                    }
                },
            }
        )

        return self._spec

    def collect(self):

        items = [
            {
                # source_ip is a combination of ip + port number,
                # filter the port number to get ip address
                "source_ip": neighbor.source_ip.split('+')[0],
                "source_asn": neighbor.source_asn,
                "dest_ip": neighbor.dest_ip.split('+')[0],
                "dest_asn": neighbor.dest_asn,
                "vrf_name": vrf_name(neighbor.vrf_name),
                "addr_family": bgp_address_family(neighbor.addr_family),
                "fsm_state": neighbor.state.lower(),
                "value": bgp_neighbor_state(neighbor.state),
            }
            for neighbor in self.device.create_table(
                self.spec["BgpNeighborTable"]
            ).get()
        ]

        self.post_data(json.dumps(dict(items=items)))


def collector_plugin(_):
    return BgpCollector
