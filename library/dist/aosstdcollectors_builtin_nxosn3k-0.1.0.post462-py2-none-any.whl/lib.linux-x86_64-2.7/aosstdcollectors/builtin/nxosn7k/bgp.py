# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

import json
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.nxosn7k_util import get_tree, get_value


class BgpCollector(BaseTelemetryCollector):

    def _process(self, data):
        tree, nsmap = get_tree(data)
        vrfs = tree.xpath('//aos:ROW_vrf', namespaces=nsmap)
        return json.dumps({
            'items': [
                {
                    'source_ip': get_value(vrf, nsmap, 'vrf-router-id'),
                    'source_asn': get_value(vrf, nsmap, 'vrf-local-as'),
                    'dest_ip': get_value(row, nsmap, 'neighborid'),
                    'dest_asn': get_value(row, nsmap, 'neighboras'),
                    'vrf_name': get_value(vrf, nsmap, 'vrf-name-out'),
                    'addr_family':
                        'ipv4' if get_value(row, nsmap, 'neighborversion') == '4'
                        else 'ipv6',
                    'fsm_state': get_value(row, nsmap, 'state').lower(),
                    'value':
                        'up' if get_value(row, nsmap, 'state') == 'Established'
                        else 'down',

                }
                for vrf in vrfs
                for row in vrf.xpath('.//aos:ROW_neighbor', namespaces=nsmap)
            ]
        })

    def collect(self):
        # TODO: IPv6 and EVPN BGP sessions once the data is available.
        data = self.device.get_text('show bgp ipv4 unicast summary vrf all | xml')
        parsed_data = self._process(data)
        self.post_data(parsed_data)


def collector_plugin(_device):
    return BgpCollector
