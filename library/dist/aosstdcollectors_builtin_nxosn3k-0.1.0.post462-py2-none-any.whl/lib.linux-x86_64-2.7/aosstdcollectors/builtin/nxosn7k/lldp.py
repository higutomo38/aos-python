# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

import json
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.nxosn7k_util import get_value, get_tree,\
    MGMT_INTF_REGEX, normalize_intf_name
from aosstdcollectors.utils.cisco_util import convert_mac_address
from aosstdcollectors.utils.platform_independent import is_valid_mac_address


def process_lldp_neighbors(neighbors, nsmap):
    # some items will exist but not have LLDP neighbors, those are ignored to match
    # the onbox agent behavior

    return json.dumps({
        'items': [
            {
                'chassis_id':
                    convert_mac_address(get_value(nbor, nsmap, 'chassis_id'))
                    if is_valid_mac_address(
                        convert_mac_address(get_value(nbor, nsmap, 'chassis_id')))
                    else '',
                'sys_description': '%s: %s' %
                                   (get_value(nbor, nsmap, 'chassis_type'),
                                    get_value(nbor, nsmap, 'chassis_id')),
                'neighbor_system_id': get_value(nbor, nsmap, 'chassis_id'),
                'neighbor_interface_name': normalize_intf_name(
                    nbor, nsmap, 'port_id'),
                'interface_name': normalize_intf_name(nbor, nsmap, 'l_port_id'),
            }
            for n in neighbors
            for nbor in n.xpath('.//aos:ROW_nbor', namespaces=nsmap)
            if not MGMT_INTF_REGEX.match(nbor.find('./aos:l_port_id', nsmap).text)
        ]
    })


# pylint: disable=anomalous-backslash-in-string
class LldpCollector(BaseTelemetryCollector):
    def collect(self):
        lldp_nbors = self.device.get_text('show lldp neighbors | xml')
        tree, nsmap = get_tree(lldp_nbors)
        neighbors = tree.xpath('//aos:show/aos:lldp/aos:neighbors', namespaces=nsmap)
        self.post_data(process_lldp_neighbors(neighbors, nsmap))


def collector_plugin(_device):
    return LldpCollector
