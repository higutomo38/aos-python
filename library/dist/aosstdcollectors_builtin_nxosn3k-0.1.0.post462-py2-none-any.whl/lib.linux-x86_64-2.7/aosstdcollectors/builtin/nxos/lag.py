# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

import json
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector


class LagCollector(BaseTelemetryCollector):
    def collect(self):
        def sanitize(l):
            return l if isinstance(l, list) else [l]

        lags = [
            {
                'lag_name': po['port-channel'],
                'value': 'up' if po['status'] == 'U' else 'down',
                'interfaces': [
                    {
                        'interface_name': member['port'],
                        'value': 'up' if member['port-status'] == 'P' else 'down',
                    }
                    for member in sanitize(
                        po.get('TABLE_member', {}).get('ROW_member', {})
                    )
                    if member.get('port')
                ],
            }
            for po_data in [self.device.get_json('show port-channel summary')]
            if po_data
            for po in sanitize(po_data['TABLE_channel']['ROW_channel'])
        ]
        self.post_data(json.dumps(dict(items=lags)))


def collector_plugin(_device):
    return LagCollector
