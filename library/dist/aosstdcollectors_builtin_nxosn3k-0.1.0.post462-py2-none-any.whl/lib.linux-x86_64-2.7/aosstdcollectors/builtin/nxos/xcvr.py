# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula
import json
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector


class XcvrCollector(BaseTelemetryCollector):
    def collect(self):
        def sanitize(l):
            return l if isinstance(l, list) else [l]

        def format_detail(entry):
            return '\n'.join(
                '{}: {}'.format(k, v)
                for k, v in sorted(entry.iteritems())
                if k not in ('interface', 'sfp')
            )

        self.post_data(json.dumps({
            'items': [
                {
                    'interface': entry['interface'],
                    'xcvr_detail': format_detail(entry),
                }
                for entry in sanitize(
                    self.device.get_json('show interface transceiver')[
                        'TABLE_interface']['ROW_interface'])
                if entry['sfp'] == 'present'
            ]
        }))


def collector_plugin(_device):
    return XcvrCollector
