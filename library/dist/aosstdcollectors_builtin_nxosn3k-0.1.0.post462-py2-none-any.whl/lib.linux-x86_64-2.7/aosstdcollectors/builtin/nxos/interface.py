# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

import json
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector


class InterfaceCollector(BaseTelemetryCollector):
    def collect(self):
        def get_interface(interface):
            if interface.startswith("loopback"):
                return interface.title()
            return interface
        self.post_data(json.dumps({
            'items': [
                {
                    'interface_name': get_interface(intf['interface']),
                    'value': 'up' if intf['state'] == 'connected' else 'down',
                    'admin_state': (
                        'up' if intf['state'] != 'disabled' else 'down'
                    ),
                }
                for intf in self.device.get_json('show interface status')[
                    'TABLE_interface']['ROW_interface']
            ]
        }))


def collector_plugin(_device):
    return InterfaceCollector
