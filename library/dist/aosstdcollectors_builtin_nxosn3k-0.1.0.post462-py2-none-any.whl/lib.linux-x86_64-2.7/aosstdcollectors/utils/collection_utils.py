# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula


def indexby(key, items):
    """
    Apply function key() to each item in items parameter. Throw AssertionError if
    return value is already a key in the resulting dictionary.
    """
    result = {}
    for item in items:
        k = key(item)
        assert k not in result, \
            'Duplicate key %s of item %s. Previous item %s' % (
                k, item, result[k])
        result[k] = item
    return result
