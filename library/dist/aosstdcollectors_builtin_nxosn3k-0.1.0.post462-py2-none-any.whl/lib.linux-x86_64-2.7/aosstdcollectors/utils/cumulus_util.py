# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula


def make_item_lldp_nei(nei_data):
    """
    This function creates the collector item when
    an interface has an LLDP neighbor
    """

    val, desc, name = '', '', ''
    chassis = nei_data.get('chassis', [])
    if chassis:
        nm = chassis[0].get('name', [])
        if nm:
            val = str(nm[0].get('value'))

        ds = chassis[0].get('descr', [])
        if ds:
            desc = str(ds[0].get('value'))

    port = nei_data.get('port', [])
    if port:
        nm = port[0].get('id', [])
        if nm:
            name = str(nm[0].get('value'))

    return {
        'interface_name': str(nei_data.get('name')),
        'neighbor_system_id': val,
        'sys_description': desc,
        'neighbor_interface_name': name
    }


def is_lldp(elem):
    return str(elem.get('via')) == 'LLDP'
