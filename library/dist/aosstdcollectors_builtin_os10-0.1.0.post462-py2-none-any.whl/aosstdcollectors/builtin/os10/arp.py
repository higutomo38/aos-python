# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula
import json
from lxml import etree
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.os10_util import parse


def parse_arp_data(arp_data):
    return json.dumps(dict(items=[
        {
            # TODO we only support default vrf, add support for non-default vrf later
            'vrf_name': 'default',
            'ip_address': parse(arp_entry, './addr'),
            'mac_address': parse(arp_entry, './link-layer-address'),
            'interface_name': parse(arp_entry, './intf-name'),
            'type': 'dynamicArp' if parse(
                arp_entry, './state') == 'dynamic' else 'staticArp',
            'l2_info': parse(arp_entry, './vlan-mem-port') or ''
        }
        for arp_entry in arp_data.findall('./bulk/data/arp-entry')
    ]))


class ArpCollector(BaseTelemetryCollector):
    def collect(self):
        xml_data = self.device.get_text('show ip arp | display-xml')
        arp_data = etree.fromstring(xml_data.encode('utf8'))
        self.post_data(parse_arp_data(arp_data))


def collector_plugin(_device):
    return ArpCollector
