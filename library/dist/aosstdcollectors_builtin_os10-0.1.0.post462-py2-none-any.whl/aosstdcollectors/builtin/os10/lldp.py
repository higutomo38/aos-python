# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula
import base64
import json
from lxml import etree
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.os10_util import parse, is_management_interface, \
    parse_multiple_xmls, decode_mac_address
from aosstdcollectors.utils.platform_independent import is_valid_mac_address


class LldpCollector(BaseTelemetryCollector):

    def most_recent_lldp(self, interface):
        return max(interface.findall('./lldp-rem-neighbor-info/info'),
                   key=lambda info: int(parse(info, './rem-last-update-time')))

    def parse_interface_lldp(self, intf_name, lldp_info):
        def parse_not_advertised(value):
            if value == 'Not Advertised':
                return ''
            return value

        neighbor_interface_type = parse(lldp_info, './rem-lldp-port-subtype')
        neighbor_interface_name = parse(lldp_info, './rem-lldp-port-id')
        chassis_id = parse(lldp_info, './rem-lldp-chassis-id')

        if neighbor_interface_type == 'mac-address':
            neighbor_interface_name = decode_mac_address(
                neighbor_interface_name)
        elif neighbor_interface_type == 'interface-name':
            neighbor_interface_name = base64.b64decode(neighbor_interface_name)

        return {
            'chassis_id':
                chassis_id
                if is_valid_mac_address(chassis_id) else '',
            'interface_name': intf_name,
            'neighbor_interface_name': neighbor_interface_name,
            'neighbor_system_id': parse_not_advertised(
                parse(lldp_info, './rem-system-name')),
            'sys_description': parse_not_advertised(
                parse(lldp_info, './rem-system-desc'))
        }

    def parse_lldp(self, interfaces):
        return [
            self.parse_interface_lldp(parse(interface, 'name'),
                                      self.most_recent_lldp(interface))
            for interface in interfaces.findall('./bulk/data/interface')
            if interface.find(
                './lldp-rem-neighbor-info/info/rem-system-name') is not None and
            not is_management_interface(parse(interface, 'type'))
        ]

    def populate_lldp(self):
        data_xmls = parse_multiple_xmls(
            self.device.get_text('show lldp neighbors | display-xml'))
        return [
            lldp_entry
            for lldp_entries in data_xmls
            for lldp_entry in
            self.parse_lldp(etree.fromstring(lldp_entries.encode('utf8')))
        ]

    def collect(self):
        self.post_data(json.dumps(dict(items=self.populate_lldp())))


def collector_plugin(_):
    return LldpCollector
