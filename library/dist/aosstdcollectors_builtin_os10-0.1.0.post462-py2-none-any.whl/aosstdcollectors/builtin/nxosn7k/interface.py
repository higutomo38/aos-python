# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

import json
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.nxosn7k_util import get_tree, get_value


class InterfaceCollector(BaseTelemetryCollector):
    # TODO: this function is not required if NX7K is printing Port-Channel
    # in lower case. I copied this code from eos platform and retaining
    # it for now as I don't have dump for port channel interface for NX7K.
    def _make_if_name(self, ifname):
        # existing code expects the port-channel to be lowercase, following
        # suit in this collector
        return ifname.lower() if ifname.startswith("Port-Channel") else ifname

    def _process(self, data):
        tree, nsmap = get_tree(data)
        return json.dumps({
            'items': [
                {
                    "interface_name":
                        self._make_if_name(get_value(intf, nsmap, 'interface')),
                    "value":
                        'up' if get_value(intf, nsmap, 'state') == 'connected'
                        else 'down',
                }
                for intf in tree.xpath('//aos:ROW_interface', namespaces=nsmap)
            ]
        })

    def collect(self):
        data = self.device.get_text('show interface status | xml')
        parsed_data = self._process(data)
        self.post_data(parsed_data)


def collector_plugin(_device):
    return InterfaceCollector
