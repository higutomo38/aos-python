# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

import json
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.nxos_util import build_bgp_neighbors


class BgpCollector(BaseTelemetryCollector):

    def collect(self):
        bgp_cmds = {
            'ipv4': 'show bgp ipv4 unicast summary vrf all',
            'ipv6': 'show bgp ipv6 unicast summary vrf all',
            'evpn': 'show bgp l2vpn evpn summary vrf all'
        }

        output = []
        for addr_family, cmd in bgp_cmds.iteritems():
            try:
                cmd_output = self.device.get_json(cmd)
            except RuntimeError as exception:
                # In case AOS starts the bgp collector and feature bgp is
                # not enabled in the device, the control gets here with
                # "invalid command". While the features are being enabled, if
                # the collector tries to retrieve the state, then
                # "process currently not running" is raised.
                if exception.message not in {
                        '% Invalid command\n',
                        'Note:  process currently not running\n',
                }:
                    raise

            else:
                output.extend(
                    build_bgp_neighbors(cmd_output, addr_family)
                )

        self.post_data(json.dumps(dict(items=output)))


def collector_plugin(_device):
    return BgpCollector
