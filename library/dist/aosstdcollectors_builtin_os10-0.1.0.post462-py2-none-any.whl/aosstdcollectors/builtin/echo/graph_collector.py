# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

import json
from aos.sdk.system_agent.base_telemetry_collector import GraphTelemetryCollector


def json_loads_ascii(input_string):
    """Given a json string, load and convert all instances of unicode strings into
       ascii encoded strings. The modified json object is returned. The input
       is unchanged.

       Returns:
            JSON object with ASCII strings (e.g. 'abc'). All unicode characters
            are encoded with UTF-8 in the resulting ASCII strings.
    """
    def convert(obj):
        if isinstance(obj, list):
            return [convert(val) for val in obj]
        elif isinstance(obj, dict):
            return {
                convert(key): convert(obj[key])
                for key in obj
            }
        elif isinstance(obj, unicode):
            return obj.encode('utf-8')
        return obj

    return convert(json.loads(input_string))


class GraphCollector(GraphTelemetryCollector):
    # TODO(Rags): This needs to be fixed most likely in AOS, where AOS assumes a
    # class-level attribute to be present in hard-coded design registry.
    design = 'virtualinfra'

    def __init__(self, *args, **kwargs):
        super(GraphCollector, self).__init__(*args, **kwargs)
        self.prev_input = None

    def collect(self):
        assert self.service_config.input
        if not self.prev_input:
            self.prev_input = self.service_config.input
        else:
            # This optimization is done to simulate behaviors of real collectors like
            # vCenter which also only do incremental updates to telemetry/inventory
            # graph. In other words, if there is no change in target vCenter, no
            # change is made to graph and graph commit is not called
            # Even if there are other collectors which are not this smart, having
            # this optimization helps us with performance in case of graph input
            # being very large and it is still functionally accurate
            if self.prev_input == self.service_config.input:
                return  # nothing changed, so no need to update graph

            self.prev_input = self.service_config.input

        input_tac_json = json_loads_ascii(self.service_config.input)

        for rel_id in [
                r.id
                for r in self.graph.get_relationships()
                if r.id not in input_tac_json['relationship']]:
            self.graph.del_relationship(rel_id)

        for node_id in [
                n.id
                for n in self.graph.get_nodes()
                if n.id not in input_tac_json['node']]:
            self.graph.del_node(node_id)

        for node in input_tac_json['node'].itervalues():
            node_id = node['id']
            schema = self.graph.schema.get_node_schema(node['type'])
            properties = schema.load({
                k: json.loads(v)
                for k, v in node['property'].iteritems()
            })
            if self.graph.get_node(node_id):
                self.graph.set_node(node_id, **properties)
            else:
                self.graph.add_node(node['type'], id=node_id, **properties)

        for rel in input_tac_json['relationship'].itervalues():
            rel_id = rel['id']
            schema = self.graph.schema.get_relationship_schema(
                rel['type'], rel['source_type'], rel['target_type'])
            properties = schema.load({
                k: json.loads(v)
                for k, v in rel['property'].iteritems()
            })
            if self.graph.get_relationship(rel_id):
                self.graph.set_relationship(rel_id, **properties)
            else:
                self.graph.add_relationship(
                    rel['type'], rel['source_id'], rel['target_id'], id=rel_id,
                    **properties)

        self.graph.commit()


def collector_plugin(_device):
    return GraphCollector
