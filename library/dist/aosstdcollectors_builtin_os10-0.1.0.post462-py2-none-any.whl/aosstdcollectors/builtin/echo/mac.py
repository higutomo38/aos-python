# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula
import json
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.echo_util import build_mac


class MacCollector(BaseTelemetryCollector):
    def collect(self):
        input_tac_json = json.loads(self.service_config.input) \
            if self.service_config.input else {}

        self.post_data(json.dumps({
            'items': [
                {
                    'mac_address': build_mac(mac_entry['macAddress']),
                    # TODO: set vlan to 1 because of AOS-12593, we can't handle
                    #  vlan = 0 atm.
                    'vlan': vlan_macs['vlan'] or 1,
                    'interface_name': mac_entry['intfName'],
                    'type': mac_entry['type'],
                }
                for vlan_macs in input_tac_json.get('entry', {}).itervalues()
                for mac_entry in vlan_macs['macEntry'].itervalues()
            ]
        }))


def collector_plugin(_device):
    return MacCollector
