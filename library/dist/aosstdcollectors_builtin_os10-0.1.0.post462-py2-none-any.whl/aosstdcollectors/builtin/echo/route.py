# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula
import json
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector


class RouteCollector(BaseTelemetryCollector):
    def collect(self):
        input_tac_json = json.loads(self.service_config.input) \
            if self.service_config.input else {}

        self.post_data(json.dumps({
            'items': [
                {
                    'prefix': entry['ip']['ip'],
                    'prefix_len': entry['ip']['prefix'],
                    'route_status': entry['status'],
                    'next_hops': [
                        {
                            'prefix': nh['ip']['ip'],
                            'prefix_len': nh['ip']['prefix'] or '32',
                            'tag': nh['tag'],
                            'type': nh['type'],
                            'status': nh['status'],
                        }
                        for nh in entry['nextHop'].itervalues()
                    ]
                }
                for entry in input_tac_json.get('route', {}).itervalues()
            ]
        }))


def collector_plugin(_device):
    return RouteCollector
