# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula
import json

from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector


class HostnameCollector(BaseTelemetryCollector):
    def collect(self):
        # TODO(Rags): Need to find a more specific command to fetch just the hostname
        # and domain. The hostname is present in rpc get_software_information but
        # unable to find a way to get domain-name short of reading the active config
        # itself. Using table/view pattern in junos-pyez to read config is not
        # working either
        self.device.driver.facts_refresh(keys=('hostname', 'domain'))

        f = self.device.driver.facts

        self.post_data(json.dumps(
            {
                'items': [
                    {
                        'hostname': f['hostname'] or f['hostname_info']['fpc0'],
                        'domain': f['domain'] or '',
                    }
                ]
            }))


def collector_plugin(_device):
    return HostnameCollector
