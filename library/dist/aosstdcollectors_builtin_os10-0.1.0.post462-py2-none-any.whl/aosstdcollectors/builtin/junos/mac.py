# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.junos_util import intf_name


class MacCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(MacCollector, self).__init__(*args, **kwargs)
        self._spec = None

    @property
    def spec(self):
        if self._spec:
            return self._spec

        self._spec = self.device.load_table_view_spec(
            {
                "EthernetSwitchingTable": {
                    "rpc": "get-ethernet-switching-table-information",
                    "item": "l2ng-l2ald-mac-entry-vlan",
                    "args": {"extensive": True},
                    "view": "EthernetSwitchingTableView",
                },
                "EthernetSwitchingTableView": {
                    "fields": {
                        "mac_address": "l2ng-l2-mac-address",
                        "vlan": "l2ng-l2-vlan-id",
                        "interface_name": "l2ng-l2-mac-logical-interface",
                        "type": "l2ng-l2-mac-entry-flags",
                    }
                },
            }
        )
        return self._spec

    def collect(self):
        self.post_data(dict(items=[
            {
                "mac_address": mac.mac_address,
                "vlan": int(mac.vlan),
                "interface_name": intf_name(mac.interface_name),
                "type": "staticMac" if "static" in mac.type else "dynamicMac",
            }
            for mac in self.device.create_table(
                self.spec["EthernetSwitchingTable"]).get()
        ]))


def collector_plugin(_device):
    return MacCollector
