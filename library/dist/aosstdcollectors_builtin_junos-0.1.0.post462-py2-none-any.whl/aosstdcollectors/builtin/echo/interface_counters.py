# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula
import json
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector


DEFAULT_DELTA = 5


class InterfaceCounterCollector(BaseTelemetryCollector):
    def collect(self):
        input_tac_json = json.loads(self.service_config.input) \
            if self.service_config.input else {}

        self.post_data(json.dumps({
            'items': [{
                'interface_name': entry['name'],
                'rx_unicast_packets': entry['statistics']['rxUnicastPackets'],
                'rx_broadcast_packets': entry['statistics']['rxBroadcastPackets'],
                'rx_multicast_packets': entry['statistics']['rxMulticastPackets'],
                'rx_error_packets': entry['errorStatistics']['rxErrorPackets'],
                'rx_discard_packets': entry['errorStatistics']['rxDiscardPackets'],
                'rx_bytes': entry['statistics']['rxBytes'],
                'tx_unicast_packets': entry['statistics']['txUnicastPackets'],
                'tx_broadcast_packets': entry['statistics']['txBroadcastPackets'],
                'tx_multicast_packets': entry['statistics']['txMulticastPackets'],
                'tx_error_packets': entry['errorStatistics']['txErrorPackets'],
                'tx_discard_packets': entry['errorStatistics']['txDiscardPackets'],
                'tx_bytes': entry['statistics']['txBytes'],
                'alignment_errors': entry['errorStatistics']['alignmentErrors'],
                'fcs_errors': entry['errorStatistics']['fcsErrors'],
                'symbol_errors': entry['errorStatistics']['symbolErrors'],
                'runts': entry['errorStatistics']['runts'],
                'giants': entry['errorStatistics']['giants'],
            }
                      for entry in input_tac_json.get('interface', {}).itervalues()
                     ],
            'delta_seconds': int(input_tac_json.get('timeDelta')) or DEFAULT_DELTA
        }))


def collector_plugin(_device):
    return InterfaceCounterCollector
