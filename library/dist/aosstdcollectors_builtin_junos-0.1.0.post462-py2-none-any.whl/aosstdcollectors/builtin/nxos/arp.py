# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

import json
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.cisco_util import convert_mac_address


class ArpCollector(BaseTelemetryCollector):
    def collect(self):
        def sanitize(l):
            return l if isinstance(l, list) else [l]

        arp_entries = [
            {
                'vrf_name': vrf['vrf_name'],
                'ip_address': vrf_arp['ip-addr-out'],
                'mac_address': convert_mac_address(vrf_arp['mac']),
                'interface_name': vrf_arp['intf-out'],
                'type': (
                    'staticArp' if vrf_arp['time-stamp'] == '-' else 'dynamicArp'),
                'l2_info': '',
            }
            for vrf in self.device.get_json('show vrf all')['TABLE_vrf']['ROW_vrf']
            for vrf_arp in sanitize(
                self.device.get_json(
                    'show ip arp vrf {}'.format(vrf['vrf_name'])
                )['TABLE_vrf']['ROW_vrf'].get('TABLE_adj', {}).get('ROW_adj', [])
            )
            if vrf_arp.get('incomplete') != 'true'
        ]
        self.post_data(json.dumps(dict(items=arp_entries)))


def collector_plugin(_device):
    return ArpCollector
