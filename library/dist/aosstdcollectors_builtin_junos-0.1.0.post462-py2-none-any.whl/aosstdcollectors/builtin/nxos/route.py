# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

from collections import defaultdict
import json
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.platform_independent import split_ip_prefix_len


class RouteCollector(BaseTelemetryCollector):
    def collect(self):
        def sanitize(l):
            return l if isinstance(l, list) else [l]

        def next_hop_type(nh_data):
            client = nh_data.get('clientname')
            if not client:
                return 'unknown'

            if client.startswith('bgp'):
                return 'bgp'

            if client.startswith('stat'):
                return 'stat'

            if client.startswith('direct'):
                return 'direct'

            return 'unknown'

        def dedup_nexthops(nh_list):
            '''Cisco returns multiple nexthops with exact same IP having different
            attributes. We prefer the one that has most populated info'''
            prefix_to_nhs = defaultdict(list)
            for nh in nh_list:
                prefix_to_nhs[nh['prefix']].append(nh)

            def select_nh(prefix_nh_list):
                for nh in prefix_nh_list:
                    if nh['type'] != 'unknown':
                        return nh

                return prefix_nh_list[0]

            return [
                select_nh(prefix_nh_list)
                for prefix_nh_list in prefix_to_nhs.itervalues()
            ]

        self.post_data(json.dumps({
            'items': [
                {
                    'prefix': prefix,
                    'prefix_len': prefix_len,
                    # Without access to route expectations, we can't deduce other
                    # values for route_status and next-hop status
                    'route_status': 'up',
                    'next_hops': dedup_nexthops([
                        {
                            'prefix': nh_data['ipnexthop'],
                            'prefix_len': '32',
                            'tag': '',  # tag is not filled for nxos onbox too
                            'type': next_hop_type(nh_data),
                            'status': 'up',
                        }
                        for nh_data in sanitize(ri['TABLE_path']['ROW_path'])
                        if nh_data.get('ipnexthop')
                    ]),
                }
                # TODO(Rags): Add ipv6 route collection support
                for vrf_data in sanitize(self.device.get_json(
                    'show ip route')['TABLE_vrf']['ROW_vrf'])
                if vrf_data['vrf-name-out'] == 'default'
                if 'TABLE_prefix' in vrf_data['TABLE_addrf']['ROW_addrf']
                for ri in sanitize(vrf_data[
                    'TABLE_addrf']['ROW_addrf']['TABLE_prefix']['ROW_prefix'])
                # ignore routes without next hops to match onbox agent behavior
                if ri.get('TABLE_path', {}).get('ROW_path')
                for prefix, prefix_len in [split_ip_prefix_len(ri['ipprefix'])]
            ]
        }))


def collector_plugin(_device):
    return RouteCollector
