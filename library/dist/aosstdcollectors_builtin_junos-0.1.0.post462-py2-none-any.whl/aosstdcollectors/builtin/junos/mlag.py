# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula
import json
import logging

from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.junos_util import intf_name

LOG = logging.getLogger(__name__)


class MlagCollector(BaseTelemetryCollector):
    """
    MLAG (MC-LAG) collector for Juniper.

    Juniper MC-LAG does not support more than one peer (based on vqfx 18R1).
    """
    def __init__(self, *args, **kwargs):
        super(MlagCollector, self).__init__(*args, **kwargs)
        self._spec = None

    @property
    def mlag_spec(self):
        if self._spec:
            return self._spec

        self._spec = self.device.load_table_view_spec(
            {
                "MLAGTable": {
                    "rpc": "get-mc-ae-interface-information",
                    "item": "mc-ae-status-information",
                    # "extensive" is required to receive global MLAG (MC-LAG in
                    # Juniper terms) configuration
                    "args": {"extensive": True},
                    "view": "MLAGView",
                },
                "MLAGView": {
                    # see https://www.juniper.net/documentation/en_US/junos/
                    # topics/reference/command-summary/show-intefaces-mc-ae.html
                    #
                    # - mc-ae-status/local-state: Up or down state of the local
                    #   device
                    # - mc-ae-status/local-status: Status of the local link: active
                    #   or standby.
                    # - mc-ae-ifl-list/mcp-state: space-separated string with 3 items
                    #   "<Peer IP> <Peer interface> <Peer state>", or "N/A"
                    "fields": {
                        "domain_id": "mc-ae-additional-information/mcae-id",
                        "local_state": "mc-ae-status/local-state",
                        "local_interface": "mc-ae-status/member-link",
                        "local_interface_status": "mc-ae-status/local-status",
                        "peer_mcp_state": "mc-ae-ifl-list/mcp-state",
                    }
                },
            }
        )

        return self._spec

    def collect(self):
        def domain_state(_mlag):
            # Junos values: ['up', 'down']
            # see https://www.juniper.net/documentation/en_US/junos/
            # topics/reference/command-summary/show-intefaces-mc-ae.html
            #
            # AOS accepted values: ['active', 'inactive', 'disabled', 'missing',
            # 'unknown']
            junos_to_aos_state = {
                "up": "active",
                "down": "disabled"
            }
            return junos_to_aos_state.get(_mlag.local_state, "unknown")

        def parse_mcp_state(mcp_state):
            # `mcp_state` is either space-separated string with 3 items
            # "<Peer IP> <Peer interface> <Peer state>", or "N/A"
            if mcp_state == "N/A":
                return None, None, None

            m = mcp_state.strip().split(" ")

            if len(m) != 3:
                # TODO(roman) raise ValueError instead?
                # raise ValueError("Unexpected MC-LAG peer link state value: %s" %
                #                  mcp_state)
                LOG.warning("Unexpected MC-LAG peer link state value: %s", mcp_state)
                return None, None, None

            peer_ip, peer_intf, peer_state = m

            return peer_ip, peer_intf, peer_state

        def peer_link(_mlag):
            _, peer_intf, _ = parse_mcp_state(_mlag.peer_mcp_state)
            return intf_name(peer_intf)

        def peer_address(_mlag):
            address, _, _ = parse_mcp_state(_mlag.peer_mcp_state)
            return address

        def peer_link_status(_mlag):
            _, _, peer_status = parse_mcp_state(_mlag.peer_mcp_state)
            return peer_status

        def mlag_intf_state(_mlag):
            # AOS expects: ['active_full', 'active_partial', 'inactive',
            # 'configured', 'disabled', 'missing', 'unknown']
            # Junos provides: ['active', 'standby']
            junos_to_aos_intf_state = {
                "active": "active_full",
                "standby": "inactive",
            }
            return junos_to_aos_intf_state.get(_mlag.local_interface_status,
                                               "unknown")

        items = [
            {
                "mlag_global": {
                    "domain_id": mlag.domain_id,
                    "domain_state": domain_state(mlag),
                    "local_interface": mlag.local_interface,
                    "local_inf_status": mlag.local_interface_status,
                    "peer_address": peer_address(mlag),
                    "peer_link": peer_link(mlag),
                    "peer_link_status": peer_link_status(mlag),
                    # optional "config_sanity" is not available
                },
                # Junos only supports one MC-LAG interface (empirical evidence only
                # on vqfx 18R1, cannot find proof in Junos docs)
                "mlag_interface": [{
                    "intf_name": mlag.local_interface,
                    "mlag_id": int(mlag.domain_id),
                    "intf_state": mlag_intf_state(mlag)
                }]
            }
            for mlag in self.device.create_table(self.mlag_spec["MLAGTable"]).get()
        ]

        self.post_data(json.dumps(dict(items=items)))


def collector_plugin(_):
    return MlagCollector
