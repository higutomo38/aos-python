# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula
import json
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.junos_util import VALID_INTF_REGEX


class InterfaceCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(InterfaceCollector, self).__init__(*args, **kwargs)
        self._spec = None

    @property
    def spec(self):
        if self._spec:
            return self._spec

        self._spec = self.device.load_table_view_spec({
            'InterfaceStatusTable': {
                'rpc': 'get-interface-information',
                'item': 'physical-interface',
                'args': {
                    'terse': True,
                },
                'view': 'InterfaceStatusView',
            },
            'InterfaceStatusView': {
                'fields': {
                    'status': 'oper-status',
                }
            }
        })

        return self._spec

    def collect(self):
        items = [
            {
                'interface_name': intf.name,
                'value': 'up' if intf.status == 'up' else 'down'
            }
            for intf in self.device.create_table(
                self.spec['InterfaceStatusTable']).get()
            if VALID_INTF_REGEX.match(intf.name)
        ]

        self.post_data(json.dumps(dict(items=items)))


def collector_plugin(_device):
    return InterfaceCollector
