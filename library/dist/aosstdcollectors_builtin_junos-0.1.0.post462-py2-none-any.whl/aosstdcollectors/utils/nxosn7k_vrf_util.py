# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula


import datetime
import logging
from collections import defaultdict
from aosstdcollectors.utils.nxosn7k_util import get_tree, get_value, MGMT_INTF_REGEX

LOG = logging.getLogger(__name__)
VRF_CACHE = {'data': {}, 'time': None}


def update_cache(cache_time, cache_data):
    VRF_CACHE['data'] = cache_data
    VRF_CACHE['time'] = cache_time


def read_vrfs(device, no_cache=False):
    if no_cache:
        LOG.info('Do not use VRF_CACHE')
        update_cache(None, {})

    # update cache if data is more than 4 hours old
    # vrfs will only change if configs are updated
    if VRF_CACHE['time'] and \
       (datetime.datetime.now() - VRF_CACHE['time']).total_seconds() > 14400:
        LOG.info('Invalidating VRF_CACHE - time exceeded %s', VRF_CACHE['time'])
        update_cache(datetime.datetime.now(), {})

    if VRF_CACHE['data']:
        LOG.debug('Reading VRF_CACHE')
        return VRF_CACHE['data']

    LOG.info('Updating VRF_CACHE')
    update_cache(datetime.datetime.now(), collect_vrfs(device))
    return VRF_CACHE['data']


def collect_vrfs(device):
    def build(vrf):
        vrf_name = get_value(vrf, vrf_nsmap, 'vrf_name').strip()
        role = 'data'
        if any(MGMT_INTF_REGEX.match(i) for i in intf_data[vrf_name]):
            role = 'management'

        return {
            'vrf_name': vrf_name,
            'value': {
                'rd': get_value(vrf, vrf_nsmap, 'rd').strip(),
                'interfaces': intf_data[vrf_name],
                'role': role,
                'multicast_mode': 'enabled' if vrf_name in
                                  pim_vrfs else 'disabled'
            }
        }

    vrf_tree, vrf_nsmap = get_tree(device.get_text(
        'show vrf detail | xml'))
    intfs_tree, intfs_nsmap = get_tree(device.get_text(
        'show vrf interface | xml'))
    pim_tree, pim_nsmap = get_tree(device.get_text(
        'show ip pim vrf all | xml'))

    vrfs = vrf_tree.xpath('//aos:show//aos:ROW_vrf', namespaces=vrf_nsmap)
    intfs = intfs_tree.xpath('//aos:show//aos:ROW_if', namespaces=intfs_nsmap)
    pim_vrfs = [
        get_value(p, pim_nsmap, 'out-context').strip()
        for p in pim_tree.xpath('//aos:show//aos:ROW_context',
                                namespaces=pim_nsmap)
    ]

    intf_data = defaultdict(list)
    for i in intfs:
        intf_data[get_value(i, intfs_nsmap, 'vrf_name').strip()].append(
            get_value(i, intfs_nsmap, 'if_name').strip())

    vrf_data = {
        get_value(vrf, vrf_nsmap, 'vrf_name').strip(): build(vrf)['value']
        for vrf in vrfs
    }

    return vrf_data
