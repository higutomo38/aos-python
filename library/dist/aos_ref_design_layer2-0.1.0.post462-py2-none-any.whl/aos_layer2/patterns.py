# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula


from aos.sdk.graph import is_in, not_none
from aos.sdk.graph.query import node, match


def linked_systems(
        system1=None,
        system2=None,
        interface1="interface1",
        interface2="interface2",
        link=None,
        system1_type="system",
):
    return (
        node(system1_type, name=system1)
        .out("hosted_interfaces")
        .node("interface", name=interface1)
        .out("link")
        .node("link", name=link)
        .in_("link")
        .node("interface", name=interface2)
        .in_("hosted_interfaces")
        .node("system", name=system2)
        .ensure_different(interface1, interface2)
    )


def connected_physical_interfaces(device="device", remote_device="remote_device"):
    """Return path query for linked physical interfaces. Named nodes are device,
    interface, link, remote_interface and remote_device.
    """
    return match(
        linked_systems(
            system1=device,
            system2=remote_device,
            interface1="interface",
            interface2="remote_interface",
            link="link",
        ),
        node(name="interface", if_type=is_in(["ip", "ethernet"])),
    )


def connected_port_channels(
        device="device", remote_device="remote_device", named_child_link="child_link"
):
    """Return path query for port-channels with a connected child interface.
    Named nodes are device, interface (representing port-channel), child_interface,
    child_link (overridable), remote_child_interface, remote_interface
    (port-channel) and remote_device.

    Parameters:
        named_child_link - if specified, child link node is named

    """
    # For port-channels we always use child interface link to reach neighbor as that
    # must always exist. Port-channel on member leaf itself has no link in case of
    # mlag connection
    return (
        node("system", name=device)
        .out("hosted_interfaces")
        .node("interface", name="interface", if_type="port_channel")
        .out("composed_of")
        .node("interface", name="child_interface")
        .out("link")
        .node("link", name=named_child_link)
        .in_("link")
        .node("interface", name="remote_child_interface")
        .where(
            lambda child_interface, remote_child_interface: child_interface
            != remote_child_interface
        )
        .in_("composed_of")
        .node("interface", name="remote_interface", if_type="port_channel")
        .in_("hosted_interfaces")
        .node("system", name=remote_device)
    )


def systems_with_asn(system='device', domain='domain', system_filters=None):
    '''Return path query for systems that are part of autonomous system domain with
    an assigned asn.
    Named nodes are domain, device'''

    system_filters = system_filters or {}

    return (
        node('domain', name=domain, domain_type='autonomous_system',
             domain_id=not_none())
        .out('composed_of_systems')
        .node('system', name=system, **system_filters)
    )


def paired_systems_in_mlag_domain(
        system1="system1",
        system2="system2",
        redundancy_group="redundancy_group",
        domain="domain",
):
    """Return path query for mlag connected devices, query includes domain
    and redundancy group"""
    return (
        node("system", name=system1)
        .out("part_of_redundancy_group")
        .node("redundancy_group", name=redundancy_group)
        .in_("composed_of_redundancy_group")
        .node("domain", name=domain, domain_type="mlag", domain_id=not_none())
        .out("composed_of_redundancy_group")
        .node(name=redundancy_group)
        .out("composed_of_systems")
        .node("system", name=system2)
        .ensure_different(system1, system2)
    )
