# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula


from aos.sdk.reference_design.blueprint_registry_plugin import \
    BlueprintRegistryPlugin as _BlueprintRegistryPlugin
from aos.sdk.graph.query import not_none


class BlueprintRegistryPlugin(_BlueprintRegistryPlugin):
    def get_blueprint_system_map(self, graph):
        system_map = self._new_map()
        for node in graph.get_nodes('system', system_id=not_none()):
            system_map.add_system(node.system_id, node.deploy_mode, node.role)
        return system_map
