#!/usr/bin/env python
# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula


import os
from setuptools import find_packages, setup


def finalize_version(base_version):
    return (base_version + os.getenv('VERSION_SUFFIX', '')) if base_version else None


def get_requirements_from(filename):
    req_lines = (
        line.strip()
        for line in open(
            os.path.join(os.path.dirname(__file__), filename)).readlines()
    )

    return list(filter(None, req_lines))


setup(
    name='aos-ref-design-layer2',
    version=finalize_version('0.1.0'),
    description='Apstra Operating System reference design for traditional layer2 '
                'networks',
    license='MIT',
    author='Apstra, Inc.',
    zip_safe=False,
    author_email='support@apstra.com',
    packages=find_packages(exclude=["test"]),
    install_requires=get_requirements_from('requirements.txt'),
    tests_require=get_requirements_from('dev-requirements.txt'),
    entry_points={
        'aos.reference_design': [
            'layer2=aos_layer2',
        ]
    },
)
