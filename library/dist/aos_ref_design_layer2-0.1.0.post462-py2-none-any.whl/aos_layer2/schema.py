# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

from aos.sdk import schema as s
from aos.sdk.interface_map.interface_map_schema import interface_map_fields
from aos.sdk.device_profile.device_profile_schema import device_profile_fields

NODE_ROLES = ['spine', 'leaf', 'l2_server', 'l3_server', 'external_router']

DP_FIELDS = dict(
    device_profile_fields, device_profile_id=s.String(validate=s.Length(min=1)))


def make_port_speed_schema(allowed_speeds):
    speeds = set(sum([[speed.upper(), speed.lower()]
                      for speed in allowed_speeds], []))
    return s.Transform(s.Enum(speeds), post_load=lambda data: data.upper())


PortSpeed = make_port_speed_schema([
    '10M',
    '100M',
    '1G',
    '2500M',
    '5G',
    '10G',
    '25G',
    '40G',
    '50G',
    '100G',
])


class Schema(s.Schema):
    nodes = {
        'system': s.NodeSchema('system', {
            'label': s.Optional(s.String()),
            'system_type': s.Enum(['switch', 'server']),
            'role': s.Enum(NODE_ROLES),
            'hostname': s.Optional(s.Hostname()),
            'system_id': s.Optional(s.String()),
            'deploy_mode': s.Optional(s.Enum(['deploy', 'undeploy', 'ready'])),
            'position': s.Optional(s.Integer()),
        }, indexes=[('role', 'deploy_mode')]),
        'rack': {
            'label': s.Optional(s.String(validate=[s.Length(min=1)])),
            'rack_type_json': s.Optional(
                s.String(validate=[s.Length(min=1)]),
                description=(
                    'Contains corresponding JSON-serialized rack type from '
                    'which this rack node was generated.'
                ),
            ),
        },
        'redundancy_group': {
            'label': s.Optional(s.String()),
            # rg_id is Optional with load default to facilitate upgrade path from
            # 2.1 blueprints, whose redundancy_group nodes have no rg_id defined.
            # Validator ensures that rg_id is unique in the blueprint.
            'rg_id': s.Optional(
                s.Integer(
                    validate=s.Range(min=1),
                    description='Unique ID for the redundancy group across the '
                                'blueprint. Currently used for rendering unique '
                                'anycast mac address for Cumulus MLAG leaf pairs.'),
                load_default=1),
        },
        'link': {
            'label': s.Optional(s.String()),
            'link_type': s.Enum([
                'ethernet', 'aggregate_link', 'logical_link'
            ], description='Ethernet links are physical links. Aggregate links '
                           'connect port channels. Logical links connect '
                           'logical interfaces sucha as sub-interfaces.'),
            'role': s.Enum(['spine_leaf', 'leaf_l2_server', 'leaf_l3_server',
                            'leaf_pair_l2_server', 'leaf_peer_link',
                            'to_external_router',
                            # This could have been called spine_peer_link but going
                            # with this to make it consistent with most other link
                            # roles and to leave it open for modeling links between
                            # spines for purposes other than mlag peering (ex:
                            # anycast RP in case of multicast). We could change
                            # leaf_peer_link to leaf_leaf but keeping it same as l3
                            # clos schema has many benefits that outweigh this small
                            # inconsistency concerns
                            'spine_spine',
                            # Represents connectivity between external routers.
                            # This is used when external router that is directly
                            # facing a leaf/spine is itself managed by an AOS
                            # agent. In such cases, we want to represent external
                            # neighbors of external router and use this role to
                            # represent links between ER and its external neighbors
                            'external_router_external_router']),
            'speed': s.Optional(PortSpeed),
        },
        'interface': {
            'label': s.Optional(s.String()),
            'if_type': s.Enum([
                'ip', 'loopback', 'ethernet', 'svi', 'port_channel', 'subinterface'
            ], description='Type of interface. '
                           'subinterface: has composed_of relationship with '
                           'parent interface'),
            'if_name': s.Optional(s.String()),
            # Since '?' (code 63) is forbidden, listing allowed characters
            # as two ranges: [<space> - >] (codes 32 - 62) and
            # [@ - ~] (codes 64 - 126).
            'description': s.Optional(
                s.String(validate=[
                    s.Length(max=240),
                    s.Regexp(
                        r'\A([!->@-~]([ ->@-~]*[!->@-~])?)?\Z',
                        error=(
                            'Invalid interface description. Only ASCII characters '
                            'with codes 32 - 126, except "?" are allowed. The '
                            'description should not start or end with a space.'
                        )
                    )
                ])
            ),
            'mode': s.Optional(s.Enum(['trunk', 'access'])),
            'ipv4_addr': s.Optional(s.IpNetworkAddress()),
            'port_channel_id': s.Optional(s.Integer()),
            'mlag_id': s.Optional(s.Integer()),
            'protocols': s.Optional(s.Enum(['ebgp', 'iccp'])),
            'loopback_id': s.Optional(s.LoopbackId(
                description='For interfaces with if_type != loopback, this field is '
                            'unused - recommend setting to None. '
                            'For interfaces with if_type == loopback, this is used '
                            'to index loopbacks of the system. Loopback '
                            'interface names are generated based on this ID and '
                            'the OS of that system. The value must be unique across '
                            'loopbacks of a system. The value 0 is always assigned '
                            'to the loopback in default security zone. The value 1 '
                            'is reserved for VTEP. Therefore, loopbacks for '
                            'non-default security zone and for multicast should '
                            'have indices starting from 2. Loopbacks associated '
                            'with the same security zone may have same or different '
                            'index, though security zone facade API strives to '
                            'assign the same index to loopbacks from same SZ.'
            )),
        },
        'domain': {
            'label': s.Optional(s.String()),
            'domain_type': s.Enum(['autonomous_system', 'area', 'mlag']),
            'domain_id': s.Optional(s.String()),
        },
        'virtual_network': {
            'label': s.Optional(s.VirtualNetworkLabel()),
            'vn_type': s.Enum(['vlan']),
            'vn_id': s.Optional(s.VirtualNetworkId()),
            'description': s.Optional(s.Description()),
            'ipv4_subnet': s.Optional(s.IpNetworkAddressOrPrefix()),
            'virtual_mac': s.Optional(s.MacAddress()),
            'virtual_gateway_ipv4': s.Optional(s.IpAddress()),
        },
        'vn_instance': {
            'label': s.Optional(s.String()),
            'vlan_id': s.Optional(s.VlanId()),
            'l3_enabled': s.Boolean(),
            'dhcp_enabled': s.Boolean(),
        },
        'vn_endpoint': {
            'label': s.Optional(s.String()),
            'tag_type': s.Enum(['vlan_tagged', 'untagged']),
        },
        'logical_device': {
            'label': s.Optional(s.String()),
            'json': s.String(),
        },
        'interface_map': interface_map_fields,
        'device_profile': DP_FIELDS,
        # TODO(Rags): Remove 2 node types below once AOS-9347 is fixed
        'fabric_addressing_policy': {
            'label': s.Optional(s.String()),
            'spine_leaf_links': s.Optional(s.Enum(['ipv4', 'ipv6', 'ipv4_ipv6']),
                                           load_default='ipv4'),
        },
        'virtual_network_policy': {
            'label': s.Optional(s.String()),
            'overlay_control_protocol': s.Optional(s.Enum([
                'evpn',
            ]), description='Control protocol for inter-rack virtual networks. '\
                            'If None, then no control plane is used, and head-end '\
                            'replication in data plane is used exclusively for '\
                            'MAC learning. If "evpn", then EPVN control protocol '\
                            'run on leafs and spines. '
                            'Please refer to AOS documentation for matrix of '\
                            'supported fabric control protocols vs device '\
                            'vendors / models.')
        },
    }

    relationships = [
        {
            'source': 'system',
            'type': 'part_of_rack',
            'target': 'rack',
        },
        {
            'source': 'redundancy_group',
            'type': 'part_of_rack',
            'target': 'rack',
        },
        {
            'source': 'system',
            'type': 'hosted_interfaces',
            'target': 'interface',
        },
        {
            'source': 'interface',
            'type': 'composed_of',
            'target': 'interface',
        },
        {
            'source': 'interface',
            'type': 'link',
            'target': 'link',
        },
        {
            'source': 'domain',
            'type': 'composed_of_systems',
            'target': 'system',
        },
        {
            'source': 'domain',
            'type': 'composed_of_redundancy_group',
            'target': 'redundancy_group',
        },
        {
            'source': 'domain',
            'type': 'composed_of_interfaces',
            'target': 'interface',
        },
        {
            'source': 'system',
            'type': 'part_of_redundancy_group',
            'target': 'redundancy_group',
        },
        {
            'source': 'redundancy_group',
            'type': 'composed_of_systems',
            'target': 'system',
        },
        {
            'source': 'redundancy_group',
            'type': 'hosted_interfaces',
            'target': 'interface',
        },
        s.RelationshipSchema(
            type='instantiated_by',
            source_type='virtual_network',
            target_type='vn_instance',
            sticky=True,
        ),
        {
            'source': 'vn_instance',
            'type': 'instantiates',
            'target': 'virtual_network',
        },
        s.RelationshipSchema(
            type='hosted_vn_instances',
            source_type='system',
            target_type='vn_instance',
            sticky=True,
        ),
        s.RelationshipSchema(
            type='member_endpoints',
            source_type='virtual_network',
            target_type='vn_endpoint',
            sticky=True,
        ),
        {
            'source': 'vn_endpoint',
            'type': 'member_of',
            'target': 'virtual_network',
        },
        s.RelationshipSchema(
            type='hosted_vn_endpoints',
            source_type='system',
            target_type='vn_endpoint',
            sticky=True,
        ),
        s.RelationshipSchema(
            type='hosted_vn_endpoints',
            source_type='interface',
            target_type='vn_endpoint',
            sticky=True,
        ),
        s.RelationshipSchema(
            type='member_interfaces',
            source_type='vn_instance',
            target_type='interface',
            sticky=True,
        ),
        {
            'source': 'interface',
            'type': 'member_of_vn_instance',
            'target': 'vn_instance',
        },
        {
            'source': 'system',
            'type': 'logical_device',
            'target': 'logical_device',
        },
        {
            'source': 'system',
            'type': 'interface_map',
            'target': 'interface_map',
        },
        {
            'source': 'interface_map',
            'type': 'device_profile',
            'target': 'device_profile',
        },
        {
            'source': 'interface_map',
            'type': 'logical_device',
            'target': 'logical_device',
        },
    ]
