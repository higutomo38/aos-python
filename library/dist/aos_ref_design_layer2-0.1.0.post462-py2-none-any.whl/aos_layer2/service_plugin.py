# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

from aos.sdk.builder import rule
from aos.sdk.graph.query import match, node, is_in


class ServicePlugin(object):
    def get_system_id_from_node(self, system_node):
        return system_node.id

    @rule(match(
        node('system', role=is_in(['spine', 'leaf', 'l3_server']), name='system')
    ))
    def render_collectors(self, path):
        return {
            'system_node': path['system'],
            'services': [
                {
                    'name': 'lldp',
                    'schema': 'aos.sdk.telemetry.schemas.lldp',
                    'interval': 10
                },
                {
                    'name': 'hostname',
                    'schema': 'aos.sdk.telemetry.schemas.hostname'
                },
                {
                    'name': 'route',
                    'schema': 'aos.sdk.telemetry.schemas.route'
                },
                {
                    'name': 'arp',
                    'schema': 'aos.sdk.telemetry.schemas.arp'
                },
                {
                    'name': 'bgp',
                    'schema': 'aos.sdk.telemetry.schemas.bgp'
                },
                {
                    'name': 'xcvr',
                    'schema': 'aos.sdk.telemetry.schemas.xcvr'
                },
                {
                    'name': 'mac',
                    'schema': 'aos.sdk.telemetry.schemas.mac'
                },
                {
                    'name': 'lag',
                    'schema': 'aos.sdk.telemetry.schemas.lag'
                },
                {
                    'name': 'mlag',
                    'schema': 'aos.sdk.telemetry.schemas.mlag'
                },
                {
                    'name': 'interface',
                    'schema': 'aos.sdk.telemetry.schemas.interface'
                }
            ]
        }
