# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula


def render_system(system, graph):
    return {
        "hostname": system.hostname,
        "loopback": [
            {
                "ipv6_addr": None,
                "ipv4_addr": li.ipv4_addr,
                "id": li.id,
            }
            for li in graph.traverse(system).out('hosted_interfaces').node(
                'interface', if_type='loopback')
        ],
        "system_id": system.system_id,
        "part_of_redundancy_group_targets": [
            {
                "id": rg.id
            }
            for rg in graph.traverse(system).out('part_of').node('redundancy_group')
        ],
        "composed_of_systems_domain_sources": [
            {
                "domain_id": d.domain_id
            }
            for d in graph.traverse(system).in_('composed_of_systems').node('domain')
        ],
        "label": system.label,
        "part_of_rack_targets": [
            {
                "id": r.id
            }
            for r in graph.traverse(system).out('part_of_rack').node('rack')
        ],
        "role": system.role,
        "deploy_mode": system.deploy_mode,
        "interface_map_targets": [
            {
                "device_profile_targets": [
                    {
                        "id": dp.id,
                        "label": dp.label
                    }
                ],
                "device_profile_id": im.device_profile_id,
                "id": im.id,
                "label": im.label
            }
            for im in graph.traverse(system).out('interface_map').node(
                'interface_map')
            for dp in graph.traverse(im).out('device_profile').node('device_profile')
        ],
        "logical_device_targets": [
            {
                "id": ld.id,
                "label": ld.label
            }
            for ld in graph.traverse(system).out('logical_device').node(
                'logical_device')
        ],
        "id": system.id,
    }


def render_svi(svi, graph):
    return {
        "composed_of_interfaces_sources": [
            {
                "domain_id": d.domain_id
            }
            for d in graph.traverse(svi).in_('composed_of_interfaces').node('domain')
        ],
        "ipv4_addr": svi.ipv4_addr
    }


def render_rg(rg, graph):
    return {
        "composed_of_systems_targets": [
            {
                "id": s.id,
                "label": s.label
            }
            for s in graph.traverse(rg).out('composed_of_systems').node('system')
        ],
        "id": rg.id,
        "label": rg.label
    }


def get_systems(graph):
    return {
        "version": graph.version,
        "data": {
            "leaf": [
                render_system(l, graph)
                for l in graph.get_nodes('system', role='leaf')
            ],
            "svi": [
                render_svi(svi, graph)
                for svi in graph.get_nodes('interface', if_type='svi')
            ],
            "spine": [
                render_system(l, graph)
                for l in graph.get_nodes('system', role='spine')
            ],
            "redundancy_group_nodes": [
                render_rg(rg, graph)
                for rg in graph.get_nodes('redundancy_group')
            ],
            "logical_link": [],  # N/A for layer2
            "configlet_nodes": [],  # N/A for layer2
            "external_router": [
                render_system(l, graph)
                for l in graph.get_nodes('system', role='external_router')
            ],
            "l3_server": [
                render_system(l, graph)
                for l in graph.get_nodes('system', role='l3_server')
            ],
            "l2_server": [
                render_system(l, graph)
                for l in graph.get_nodes('system', role='l2_server')
            ],
        }
    }
