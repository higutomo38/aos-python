# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

from collections import defaultdict
import aos.sdk.schema as s
from aos.sdk.graph.query import iterate, match, node, is_in, optional


LINK_ENDPOINT_SCHEMA = s.Dict({
    'system': s.Dict({
        'id': s.NodeId(description='ID of system node at link endpoint'),
        'label': s.Optional(s.String(
            description='System node label, created during blueprint generation')),
        'group_label': s.Optional(s.String(
            description='Label of a group this system belongs to, '
                        'provided by user')),
        'role': s.String(),
        'interface_map_id': s.Optional(s.String()),
        'logical_device_id': s.Optional(s.String()),
    }),
    'interface': s.Dict({
        'id': s.NodeId(description='ID of interface node at link endpoint'),
        'if_type': s.String(),
        'if_name': s.Optional(s.String()),
        'vn_endpoint': s.Optional(s.Dict({
            'id': s.NodeId(description='ID of virtual network endpoint node'),
            'tag_type': s.Enum(['vlan_tagged', 'untagged']),
        })),
    }),
})


LINK_SCHEMA = s.Dict({
    'id': s.NodeId(description='ID of the link node'),
    'label': s.Optional(s.String(
        description='Link node label, created during blueprint generation')),
    'group_label': s.Optional(s.String(
        description='Label of a group this link belongs to, provided by user')),
    'endpoints': s.List(LINK_ENDPOINT_SCHEMA),
})


LINKS_GET_SCHEMA = s.Dict({
    'links': s.List(LINK_SCHEMA)
})


LINK_DIGEST_SCHEMA = s.Dict({
    'id': s.NodeId(description='ID of the link node'),
    'label': s.Optional(s.String(
        description='Link node label, created during blueprint generation'
    )),
    'group_label': s.Optional(s.String(
        description='Label of a group this link belongs to, provided by user')),
})


LINKS_GET_DIGEST_SCHEMA = s.Dict(
    key_type=s.NodeId(description='ID of leaf or resource group node '
                                  'at link endpoint'),
    values=s.List(LINK_DIGEST_SCHEMA)
)


def linked_systems(system1=None, system2=None,
                   interface1='interface1', interface2='interface2',
                   link=None, system1_type='system'):
    return (
        node(system1_type, name=system1)
        .out('hosted_interfaces')
        .node('interface', name=interface1)
        .out('link')
        .node('link', name=link)
        .in_('link')
        .node('interface', name=interface2)
        .in_('hosted_interfaces')
        .node('system', name=system2)
        .ensure_different(interface1, interface2)
    )


def vn_with_instantiating_systems(
        device='device', virtual_network='virtual_network'):
    '''Return path query for virtual netwworks and the leafs it is hosted on.'''
    return (
        node('virtual_network', name=virtual_network)
        .out('instantiated_by')
        .node('vn_instance', name='vn_instance')
        .in_('hosted_vn_instances')
        .node('system', name=device, role='leaf')
    )


def make_link(link):
    return {
        'id': link.id,
        'label': link.label,
        'group_label': getattr(link, 'group_label', None),
    }


def make_link_mapping(link, endpoints=None,
                      leaf_id_to_imap_id=None, leaf_id_to_ld_id=None,
                      intf_id_to_vn_ep=None):
    result = make_link(link)
    if endpoints:
        if not leaf_id_to_imap_id:
            leaf_id_to_imap_id = {}
        if not leaf_id_to_ld_id:
            leaf_id_to_ld_id = {}
        if not intf_id_to_vn_ep:
            intf_id_to_vn_ep = {}

        def make_vn_endpoint_dict(vn_endpoint):
            if not vn_endpoint:
                return None
            return {
                'id': vn_endpoint.id,
                'tag_type': vn_endpoint.tag_type
            }

        result['endpoints'] = [
            {
                'interface': {
                    'id': intf.id,
                    'if_type': intf.if_type,
                    'if_name': intf.if_name,
                    'vn_endpoint': make_vn_endpoint_dict(
                        intf_id_to_vn_ep.get(intf.id))
                },
                'system': {
                    'id': system.id,
                    'label': system.label,
                    'group_label': getattr(system, 'group_label', None),
                    'role': system.role,
                    'interface_map_id': leaf_id_to_imap_id.get(system.id),
                    'logical_device_id': leaf_id_to_ld_id.get(system.id),
                },
            }
            for intf, system in endpoints
        ]
    return result


def get_leaf_server_links_digest(blueprint):
    """
    Get mapping of leaf (or rg) to a list of links that connect it to server nodes.

    This mapping includes only leafs that can host VN instances (e.g. leafs that are
    a part of a redundancy group are not included).
    The returned links are always "top-level" which means that if a link is a part
    of some other aggregate link it won't be included.
    """
    leaf_to_links = {}

    # Match links that connect leaf switches to servers, given that server-side
    # interfaces aren't a part of any other interface.
    leaf_server_links = match(
        linked_systems(system1='leaf', system2='server', link='link'),
        node(name='server', role=is_in(['l2_server', 'l3_server']))
    ).having(
        node(name='interface2').in_('composed_of'),
        names=['interface2'], at_most=0
    )
    for path in iterate(blueprint, leaf_server_links):
        leaf_to_links.setdefault(path['leaf'].id, []).append(make_link(path['link']))

    # Match links that connect leaf redundancy groups to servers. Such links are
    # always aggregates of highest level so there's not need to filter
    # server-side interfaces.
    leaf_pair_server_links = match(
        linked_systems(
            system1='leaf_pair', system2='server',
            link='link',
            system1_type='redundancy_group'),
        node(name='server', role=is_in(['l2_server', 'l3_server']))
    )
    for path in iterate(blueprint, leaf_pair_server_links):
        leaf_to_links.setdefault(path['leaf_pair'].id, []).append(
            make_link(path['link']))

    return leaf_to_links


def get_leaf_server_links(blueprint, vnet_id):
    """
    Retrieve a list of all links that connect leafs hosting instances
    of a given VN with server-side interfaces that can be assigned as
    VN endpoints.

    Each link contains an endpoints map where endpoint includes server
    "top-level" interface (to which a VN endpoint can be bound) and physical
    interfaces for leaf or leafs to which the logical link is connected
    (e.g. a link can be a bond to one leaf or it can be an aggregate link
    to a leaf pair).
    """
    links = []

    leaf_ids = set()
    leaf_pair_ids = set()
    link_id_to_link = {}
    leaf_id_to_imap_id = {}
    leaf_id_to_ld_id = {}
    interface_id_to_vn_endpoint = {}

    link_map = defaultdict(set)

    # Match leafs that host the virtual network as well as redundancy groups
    # they may be part of.
    vn_hosting_leafs = match(
        vn_with_instantiating_systems(device='leaf'),
        node(name='virtual_network', id=vnet_id),
        optional(
            node(name='leaf')
            .out('part_of_redundancy_group')
            .node('redundancy_group', name='leaf_pair')
        )
    )
    for path in iterate(blueprint, vn_hosting_leafs):
        leaf_ids.add(path['leaf'].id)
        if path['leaf_pair']:
            leaf_pair_ids.add(path['leaf_pair'].id)

    for path in iterate(blueprint, match(
            node('system', name='leaf', role='leaf', id=is_in(leaf_ids)),
            node(name='leaf').out('logical_device').node('logical_device',
                                                         name='logical_device'),
            optional(
                node(name='leaf').out('interface_map').node('interface_map',
                                                            name='interface_map'),
            )
    )):
        leaf_id_to_ld_id[path['leaf'].id] = path['logical_device'].id
        imap = path.get('interface_map')
        if imap:
            leaf_id_to_imap_id[path['leaf'].id] = imap.id

    # Match links that connect leaf switches to servers, given that server-side
    # interfaces aren't a part of any other interface. On leafs-side also try
    # to match any child physical interfaces.
    leaf_server_links = match(
        linked_systems(
            system1='leaf', system2='server', link='link'
        ).having(
            node(name='interface2').in_('composed_of'),
            names=['interface2'], at_most=0
        ),
        node(name='leaf', id=is_in(leaf_ids)),
        node(name='server', role='l2_server'),
        optional(
            node(name='interface1')
            .out('composed_of')
            .node('interface', name='ch_interface1',
                  if_type='ethernet'),
        ),
        optional(
            node(name='interface2')
            .out('hosted_vn_endpoints')
            .node('vn_endpoint', name='vn_endpoint')
            .out('member_of')
            .node('virtual_network', id=vnet_id)
        )
    )
    # For each top-level link we save its server endpoint and all leaf-side
    # physical endpoints. E.g. a bonded link between an L2 server and a leaf
    # would correspond to several physical interfaces on the leaf side.
    for path in iterate(blueprint, leaf_server_links):
        link_id_to_link[path['link'].id] = path['link']
        link_map[path['link'].id].add((path['interface2'], path['server']))

        leaf_iface = path['ch_interface1'] or path['interface1']
        link_map[path['link'].id].add((leaf_iface, path['leaf']))
        if path['vn_endpoint']:
            interface_id_to_vn_endpoint[path['interface2'].id] = path['vn_endpoint']

    # Match links that connect leaf redundancy groups to servers. Such links are
    # always aggregates of highest level so there's not need to filter
    # server-side interfaces.
    # On rg-side match physical interfaces on member leafs by going to
    # port channels under rg interface and then to their member interfaces.
    leaf_pair_server_links = match(
        linked_systems(
            system1='leaf_pair', system2='server',
            link='link',
            system1_type='redundancy_group'),
        node(name='leaf_pair', id=is_in(leaf_pair_ids)),
        node(name='server', role='l2_server'),
        (
            node(name='interface1')
            .out('composed_of')
            .node('interface', if_type='port_channel')
            .out('composed_of')
            .node('interface', name='ch_interface',
                  if_type='ethernet')
            .in_('hosted_interfaces')
            .node('system', name='leaf')
        ),
        optional(
            node(name='interface2')
            .out('hosted_vn_endpoints')
            .node('vn_endpoint', name='vn_endpoint')
            .out('member_of')
            .node('virtual_network', id=vnet_id)
        )
    )
    # For each top-level link we save its server endpoint and all leaf-side
    # physical endpoints.
    for path in iterate(blueprint, leaf_pair_server_links):
        link_id_to_link[path['link'].id] = path['link']
        link_map[path['link'].id].add((path['interface2'], path['server']))
        link_map[path['link'].id].add((path['ch_interface'], path['leaf']))
        if path['vn_endpoint']:
            interface_id_to_vn_endpoint[path['interface2'].id] = path['vn_endpoint']

    for link_id, endpoints in link_map.iteritems():
        links.append(make_link_mapping(link_id_to_link[link_id],
                                       endpoints,
                                       leaf_id_to_imap_id,
                                       leaf_id_to_ld_id,
                                       interface_id_to_vn_endpoint))

    return links
