# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula


import aos.sdk.schema as s
from aos.sdk.graph.query import iterate, node, match
from aos.sdk.reference_design.two_stage_l3clos.search import get_system_servers


RACK_SCHEMA = s.Dict({
    'rack_id': s.NodeId(
        description=('ID of leaf pair system node (dual-leaf rack) or '
                     'ID of the leaf system node (single-leaf rack)')
    ),
    'label': s.String(),
    'leafs': s.List(s.Dict({
        'id': s.NodeId(),
        'label': s.String(),
    })),
    'servers': s.List(s.Dict({
        'id': s.NodeId(),
        'label': s.String(),
    })),
})


def make_rack(rack, leafs, servers):
    return {
        'rack_id': rack.id,
        'label': rack.label,
        'leafs': [
            {
                'id': leaf.id,
                'label': leaf.label,
            }
            for leaf in leafs
        ],
        'servers': [
            {
                'id': server.id,
                'label': server.label,
            }
            for server in servers
        ],
    }


def get_servers(blueprint, leaf):
    return get_system_servers(
        blueprint, leaf, server_roles=['l2_server', 'l3_server'])


def get_racks(blueprint):
    leaf_pair_to_leafs = {}
    for path in iterate(blueprint, match(
            node('redundancy_group', name='leaf_pair')
            .out('composed_of_systems')
            .node('system', name='leaf', role='leaf'))):
        leaf_pair_to_leafs.setdefault(path['leaf_pair'], []).append(path['leaf'])

    single_leafs = set(blueprint.get_nodes('system', role='leaf')) - \
        set(sum(leaf_pair_to_leafs.itervalues(), []))

    dual_leaf_racks = [
        make_rack(leaf_pair, leafs,
                  set(sum((get_servers(blueprint, leaf) for leaf in leafs), [])))
        for leaf_pair, leafs in leaf_pair_to_leafs.iteritems()
    ]

    single_leaf_racks = [
        make_rack(leaf, [leaf], get_servers(blueprint, leaf))
        for leaf in single_leafs
    ]

    return dual_leaf_racks + single_leaf_racks
