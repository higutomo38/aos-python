# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula


import aos.sdk.schema as s
import aos.sdk.graph.query as q

try:
    from aos.sdk.reference_design.two_stage_l3clos.schema import PortSpeed
except ImportError:
    # ProtSpeed is moved to aos.sdk.schema by AOS-14226
    PortSpeed = s.PortSpeed


CABLING_MAP_ENDPOINT_SCHEMA = s.Dict({
    # Optional system because routers may not be assigned to external router
    # links yet
    'system': s.Optional(s.Dict({
        'id': s.NodeId(description='ID of system node at link endpoint'),
        'label': s.Optional(s.String()),
        'role': s.String(),
    })),
    'interface': s.Dict({
        'id': s.NodeId(description='ID of interface node at link endpoint'),
        'if_type': s.String(),
        'if_name': s.Optional(s.String()),
        'ipv4_addr': s.Optional(s.IpNetworkAddress()),
        'ipv6_addr': s.Optional(s.Ipv6NetworkAddress()),
    }),
})


CABLING_MAP_LINK_SCHEMA = s.Dict({
    'id': s.NodeId(description='ID of the link node'),
    'label': s.Optional(s.String()),
    'role': s.String(),
    'speed': s.Optional(PortSpeed),
    'endpoints': s.List(CABLING_MAP_ENDPOINT_SCHEMA)
})


CABLING_MAP_GET_SCHEMA = s.Dict({
    'links': s.List(CABLING_MAP_LINK_SCHEMA)
})


def get_cabling_map(blueprint, include_aggregate_links=True):
    links = {}

    def add_endpoint(link, system, interface):
        if link.id not in links:
            links[link.id] = {
                'id': link.id,
                'label': link.label,
                'role': link.role,
                'speed': link.speed,
                'endpoints': [],
            }
        links[link.id]['endpoints'].append({
            'system': {
                'id': system.id,
                'label': system.label,
                'role': system.role,
            } if system is not None else None,
            'interface': {
                'id': interface.id,
                'if_type': interface.if_type,
                'if_name': interface.if_name,
                'ipv4_addr': interface.ipv4_addr,
                'ipv6_addr': None,
            }
        })

    fabric_links = q.iterate(blueprint, q.match(
        q.node('link', name='link',
               role=q.not_in(['leaf_pair_l2_server', 'to_external_router']))
        .in_('link')
        .node('interface', name='interface')
        .in_('hosted_interfaces')
        .node('system', name='system')
        .where(lambda link: (
            include_aggregate_links or link.link_type != 'aggregate_link'))
    ))

    for path in fabric_links:
        add_endpoint(path['link'], path['system'], path['interface'])

    # Not all router links have both endpoints - router is missing before assigned
    router_links = q.iterate(blueprint, q.match(
        q.node('link', name='link', role='to_external_router',
               link_type=q.not_in(['logical_link']))
        .in_('link')
        .node('interface', name='interface')
        .where(lambda link: (
            include_aggregate_links or link.link_type != 'aggregate_link'))
    ))

    for path in router_links:
        interface = path['interface']
        system = (
            blueprint.traverse(interface)
            .in_('hosted_interfaces')
            .source('system').first
        )
        add_endpoint(path['link'], system, interface)

    return links.values()
