# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

import aos.sdk.schema as s


class DictObject(object):
    def __init__(self, attrs):
        self._attrs = attrs

    def __getattr__(self, name):
        return self._attrs[name]


ENDPOINT_SCHEMA = s.Object({
    'label': s.Optional(s.String(validate=s.Length(min=1)), load_default=''),
    'interface_id': s.String(validate=s.Length(min=1)),
    'tag_type': s.Optional(s.Enum(['vlan_tagged', 'untagged']),
                           load_default='vlan_tagged'),
})

BOUND_TO_SCHEMA = s.Object({
    'system_id': s.String(validate=s.Length(min=1)),
    'vlan_id': s.Optional(s.VlanId()),
})


SVI_IP_GET_SCHEMA = s.Object({
    'system_id': s.String(validate=s.Length(min=1)),
    'ipv4_addr': s.Optional(s.IpNetworkAddress()),
})


VIRTUAL_NETWORK_GET_BRIEF_SCHEMA = s.Object({
    'id': s.NodeId(),
    'label': s.String(validate=s.Length(min=1, max=s.MAX_VN_LABEL_SIZE)),
    'description': s.Optional(s.Description()),
    'vn_type': s.Enum(['vlan', 'vxlan']),
    'bound_to': s.List(BOUND_TO_SCHEMA),
    'vn_id': s.Optional(s.VirtualNetworkId()),
    'ipv4_subnet': s.Optional(s.IpNetworkAddressOrPrefix()),
    'virtual_gateway_ipv4': s.Optional(s.IpAddress()),
    'virtual_mac': s.Optional(s.MacAddress()),
    'l3_connectivity': s.Enum(['l3Disabled', 'l3Enabled']),
    'dhcp_service': s.Enum(['dhcpServiceDisabled', 'dhcpServiceEnabled']),
    'security_zone_id': s.Optional(s.NodeId(
        description='Node ID of security zone of which this virtual network '
                    'is a member.'
    )),
})


VIRTUAL_NETWORK_GET_SCHEMA = s.Object(VIRTUAL_NETWORK_GET_BRIEF_SCHEMA, {
    'svi_ips': s.List(SVI_IP_GET_SCHEMA),
    'endpoints': s.List(ENDPOINT_SCHEMA),
})


DEFAULT_SECURITY_ZONE_ID = 'default_security_zone_id'


def get_virtual_network(graph, virtual_network_id):
    vn = graph.get_node(virtual_network_id)
    vnis = list(graph.traverse(vn).out('instantiated_by').node('vn_instance'))
    vni_to_system = {
        vni: graph.traverse(vni).in_('hosted_vn_instances').node('system').first
        for vni in vnis
    }

    def vni_to_svi_ip(vni):
        svi = graph.traverse(vni).out('member_interfaces').node('interface').first
        return svi.ipv4_addr if svi else None

    def vne_interface(vne):
        return graph.traverse(vne).in_('hosted_vn_endpoints').node('interface').first

    res = {
        'id': virtual_network_id,
        'label': vn.label,
        'description': vn.description,
        'vn_type': vn.vn_type,
        'bound_to': [
            DictObject({
                'system_id': vni_to_system[vni].system_id,
                'vlan_id': vni.vlan_id,
            })
            for vni in graph.traverse(vn).out('instantiated_by').node('vn_instance')
        ],
        'vn_id': vn.vn_id,
        'ipv4_subnet': vn.ipv4_subnet,
        'virtual_gateway_ipv4': vn.virtual_gateway_ipv4,
        'virtual_mac': vn.virtual_mac,
        'l3_connectivity': 'l3Enabled' if vnis[0].l3_enabled else 'l3Disabled',
        'dhcp_service': (
            'dhcpServiceEnabled' if vnis[0].dhcp_enabled else 'dhcpServiceDisabled'
        ),
        'security_zone_id': DEFAULT_SECURITY_ZONE_ID,
        'svi_ips': [
            DictObject({
                'system_id': vni_to_system[vni].system_id,
                'ipv4_addr': svi_ip,
            })
            for vni in vnis
            for svi_ip in [vni_to_svi_ip(vni)]
            if svi_ip
        ],
        'endpoints': [
            DictObject({
                'label': vne.label or '',
                'interface_id': vne_interface(vne).id,
                'tag_type': vne.tag_type,
            })
            for vne in graph.traverse(vn).out('member_endpoints').node('vn_endpoint')
        ],
    }
    return DictObject(res)


SECURITY_ZONE_BASE_FIELDS = {
    'label': s.String(),
    'sz_type': s.Enum(['l3_fabric']),
    'vni_id': s.Optional(s.VxlanId()),
    'vlan_id': s.Optional(s.VlanId()),
    'vrf_name': s.String(),
}


SECURITY_ZONE_GET_SCHEMA = dict(SECURITY_ZONE_BASE_FIELDS, **{
    'id': s.NodeId(),
})


def get_security_zone(graph, security_zone_id):
    assert security_zone_id == 'default', str(locals())
    return {
        'id': DEFAULT_SECURITY_ZONE_ID,
        'label': 'default',
        'sz_type': 'l3_fabric',
        'vni_id': None,
        'vlan_id': None,
        'vrf_name': 'default',
    }
