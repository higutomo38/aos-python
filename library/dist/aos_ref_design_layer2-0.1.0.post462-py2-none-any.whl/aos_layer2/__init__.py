# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

# We need all these imports (albeit not used locally) here as AOS expects symbols by
# names used here

# Disable "imported but unused" error. This is required by design of AOS (and must
# be refactored IMHO)

from .blueprint_registry_plugin import BlueprintRegistryPlugin  # noqa: unused-import
from .builder import Builder as BuildRuleEngine  # noqa: unused-import
from .configuration_renderer import ConfigurationRenderer  # noqa: unused-import
from .facade import Facade  # noqa: unused-import
from .schema import Schema  # noqa: unused-import
from .service_plugin import ServicePlugin  # noqa: unused-import
from .telemetry import ExpectationRenderers  # noqa: unused-import
from .validator import Validator  # noqa: unused-import


TelemetryProcessors = {}


alert_types = [
    'bgp', 'cabling', 'counter', 'interface', 'hostname', 'liveness', 'route',
    'deployment', 'blueprint_rendering', 'probe', 'streaming', 'headroom', 'mac',
    'arp', 'lag', 'mlag', 'series', 'all'
]


roles = ['unknown', 'unused', 'lo0', 'fabric', 'leaf_server', 'l3edge', 'l2edge',
         'spine_leaf', 'fabric_spine', 'external_router', 'to_external_router',
         'leaf_l3_server', 'leaf_l2_server', 'leaf', 'l2_server', 'server',
         'spine', 'l3_server', 'peer', 'leaf_peer_link', 'spine_spine', 'leaf_pair',
         'leaf_pair_l2_server', 'all']
