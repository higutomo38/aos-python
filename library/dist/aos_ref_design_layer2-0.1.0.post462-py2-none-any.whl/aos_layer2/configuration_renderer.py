# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

from aos.sdk.graph import query as q
from aos.sdk.reference_design.configuration_rendering_plugin import \
    ConfigurationRenderingPlugin, ConfigGenerationResult


class ConfigurationRenderer(ConfigurationRenderingPlugin):
    def get_system_ids(self):
        return [
            dev.system_id
            for dev in self.graph.get_nodes(
                type='system',
                system_id=q.not_none(),
                deploy_mode=q.is_in(['deploy', 'ready'])
            )
        ]

    def generate_config(
            self, system_id, current_ctx, config_apply_mode, aos_version):
        return ConfigGenerationResult(
            True,
            'Config rendering is unsupported for layer2 reference designs'
        )

    def should_retry_deploy_on_failure(self, system_id=None):
        return True
