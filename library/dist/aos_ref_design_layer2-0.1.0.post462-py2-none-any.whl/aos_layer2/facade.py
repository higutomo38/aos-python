# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

import aos.sdk.schema as s
from aos.sdk.facade import Facade as BaseFacade, blueprint_initializer, \
    INIT_BLUEPRINT_DATA_SCHEMA, init_blueprint_explicitly, result_schema, web_api, \
    arg_schema
from facades import rack
from facades import cabling_map
from facades import experience
from facades import virtual_network as vn
from facades import leaf_server_links


EXPERIENCE_META_SCHEMA = s.Dict({
    'version': s.Integer(),
    'last_updated': s.String(),
})


class Facade(BaseFacade):
    def blueprint_digest(self):
        return {}

    @blueprint_initializer(
        'explicit', schema=INIT_BLUEPRINT_DATA_SCHEMA, is_default=True)
    def init_blueprint_explicitly(self, data):
        init_blueprint_explicitly(self.graph, data)

    @result_schema(s.Dict({
        'items': s.List(rack.RACK_SCHEMA)
    }))
    @web_api('/racks', 'GET')
    def get_racks(self):
        return dict(items=rack.get_racks(self.graph))

    @result_schema(
        cabling_map.CABLING_MAP_GET_SCHEMA
    )
    @web_api('/cabling-map', 'GET',
             skip_result_schema_dump=True)
    def get_cabling_map(self):
        return dict(links=cabling_map.get_cabling_map(self.graph))

    @result_schema(s.Dict({
        'items': s.List(rack.RACK_SCHEMA),
        'version': s.Integer(),
    }))
    @web_api('/experience/web/racks', 'GET', skip_result_schema_dump=True)
    def experience_web_racks(self):
        return {
            'items': rack.get_racks(self.graph),
            'version': self.graph.version,
        }

    @result_schema(EXPERIENCE_META_SCHEMA)
    @web_api('/experience/web/racks/meta', 'GET', skip_result_schema_dump=True)
    def experience_web_racks_meta(self):
        return {
            'version': self.graph.version,
            'last_updated': str(self.graph.version),
        }

    @result_schema(s.Dict({
        'data': s.Dict({'version': s.String()}),
        'version': s.Integer(),
    }))
    @web_api('/experience/web/systems', 'GET', skip_result_schema_dump=True)
    def experience_web_systems(self):
        return {
            'data': experience.get_systems(self.graph),
            'version': self.graph.version,
        }

    @result_schema(EXPERIENCE_META_SCHEMA)
    @web_api('/experience/web/systems/meta', 'GET', skip_result_schema_dump=True)
    def experience_web_systems_meta(self):
        return {
            'version': self.graph.version,
            'last_updated': str(self.graph.version),
        }

    @result_schema(s.Dict({
        'links': s.List(cabling_map.CABLING_MAP_LINK_SCHEMA),
        'version': s.Integer(),
    }))
    @arg_schema(aggregate_links=s.Optional(
        s.String(
            description=(
                'Include aggregate links into cabling map (false by default).'
            ),
            validate=s.AnyOf(['true', 'false']),
        ),
        load_default='false',
    ))
    @web_api('/experience/web/cabling-map', 'GET',
             skip_result_schema_dump=True)
    def experience_web_cabling_map(self, aggregate_links):
        return {
            'links': cabling_map.get_cabling_map(
                self.graph,
                include_aggregate_links=(aggregate_links == 'true')),
            'version': self.graph.version,
        }

    @result_schema(EXPERIENCE_META_SCHEMA)
    @web_api('/experience/web/cabling-map/meta', 'GET', skip_result_schema_dump=True)
    def experience_web_cabling_map_meta(self):
        return {
            'version': self.graph.version,
            'last_updated': str(self.graph.version),
        }

    @arg_schema(
        virtual_network_id=s.String()
    )
    @result_schema(
        vn.VIRTUAL_NETWORK_GET_SCHEMA
    )
    @web_api('/virtual-networks/<virtual_network_id>', 'GET')
    def get_virtual_network(self, virtual_network_id):
        return vn.get_virtual_network(self.graph, virtual_network_id)

    @arg_schema(virtual_network_id=s.String())
    @result_schema(leaf_server_links.LINKS_GET_SCHEMA)
    @web_api('/virtual-networks/<virtual_network_id>/leaf-server-links', 'GET')
    def get_leaf_server_links(self, virtual_network_id):
        """
        Retrieve a list of all links that connect leafs hosting instances
        of a given VN with server-side interfaces that can be assigned as
        VN endpoints.

        Each link contains an endpoints map where endpoint includes server
        "top-level" interface (to which a VN endpoint can be bound) and physical
        interfaces for leaf or leafs to which the logical link is connected
        (e.g. a link can be a bond to one leaf or it can be an aggregate link
        to a leaf pair).
        """

        return dict(links=leaf_server_links.get_leaf_server_links(
            self.graph, virtual_network_id))

    @arg_schema(
        security_zone_id=s.String()
    )
    @result_schema(
        s.Dict(vn.SECURITY_ZONE_GET_SCHEMA)
    )
    @web_api('/security-zones/<security_zone_id>', 'GET')
    def get_security_zone(self, security_zone_id):
        return vn.get_security_zone(self.graph, security_zone_id)
