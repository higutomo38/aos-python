# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

"""Plugin for BGP expectation rendering for 'layer2' reference design"""
from netaddr import IPNetwork

from aos.sdk.builder import rule, match, node
from aos.sdk.graph.query import not_none
import aos.sdk.graph.query as q
from aos.sdk.reference_design.expectation_rendering_plugin import \
    ExpectationRenderingPlugin
from ..patterns import (
    systems_with_asn, connected_physical_interfaces
)


def connected_bgp_peers(system_filters=None, remote_system_filters=None):
    """Base line for 'bgp_peers_using_<ip-version>_link_ips' methods.

    Returns:
      List of path queries for systems with assigned ASN numbers,
      physically connected through interfaces having bgp-related protocols.
      Named nodes are device, interface, link, remote_interface, remote_device,
      domain, remote_domain.
    """
    return [
        connected_physical_interfaces(),
        # Using additional node() queries instead of lambdas for better performance
        node(name='interface', protocols='ebgp'),
        node(name='remote_interface', protocols='ebgp'),
        systems_with_asn(system_filters=system_filters),
        systems_with_asn('remote_device', 'remote_domain',
                         system_filters=remote_system_filters)
    ]


def bgp_peers_using_v4_link_ips(system_filters=None, remote_system_filters=None):
    """
    Returns:
      List of path queries for systems with assigned ASN numbers, that are
      physically connected through ipv4 interfaces having bgp related protocols.
      Named nodes are device, interface, link, remote_interface, remote_device,
      domain, remote_domain.
    """
    return connected_bgp_peers() + [
        node(name='interface', ipv4_addr=not_none(), if_type='ip'),
        node(name='remote_interface', ipv4_addr=not_none(), if_type='ip')
    ]


def _ipv4(ipv4_str):
    return str(IPNetwork(ipv4_str, version=4).ip)


def bgp_expect_id(intf_node, asn_node, remote_asn_node,
                  vrf_name, addr_family):
    """ Creates a unique 'expect' ID. Prevent collision for vnets/vrfs """
    return '%s:%s:%s:%s:%s' % (
        intf_node.id, asn_node.id, remote_asn_node.id, vrf_name, addr_family)


def render_expect(role, source_ip, source_asn, dest_ip, dest_asn,
                  vrf_name='default', addr_family='ipv4'):
    return {
        'role': role,
        'identity': {
            'source_ip': source_ip,
            'source_asn': source_asn,
            'dest_ip': dest_ip,
            'dest_asn': dest_asn,
            'vrf_name': vrf_name,
            'addr_family': addr_family
        },
        'expected': {
            'value': 'up'
        }
    }


class BgpRenderer(ExpectationRenderingPlugin):

    # Get any connected physical interface path where both ends are part of some
    # autonomous system
    @rule(match(
        node(name='device', system_id=q.not_none()),
        *bgp_peers_using_v4_link_ips()
    ))
    def render_ipv4_bgp_links(self, path, action):
        def bgp_session_generator():
            interface = path['interface']
            domain = path['domain']
            remote_interface = path['remote_interface']
            remote_domain = path['remote_domain']
            entry_id = bgp_expect_id(interface, domain, remote_domain,
                                     'default', 'ipv4')
            yield entry_id, lambda: render_expect(
                path['link'].role,
                _ipv4(interface.ipv4_addr), domain.domain_id,
                _ipv4(remote_interface.ipv4_addr), remote_domain.domain_id,
                'default', 'ipv4')

        self.render_bgp_links(path['device'], action, bgp_session_generator)

    def render_bgp_links(self, device, action, bgp_session_generator):
        """
        Depending on action, adds or removes expectations from the store.
        bgp_session_generator:
          generator function, which returns (entry_id, value_fn) tuple,
          value_fn is implemented as a function to have an ability not to
          make extra calls on data removal.
        """
        if action in ['added', 'updated']:
            for (entry_id, value_fn) in bgp_session_generator():
                self.expectation_store.add(device.id, 'bgp', entry_id, value_fn())
        else:
            for (entry_id, _) in bgp_session_generator():
                self.expectation_store.remove(device.id, 'bgp', entry_id)

    def get_service_system_id_map(self, graph):
        return {
            'bgp': {
                dev.id: dev.system_id
                for dev in graph.get_nodes(type='system', system_id=q.not_none())
            }
        }
