# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

from aos.sdk.builder import rule, match, node
from aos.sdk.graph.query import not_none, not_in

from aos.sdk.reference_design.expectation_rendering_plugin import (
    ExpectationRenderingPlugin
)


EXCLUDED_ROLES = ["l3_server", "l2_server", "external_router", "server"]
EXCLUDED_TYPES = ["redundancy_switch_group"]


class HostnameRenderer(ExpectationRenderingPlugin):
    @rule(
        match(
            node(
                "system",
                name="device",
                hostname=not_none(),
                system_id=not_none(),
                deploy_mode="deploy",
            )
        )
    )
    def render_hostname(self, path, action):
        key = {
            "node_id": path["device"].id,
            "service_name": "hostname",
            "element_id": path["device"].id,
        }

        data = {
            "role": path["device"].role,
            "identity": {"system_id": path["device"].system_id},
            "expected": {"hostname": path["device"].hostname},
        }

        if action in ["added", "updated"]:
            self.expectation_store.add(element_data=data, **key)
        else:
            self.expectation_store.remove(**key)

    def get_service_system_id_map(self, graph):
        return {
            "hostname": {
                dev.id: dev.system_id
                for dev in graph.get_nodes(
                    type="system", system_id=not_none(), role=not_in(EXCLUDED_ROLES)
                )
            }
        }
