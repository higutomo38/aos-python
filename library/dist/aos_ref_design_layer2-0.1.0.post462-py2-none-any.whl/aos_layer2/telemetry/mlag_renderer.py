# Copyright 2018, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

"""
MLAG expectation renderer for Layer 2 reference design

The only difference from L3Clos reference design is that Layer2 has MLAG links not
only for leaf-leaf and server-leaf, but also spine-spine and leaf-spine.
"""

from aos.sdk.builder import rule
from aos.sdk.graph import not_none, is_in
from aos.sdk.graph.query import node, match
from aos.sdk.reference_design.expectation_rendering_plugin import (
    ExpectationRenderingPlugin
)

from ..patterns import paired_systems_in_mlag_domain


def get_domain_state(device_one, device_two):
    domain_state = "disabled"
    if device_one.deploy_mode == device_two.deploy_mode == "deploy":
        domain_state = "active"
    return domain_state


def render_domain(domain, device_one, device_two):
    return {
        "role": device_one.role,
        "identity": {"domain_id": domain.domain_id},
        "expected": {"domain_state": get_domain_state(device_one, device_two)},
    }


def render_mlag_peer(peer_link):
    return {
        "identity": {"peer_link": peer_link.if_name},
        "expected": {"peer_link_state": "up"},
    }


def render_mlag(port_channel, mlag_intf):
    return {
        "identity": {"interface_name": port_channel.if_name},
        "expected": {"mlag_id": mlag_intf.mlag_id, "intf_state": "active_full"},
    }


class MlagRenderer(ExpectationRenderingPlugin):
    @rule(
        paired_systems_in_mlag_domain(
            system1="device_one", system2="device_two", domain="domain"
        )
    )
    def render_device_domain_state(self, path, action):
        node_id = path["device_one"].id
        element_id = path["domain"].id
        if action in ["added", "updated"]:
            data = render_domain(
                path["domain"], path["device_one"], path["device_two"]
            )
            self.expectation_store.add(node_id, "mlag", element_id, data)
        else:
            self.expectation_store.remove(node_id, "mlag", element_id)

    @rule(
        match(
            node(
                "system",
                name="device_one",
                system_id=not_none(),
                deploy_mode="deploy",
            )
            .out("hosted_interfaces")
            .node(
                "interface",
                name="peer_link_intf",
                if_type="port_channel",
                if_name=not_none(),
            )
            .out("link")
            .node(
                "link",
                name="peer_link",
                role=is_in(["leaf_peer_link", "spine_spine"]),
            )
        )
    )
    def render_peer_link(self, path, action):
        node_id = path["device_one"].id
        element_id = path["peer_link_intf"].id
        if action in ["added", "updated"]:
            element_data = render_mlag_peer(peer_link=path["peer_link_intf"])
            self.expectation_store.add(node_id, "mlag", element_id, element_data)
        else:
            self.expectation_store.remove(node_id, "mlag", element_id)

    @rule(
        match(
            node(
                "system",
                name="device_one",
                system_id=not_none(),
                deploy_mode="deploy",
            )
            .out("hosted_interfaces")
            .node(
                "interface",
                name="port_channel_intf",
                if_type="port_channel",
                if_name=not_none(),
            )
            .in_("composed_of")
            .node("interface", name="mlag_intf", if_type="port_channel")
            .out("link")
            .node("link")
            .in_("link")
            .node("interface", name="peer_mlag_intf", if_type="port_channel")
            .out("composed_of")
            .node("interface")
            .in_("hosted_interfaces")
            .node("system", deploy_mode="deploy")
            .ensure_different("mlag_intf", "peer_mlag_intf")
        )
        .select("device_one", "port_channel_intf", "mlag_intf")
        .distinct()
    )
    def render_mlag_id_and_port_channel(self, path, action):
        node_id = path["device_one"].id
        element_id = path["port_channel_intf"].id
        if action in ["added", "updated"]:
            element_data = render_mlag(
                port_channel=path["port_channel_intf"], mlag_intf=path["mlag_intf"]
            )
            self.expectation_store.add(node_id, "mlag", element_id, element_data)
        else:
            self.expectation_store.remove(node_id, "mlag", element_id)

    def get_service_system_id_map(self, graph):
        return {
            "mlag": {
                dev.id: dev.system_id
                for dev in graph.get_nodes(type="system", system_id=not_none())
            }
        }
