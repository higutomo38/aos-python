# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

import aos.sdk.graph.query as q
from aos.sdk.builder import rule, match, node
from aos.sdk.reference_design.expectation_rendering_plugin import (
    ExpectationRenderingPlugin
)
from ..patterns import connected_physical_interfaces, connected_port_channels


def render_interface(role, intf, state):
    return {
        "role": role,
        "identity": {"interface_name": intf},
        "expected": {"value": state},
    }


def should_render_path(path):
    remote_device = path["remote_device"]
    if remote_device.system_id:
        remote_deploy_modes = (
            ["deploy"]
            if path["interface"].if_type == "port_channel"
            else ["ready", "deploy"]
        )
        return remote_device.deploy_mode in remote_deploy_modes

    return remote_device.role == "external_router"


class InterfaceRenderer(ExpectationRenderingPlugin):
    @rule(
        match(
            connected_physical_interfaces(),
            node(
                name="device",
                system_id=q.not_none(),
                deploy_mode=q.is_in(["deploy", "ready"]),
            ),
            node(name="interface", if_name=q.not_none()),
        )
    )
    @rule(
        match(
            connected_port_channels(named_child_link="link"),
            node(name="device", system_id=q.not_none(), deploy_mode="deploy"),
            node(name="interface", if_name=q.not_none()),
        )
    )
    def render_interfaces(self, path, action):
        system_node_id = path["device"].id
        intf_node = path["interface"]
        link = path["link"]
        if action in ["added", "updated"] and should_render_path(path):
            self.expectation_store.add(
                system_node_id,
                "interface",
                intf_node.id,
                render_interface(link.role, intf_node.if_name, "up"),
            )
        else:
            self.expectation_store.remove(system_node_id, "interface", intf_node.id)

    def get_service_system_id_map(self, graph):
        return {
            "interface": {
                dev.id: dev.system_id
                for dev in graph.get_nodes(type="system", system_id=q.not_none())
            }
        }
