# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

"""Telemetry specific code for current reference design"""

from .bgp_renderer import BgpRenderer
from .hostname_renderer import HostnameRenderer
from .interface_renderer import InterfaceRenderer
from .lldp_renderer import LldpRenderer
from .mlag_renderer import MlagRenderer

ExpectationRenderers = [
    BgpRenderer,
    HostnameRenderer,
    InterfaceRenderer,
    LldpRenderer,
    MlagRenderer,
]
