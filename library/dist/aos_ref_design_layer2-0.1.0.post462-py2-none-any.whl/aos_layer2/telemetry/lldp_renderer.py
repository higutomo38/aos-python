# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

"""Plugin for LLDP expectation rendering for 'layer2' reference design"""

from aos.sdk.builder import rule, match, node
from aos.sdk.graph.query import is_in, not_none
from aos.sdk.reference_design.expectation_rendering_plugin import \
    ExpectationRenderingPlugin


def is_external_router_or_device(remote_device):
    # we always want to have lldp enabled with external routers irrespective of
    # their deploy-mode, to be consistent with two_stage_l3clos
    return remote_device.hostname and \
           (remote_device.role == 'external_router' or
            remote_device.deploy_mode in ['ready', 'deploy'])


class LldpRenderer(ExpectationRenderingPlugin):
    @rule(match(
        node('system', name='device',
             deploy_mode=is_in(['ready', 'deploy']),
             system_id=not_none())
        .out('hosted_interfaces')
        .node('interface', name='interface',
              if_type=is_in(['ip', 'ethernet']),
              if_name=not_none())
        .out('link')
        .node('link', name='link', link_type='ethernet')
        .in_('link')
        .node('interface', name='remote_interface')
        .in_('hosted_interfaces')
        .node('system', name='remote_device')
        .ensure_different('interface', 'remote_interface')
        .where(is_external_router_or_device, ['remote_device'])
    ))
    def render_lldp(self, path, action):
        """Generates LLDP expectations between blueprint systems."""
        key = {
            'node_id': path['device'].id,
            'service_name': 'lldp',
            'element_id': path['interface'].id
        }

        data = {
            'role': path['link'].role,
            'identity': {
                'interface_name': path['interface'].if_name,
            },
            'expected': {
                'neighbor_system_id': path['remote_device'].hostname,
                'neighbor_interface_name': path['remote_interface'].if_name
            },
        }
        if action in ['added', 'updated']:
            self.expectation_store.add(element_data=data, **key)
        else:
            self.expectation_store.remove(**key)

    def get_service_system_id_map(self, graph):
        return {
            'lldp': {
                dev.id: dev.system_id
                for dev in graph.get_nodes(type='system', system_id=not_none())
            }
        }
