# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

import os
from aos_layer2.schema import Schema
from aos_layer2.facades.experience import get_systems
from test_lib.util import graph_from_dict, read_json


def load_fixture(blueprint):
    return read_json(os.path.join(
        os.path.dirname(__file__), "fixtures", "blueprints", blueprint
    ))


def test_get_systems_with_external_routers():
    fn = "blueprint_2_3_1_layer2_2spines_3mlag_pairs_dell_os10_telemetry_store.json"
    bp = graph_from_dict(load_fixture(fn), Schema())
    systems = get_systems(bp)
    assert len(systems['data']['external_router']) == bp.get_nodes(
        'system', role='external_router').count, str(locals())
