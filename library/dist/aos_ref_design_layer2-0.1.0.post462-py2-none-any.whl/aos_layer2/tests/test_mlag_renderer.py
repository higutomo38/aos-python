# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula
import os

from test_lib.util import graph_from_dict, read_json
from aos_layer2.schema import Schema
from aos_layer2.telemetry.mlag_renderer import MlagRenderer


def fixture(blueprint):
    return os.path.join(
        os.path.dirname(__file__), "fixtures", "blueprints", blueprint
    )


def test_2_2_1l_blueprint_boeing_mlag_expectations(blueprint_expectation_generator):
    """
    Uses blueprint created from Boeing network using aos-cli network discovery logic.

    The telemetry store may be kept up to date with the one available in
    tests/fixtures/discover_cmd.
    """
    bp = graph_from_dict(
        read_json(
            fixture(
                "blueprint_2_2_1l_layer2_2mlag_spine_4mlag_leafs_dell_os10_"
                "telemetry_store.json"
            )
        ),
        Schema(),
    )

    expectation_generator = blueprint_expectation_generator(
        graph=bp, rule_classes=[MlagRenderer]
    )

    expectation_generator.on_graph(bp)

    expected = {
        "system_4": {
            "mlag": {
                "interface_43": {
                    "identity": {"peer_link": "port-channel1000"},
                    "expected": {"peer_link_state": "up"},
                },
                "domain_4": {
                    "identity": {"domain_id": "1"},
                    "role": "leaf",
                    "expected": {"domain_state": "active"},
                },
            }
        },
        "system_5": {
            "mlag": {
                "domain_4": {
                    "identity": {"domain_id": "1"},
                    "role": "leaf",
                    "expected": {"domain_state": "active"},
                },
                "interface_56": {
                    "identity": {"peer_link": "port-channel1000"},
                    "expected": {"peer_link_state": "up"},
                },
            }
        },
        "system_6": {
            "mlag": {
                "domain_3": {
                    "identity": {"domain_id": "1"},
                    "role": "spine",
                    "expected": {"domain_state": "active"},
                },
                "interface_36": {
                    "identity": {"peer_link": "port-channel1000"},
                    "expected": {"peer_link_state": "up"},
                },
            }
        },
        "system_2": {
            "mlag": {
                "interface_5": {
                    "identity": {"peer_link": "port-channel1000"},
                    "expected": {"peer_link_state": "up"},
                },
                "domain_5": {
                    "identity": {"domain_id": "1"},
                    "role": "leaf",
                    "expected": {"domain_state": "active"},
                },
            }
        },
        "system_3": {
            "mlag": {
                "interface_18": {
                    "identity": {"peer_link": "port-channel1000"},
                    "expected": {"peer_link_state": "up"},
                },
                "domain_5": {
                    "identity": {"domain_id": "1"},
                    "role": "leaf",
                    "expected": {"domain_state": "active"},
                },
            }
        },
        "system_8": {
            "mlag": {
                "domain_3": {
                    "identity": {"domain_id": "1"},
                    "role": "spine",
                    "expected": {"domain_state": "active"},
                },
                "interface_73": {
                    "identity": {"peer_link": "port-channel1000"},
                    "expected": {"peer_link_state": "up"},
                },
            }
        },
    }

    assert expectation_generator.store.expectations == expected


def test_2_3_0l_3mlag_pairs(blueprint_expectation_generator):
    """
    Uses blueprint created from Boeing network using aos-cli network discovery logic.

    The telemetry store may be kept up to date with the one available in
    tests/fixtures/discover_cmd.
    """
    bp = graph_from_dict(
        read_json(
            fixture(
                "blueprint_2_2_1l_layer2_2spines_3mlag_pairs_dell_os10_"
                "telemetry_store.json"
            )
        ),
        Schema(),
    )

    expectation_generator = blueprint_expectation_generator(
        graph=bp, rule_classes=[MlagRenderer]
    )

    expectation_generator.on_graph(bp)

    expected = {
        "border_leaf1_rack3": {
            "mlag": {
                "interface_162": {
                    "expected": {"mlag_id": 1, "intf_state": "active_full"},
                    "identity": {"interface_name": "port-channel1"},
                },
                "interface_163": {
                    "expected": {"mlag_id": 2, "intf_state": "active_full"},
                    "identity": {"interface_name": "port-channel2"},
                },
                "interface_166": {
                    "expected": {"mlag_id": 5, "intf_state": "active_full"},
                    "identity": {"interface_name": "port-channel5"},
                },
                "interface_167": {
                    "expected": {"mlag_id": 6, "intf_state": "active_full"},
                    "identity": {"interface_name": "port-channel6"},
                },
                "interface_164": {
                    "expected": {"mlag_id": 100, "intf_state": "active_full"},
                    "identity": {"interface_name": "port-channel100"},
                },
                "interface_165": {
                    "expected": {"mlag_id": 4, "intf_state": "active_full"},
                    "identity": {"interface_name": "port-channel4"},
                },
                "interface_169": {
                    "expected": {"peer_link_state": "up"},
                    "identity": {"peer_link": "port-channel1000"},
                },
                "domain_5": {
                    "role": "leaf",
                    "expected": {"domain_state": "active"},
                    "identity": {"domain_id": "1"},
                },
                "interface_155": {
                    "expected": {"mlag_id": 3, "intf_state": "active_full"},
                    "identity": {"interface_name": "port-channel3"},
                },
            }
        },
        "spine1": {
            "mlag": {
                "interface_14": {
                    "expected": {"peer_link_state": "up"},
                    "identity": {"peer_link": "port-channel1000"},
                },
                "domain_6": {
                    "role": "spine",
                    "expected": {"domain_state": "active"},
                    "identity": {"domain_id": "1"},
                },
                "interface_12": {
                    "expected": {"mlag_id": 100, "intf_state": "active_full"},
                    "identity": {"interface_name": "port-channel100"},
                },
                "interface_11": {
                    "expected": {"mlag_id": 101, "intf_state": "active_full"},
                    "identity": {"interface_name": "port-channel101"},
                },
                "interface_10": {
                    "expected": {"mlag_id": 102, "intf_state": "active_full"},
                    "identity": {"interface_name": "port-channel102"},
                },
            }
        },
        "spine2": {
            "mlag": {
                "interface_60": {
                    "expected": {"peer_link_state": "up"},
                    "identity": {"peer_link": "port-channel1000"},
                },
                "interface_58": {
                    "expected": {"mlag_id": 100, "intf_state": "active_full"},
                    "identity": {"interface_name": "port-channel100"},
                },
                "interface_57": {
                    "expected": {"mlag_id": 101, "intf_state": "active_full"},
                    "identity": {"interface_name": "port-channel101"},
                },
                "interface_56": {
                    "expected": {"mlag_id": 102, "intf_state": "active_full"},
                    "identity": {"interface_name": "port-channel102"},
                },
                "domain_6": {
                    "role": "spine",
                    "expected": {"domain_state": "active"},
                    "identity": {"domain_id": "1"},
                },
            }
        },
        "exchange_point_1": {"mlag": {}},
        "leaf2_rack2": {
            "mlag": {
                "interface_148": {
                    "expected": {"mlag_id": 2, "intf_state": "active_full"},
                    "identity": {"interface_name": "port-channel2"},
                },
                "domain_8": {
                    "role": "leaf",
                    "expected": {"domain_state": "active"},
                    "identity": {"domain_id": "1"},
                },
                "interface_140": {
                    "expected": {"mlag_id": 1, "intf_state": "active_full"},
                    "identity": {"interface_name": "port-channel1"},
                },
                "interface_141": {
                    "expected": {"mlag_id": 101, "intf_state": "active_full"},
                    "identity": {"interface_name": "port-channel101"},
                },
                "interface_142": {
                    "expected": {"mlag_id": 3, "intf_state": "active_full"},
                    "identity": {"interface_name": "port-channel3"},
                },
                "interface_143": {
                    "expected": {"mlag_id": 4, "intf_state": "active_full"},
                    "identity": {"interface_name": "port-channel4"},
                },
                "interface_144": {
                    "expected": {"mlag_id": 5, "intf_state": "active_full"},
                    "identity": {"interface_name": "port-channel5"},
                },
                "interface_145": {
                    "expected": {"mlag_id": 6, "intf_state": "active_full"},
                    "identity": {"interface_name": "port-channel6"},
                },
                "interface_147": {
                    "expected": {"peer_link_state": "up"},
                    "identity": {"peer_link": "port-channel1000"},
                },
            }
        },
        "leaf2_rack1": {
            "mlag": {
                "domain_7": {
                    "role": "leaf",
                    "expected": {"domain_state": "active"},
                    "identity": {"domain_id": "1"},
                },
                "interface_99": {
                    "expected": {"mlag_id": 1, "intf_state": "active_full"},
                    "identity": {"interface_name": "port-channel1"},
                },
                "interface_94": {
                    "expected": {"mlag_id": 102, "intf_state": "active_full"},
                    "identity": {"interface_name": "port-channel102"},
                },
                "interface_104": {
                    "expected": {"mlag_id": 6, "intf_state": "active_full"},
                    "identity": {"interface_name": "port-channel6"},
                },
                "interface_106": {
                    "expected": {"peer_link_state": "up"},
                    "identity": {"peer_link": "port-channel1000"},
                },
                "interface_100": {
                    "expected": {"mlag_id": 2, "intf_state": "active_full"},
                    "identity": {"interface_name": "port-channel2"},
                },
                "interface_101": {
                    "expected": {"mlag_id": 3, "intf_state": "active_full"},
                    "identity": {"interface_name": "port-channel3"},
                },
                "interface_102": {
                    "expected": {"mlag_id": 4, "intf_state": "active_full"},
                    "identity": {"interface_name": "port-channel4"},
                },
                "interface_103": {
                    "expected": {"mlag_id": 5, "intf_state": "active_full"},
                    "identity": {"interface_name": "port-channel5"},
                },
            }
        },
        "exchange_point_2": {"mlag": {}},
        "leaf1_rack1": {
            "mlag": {
                "interface_115": {
                    "expected": {"mlag_id": 102, "intf_state": "active_full"},
                    "identity": {"interface_name": "port-channel102"},
                },
                "domain_7": {
                    "role": "leaf",
                    "expected": {"domain_state": "active"},
                    "identity": {"domain_id": "1"},
                },
                "interface_127": {
                    "expected": {"peer_link_state": "up"},
                    "identity": {"peer_link": "port-channel1000"},
                },
                "interface_124": {
                    "expected": {"mlag_id": 5, "intf_state": "active_full"},
                    "identity": {"interface_name": "port-channel5"},
                },
                "interface_125": {
                    "expected": {"mlag_id": 6, "intf_state": "active_full"},
                    "identity": {"interface_name": "port-channel6"},
                },
                "interface_122": {
                    "expected": {"mlag_id": 3, "intf_state": "active_full"},
                    "identity": {"interface_name": "port-channel3"},
                },
                "interface_123": {
                    "expected": {"mlag_id": 4, "intf_state": "active_full"},
                    "identity": {"interface_name": "port-channel4"},
                },
                "interface_120": {
                    "expected": {"mlag_id": 1, "intf_state": "active_full"},
                    "identity": {"interface_name": "port-channel1"},
                },
                "interface_121": {
                    "expected": {"mlag_id": 2, "intf_state": "active_full"},
                    "identity": {"interface_name": "port-channel2"},
                },
            }
        },
        "leaf1_rack2": {
            "mlag": {
                "interface_40": {
                    "expected": {"mlag_id": 2, "intf_state": "active_full"},
                    "identity": {"interface_name": "port-channel2"},
                },
                "interface_39": {
                    "expected": {"peer_link_state": "up"},
                    "identity": {"peer_link": "port-channel1000"},
                },
                "domain_8": {
                    "role": "leaf",
                    "expected": {"domain_state": "active"},
                    "identity": {"domain_id": "1"},
                },
                "interface_35": {
                    "expected": {"mlag_id": 4, "intf_state": "active_full"},
                    "identity": {"interface_name": "port-channel4"},
                },
                "interface_34": {
                    "expected": {"mlag_id": 3, "intf_state": "active_full"},
                    "identity": {"interface_name": "port-channel3"},
                },
                "interface_37": {
                    "expected": {"mlag_id": 6, "intf_state": "active_full"},
                    "identity": {"interface_name": "port-channel6"},
                },
                "interface_36": {
                    "expected": {"mlag_id": 5, "intf_state": "active_full"},
                    "identity": {"interface_name": "port-channel5"},
                },
                "interface_33": {
                    "expected": {"mlag_id": 101, "intf_state": "active_full"},
                    "identity": {"interface_name": "port-channel101"},
                },
                "interface_32": {
                    "expected": {"mlag_id": 1, "intf_state": "active_full"},
                    "identity": {"interface_name": "port-channel1"},
                },
            }
        },
        "border_leaf2_rack3": {
            "mlag": {
                "interface_81": {
                    "expected": {"peer_link_state": "up"},
                    "identity": {"peer_link": "port-channel1000"},
                },
                "domain_5": {
                    "role": "leaf",
                    "expected": {"domain_state": "active"},
                    "identity": {"domain_id": "1"},
                },
                "interface_75": {
                    "expected": {"mlag_id": 2, "intf_state": "active_full"},
                    "identity": {"interface_name": "port-channel2"},
                },
                "interface_67": {
                    "expected": {"mlag_id": 3, "intf_state": "active_full"},
                    "identity": {"interface_name": "port-channel3"},
                },
                "interface_77": {
                    "expected": {"mlag_id": 4, "intf_state": "active_full"},
                    "identity": {"interface_name": "port-channel4"},
                },
                "interface_76": {
                    "expected": {"mlag_id": 100, "intf_state": "active_full"},
                    "identity": {"interface_name": "port-channel100"},
                },
                "interface_79": {
                    "expected": {"mlag_id": 6, "intf_state": "active_full"},
                    "identity": {"interface_name": "port-channel6"},
                },
                "interface_78": {
                    "expected": {"mlag_id": 5, "intf_state": "active_full"},
                    "identity": {"interface_name": "port-channel5"},
                },
                "interface_74": {
                    "expected": {"mlag_id": 1, "intf_state": "active_full"},
                    "identity": {"interface_name": "port-channel1"},
                },
            }
        },
    }

    assert expectation_generator.store.expectations == expected
