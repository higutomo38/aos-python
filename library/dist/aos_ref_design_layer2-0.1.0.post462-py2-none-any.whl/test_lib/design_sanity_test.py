#!/usr/bin/env python
# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

from aos.sdk.builder import Builder
from aos.sdk.reference_design.expectation_rendering_plugin import \
    ExpectationRenderingPlugin
from aos.sdk.reference_design.blueprint_registry_plugin import \
    BlueprintRegistryPlugin
from aos.sdk.reference_design.configuration_rendering_plugin import \
    ConfigurationRenderingPlugin
from aos.sdk.reference_design.diff_input_plugin import DiffInputPlugin


def get_facade_blueprint_initializers(design):
    for attr_name in dir(design.Facade):
        method = getattr(design.Facade, attr_name)
        if callable(method) and getattr(
                method, 'blueprint_init_type', None) is not None:
            yield method


class ReferenceDesignSanityTest(object):
    design = None

    def test_has_builder(self):
        assert issubclass(getattr(self.design, 'BuildRuleEngine', None), Builder)

    def test_has_expectation_renderer(self):
        assert isinstance(getattr(self.design, 'ExpectationRenderers', None), list)

    def test_expectation_rendering_plugins_are_valid(self):
        bad_types = [
            plugin.__name__
            for plugin in getattr(self.design, 'ExpectationRenderers', [])
            if not issubclass(plugin, ExpectationRenderingPlugin)
        ]
        assert [] == bad_types, (
            'Plugins not derived from ExpectationRenderingPlugin:\n' +
            '\n'.join(bad_types)
        )

    def test_has_blueprint_registry_plugin(self):
        assert issubclass(
            getattr(self.design, 'BlueprintRegistryPlugin', None),
            BlueprintRegistryPlugin)

    def test_has_configuration_renderer(self):
        assert issubclass(
            getattr(self.design, 'ConfigurationRenderer', None),
            ConfigurationRenderingPlugin)

    def test_has_telemetry_processors(self):
        assert isinstance(getattr(self.design, 'TelemetryProcessors', None), dict)

    def test_blueprint_initializers_have_different_init_types(self):
        initializers = list(get_facade_blueprint_initializers(self.design))
        assert len(initializers) == len(set(initializers))

    def test_at_most_one_default_blueprint_initializer(self):
        defaults = [
            i for i in get_facade_blueprint_initializers(self.design)
            if i.is_default_blueprint_initializer
        ]
        assert len(defaults) <= 1, locals()

    def test_diff_input_plugin_validity(self):
        element_types = []
        for plugin in getattr(self.design, "DiffInputPlugins", []):
            element_types.append(plugin.element_type)
            assert issubclass(plugin, DiffInputPlugin), locals()

        assert len(element_types) == len(set(element_types)), locals()

    def test_has_alert_types(self):
        assert isinstance(getattr(self.design, 'alert_types', None), list)

    def test_has_roles(self):
        assert isinstance(getattr(self.design, 'roles', None), list)
