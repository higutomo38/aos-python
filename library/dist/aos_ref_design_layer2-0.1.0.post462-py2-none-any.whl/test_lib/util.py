#!/usr/bin/env python
# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

import json
from aos.sdk.graph import Graph


def graph_from_dict(graph_dict, schema):
    def sanitize(l):
        if isinstance(l, list):
            return l
        return l.itervalues()

    graph = Graph(id=graph_dict["id"], schema=schema)
    for node in sanitize(graph_dict["nodes"]):
        graph.add_node(node.pop("type"), id=node.pop("id"), **node)

    for rel in sanitize(graph_dict["relationships"]):
        graph.add_relationship(
            type=rel.pop("type"),
            source=rel.pop("source_id"),
            target=rel.pop("target_id"),
            id=rel.pop("id"),
            **rel
        )

    if graph_dict.get("version"):
        graph.commit(graph_dict["version"])

    return graph


def read_json(path):
    with open(path) as f:
        return json.load(f)
