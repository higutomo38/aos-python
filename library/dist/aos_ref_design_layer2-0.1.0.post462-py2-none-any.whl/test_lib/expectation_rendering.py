#!/usr/bin/env python
# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula


from aos.sdk.graph.query import QueryEngine


class MockedExpectationStore(object):
    """Stores expectations in-memory and pushes them to sysdb when commit is called
    Each expectation has a node_id, service_name and a collection of element states
    Each element has an id and data"""

    def __init__(self):
        # Map from node-id > service-name > element-id > element-data
        self.expectations = {}
        # Map from service-name > node-id > system-id
        self._service_map = {}

    def set_devices_for_service(self, service_name, node_id_to_system_id):
        self._service_map[service_name] = node_id_to_system_id
        # Remove stale entries not referenced in specificed devices
        for node_id, services in self.expectations.iteritems():
            if node_id not in node_id_to_system_id:
                services.pop(service_name, None)
        # Ensure service expectations are rendered for specified devices
        for node_id in node_id_to_system_id:
            (self.expectations.setdefault(node_id, {}).setdefault(service_name, {}))

    def add(self, node_id, service_name, element_id, element_data):
        (self.expectations.setdefault(node_id, {}).setdefault(service_name, {}))[
            element_id
        ] = element_data

    def remove(self, node_id, service_name, element_id):
        (self.expectations.get(node_id, {}).get(service_name, {})).pop(
            element_id, None
        )

    def clear(self, node_id, service_name):
        if self.expectations.get(node_id, {}).get(service_name):
            self.expectations.get(node_id).get(service_name).clear()

    def get(self, node_id, service_name, element_id):
        service = self.expectations.get(node_id, {}).get(service_name, {})
        if element_id in service:
            return service[element_id]
        return {}

    def get_system_ids(self):
        system_ids = set()
        for node_id_to_system_id in self._service_map.itervalues():
            system_ids.update(node_id_to_system_id.itervalues())
        return system_ids

    def get_node_ids(self, service_name):
        return self._service_map.get(service_name, {}).iterkeys()

    def commit(self):
        pass


class MockedBlueprintExpectationGenerator(object):
    """
    This is Tac-stripped version of BlueprintExpectationGenerator class
    """

    def __init__(self, graph, rule_classes):
        self.graph = graph
        self._engine = QueryEngine()
        self.store = MockedExpectationStore()
        self._rule_engines = []
        for rule_class in rule_classes:
            rule_class_instance = rule_class(self.store)
            for k in dir(rule_class_instance):
                v = getattr(rule_class_instance, k)
                if hasattr(v, "queries"):
                    for query in v.queries:
                        self._engine.register_query(query, v)
            self._rule_engines.append(rule_class_instance)

        self._initial = True

    def on_graph(self, graph):
        if self._initial:
            self._initial = False
            self._engine.execute_all(graph)

        self._engine.on_graph(graph)
        for rule_engine in self._rule_engines:
            rule_engine.on_commit(graph)
            service_map = rule_engine.get_service_system_id_map(graph)
            for service_name, node_id_to_system_id in service_map.iteritems():
                self.store.set_devices_for_service(
                    service_name, node_id_to_system_id
                )
