# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

"""Offbox deploment helper for Nxos switches"""
# pylint: disable=broad-except
# pylint: disable=no-name-in-module

import logging
import os
import tempfile
import re

import paramiko
from scp import SCPClient

from aos.sdk.system_agent.base_offbox_deployment_helper import \
    BaseOffBoxDeploymentHelper
from aos.sdk.driver.nxos.driver import NxosRequest
from aos.sdk.utils import wait_for
from requests.exceptions import RequestException

LOGGER = logging.getLogger(__name__)
CONFIG_SNIPPET_DELIMITER = '!'


class SpecialCharHandler(object):
    special_characters = [
        '\a',   # BELL
    ]

    AOS_MAGIC_STR = "#AOS_MAGIC_SPL_"

    @staticmethod
    def convert_to_aos_format(strinput):
        for v in SpecialCharHandler.special_characters:
            strinput = strinput.replace(
                v, SpecialCharHandler.AOS_MAGIC_STR + '%04d' % ord(v))
        return strinput

    @staticmethod
    def convert_from_aos_format(strinput):
        for v in SpecialCharHandler.special_characters:
            strinput = strinput.replace(
                SpecialCharHandler.AOS_MAGIC_STR + '%04d' % ord(v), v)
        return strinput


# Extending existing nxos driver to support bash commands
class NxosBashRequest(NxosRequest):
    def __init__(self):
        super(NxosBashRequest, self).__init__()
        self.msg_type = 'bash'
        self.resp_fmt = 'json'
        self.command = None


class NxosOffboxDeploymentHelper(BaseOffBoxDeploymentHelper):
    """Offbox deploment helper for Nxos switches"""

    def __init__(self, sdk_device):
        super(NxosOffboxDeploymentHelper, self).__init__(sdk_device)

        self.local_temp_file = tempfile.mkstemp()[1]  # [1] - absolute pathname
        self.checkpoint_dir_path = '/bootflash/.aos'
        self.checkpoint_dir_cli_path = 'bootflash:.aos'
        self.pristine_file = 'pristine_checkpoint_file'
        self.pristine_file_path = \
            os.path.join(self.checkpoint_dir_path, self.pristine_file)
        self.pristine_file_path_under_bootflash = \
            os.path.join('.aos', self.pristine_file)
        self.pristine_file_cli_path = \
            os.path.join('bootflash:.aos', self.pristine_file)

    def _exec_bash(self, command):
        rqst = NxosBashRequest()
        rqst.command = command
        response = rqst.send(self.sdk_device.driver)
        as_json = response.json()
        outputs = as_json['ins_api']['outputs']['output']
        if outputs.get('basherror') is not None:
            raise RuntimeError(outputs)
        return str(outputs.get('body')) or str(outputs)

    def setup_device_connection(self):
        """Setup connectivity to the device
        """
        self.sdk_device.open()
        return True

    def _connection_established(self):
        try:
            self.setup_device_connection()
            LOGGER.info("Connection is established, current time: %s",
                        self.get_system_uptime())
            return True
        except Exception as e:
            LOGGER.debug('Establishing connection: %s', str(e))
            return False

    def get_running_config(self):
        """Get the running config of the device and returns it as a string.
        """
        running_config = str(self.sdk_device.get_text('show run'))
        # The response is the format
        # <Empty line>
        # !Command: show running-config
        # <optional line> !No configuration change since last restart
        # <optinal line> !Running configuration last done at ...
        # !Time: <time>
        # Iterate the lines and save the config from the line after !Time.
        config_lines = running_config.splitlines(True)
        for i, line in enumerate(config_lines):
            if line.startswith('!Time:'):
                running_config = ''.join(config_lines[i+1:])
                break

        return running_config

    def get_system_uptime(self):
        """Returns the system uptime in seconds (float)
               """
        output = self._exec_bash('cat /proc/uptime')
        return float(output.split()[0])

    def _create_aos_dir(self):
        # /bootflash/.aos might not be in place, create it first
        exists = 'No such file' not in self.sdk_device.get_text(
            'dir {}'.format(self.checkpoint_dir_cli_path))
        if not exists:
            self._exec_bash('mkdir {}'.format(self.checkpoint_dir_path))

    def _upload_file(self, local_file, remote_file, get=False):
        def get_remote_file_size(remote_file):
            result = self.sdk_device.get_text('dir {}'.format(remote_file))
            # Output is in format:
            #
            # leaf-1-1# dir bootflash:text.txt
            #          20    May 10 12:23:05 2019  text.txt
            #
            # Usage for bootflash://sup-local
            #  2319192064 bytes used
            #  1218027520 bytes free
            #  3537219584 bytes total

            if 'No such file' in result:
                return 0
            return result.split()[0].strip()

        def file_transferred():
            transferred_file_size = os.path.getsize(local_file) if get else \
                get_remote_file_size(remote_file)
            return int(transferred_file_size) == int(file_size)

        if get:
            file_size = get_remote_file_size(remote_file)
        else:
            file_size = os.path.getsize(local_file)

        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(
            hostname=self.sdk_device.ip_address,
            username=self.sdk_device.username,
            password=self.sdk_device.password,
            port=22)

        scp = SCPClient(ssh.get_transport())
        try:
            if get:
                scp.get(remote_file, local_file)
            else:
                scp.put(local_file, remote_file)
        except Exception as e:
            LOGGER.error('Exception in scp: %s', str(e))
            try:
                wait_for(file_transferred, timeout=30)
            except AssertionError:
                pass
        transferred = file_transferred()
        scp.close()
        ssh.close()
        if not transferred:
            LOGGER.error('File %s was not transferred', remote_file)
            assert False, 'Could not upload the file'
        return True

    def apply_complete_config(self, config_blob, pristine_config):
        """Cisco-specific overwrite complete config.
           Rollback to pristine config and then apply the config_blob
        """
        # The file is deleted everytime before writing to it. NXOS 9.2(2) comes with
        # new kernel which prevents having process with uid > 10000. The file is
        # created by nxos host filesystem. This will deny the agent to modify the
        # file.

        try:
            self._create_aos_dir()

            exists = 'No such file' not in self.sdk_device.get_text(
                'dir {}'.format(self.pristine_file_cli_path))
            if exists:
                self._exec_bash('rm {}'.format(self.pristine_file_path))

            with open(self.local_temp_file, 'w') as fl:
                fl.write(SpecialCharHandler.convert_from_aos_format(
                    pristine_config) + '\n')
            self._upload_file(self.local_temp_file,
                              self.pristine_file_path_under_bootflash)
            LOGGER.info('Pristine config is uploaded to %s', self.pristine_file_path)
            self.sdk_device.driver.exec_config('rollback running-config file {}'
                                               .format(self.pristine_file_cli_path))
            LOGGER.info("'rollback running-config' is finished")
            return self._apply_config_snippets(self._create_config_snippets(
                config_blob))
        except RequestException:
            LOGGER.error('Apply complete config failed')
            raise
        except Exception as e:
            return False, str(e)

    def _create_config_snippets(self, config_blob):
        """Divide the config blob into snippets using the delimiter
        """
        return [snippet for snippet in config_blob.split(
            CONFIG_SNIPPET_DELIMITER) if snippet not in ['', '\n']]

    def _apply_config_snippets(self, config_snippets):
        """Apply the next config snippet
        """
        # `nxapi use-vrf management` command will be ignored by now because it
        # results in disconnection and agent restart (can't establish connection in
        # a quite short time)

        def get_cmd_list_from_config_blob(config_blob):
            """ Return a list of cmds from given config_blob
            """
            return [cmd.lstrip() for cmd in config_blob.split('\n')
                    if cmd.lstrip() not in ['', '!', '#']]

        for snippet in config_snippets:
            snippet = re.sub('nxapi use-vrf management', '', snippet)
            cmd_list = get_cmd_list_from_config_blob(snippet)
            cmds = ' ;'.join(cmd_list)
            LOGGER.info('Executing cmd list: %s', cmds)
            try:
                self.sdk_device.driver.exec_config(cmds)
            except RequestException as req:
                LOGGER.error('Exception while executing cmds: %s,'
                             ' exception: \n%s', cmds, str(req))
                try:
                    wait_for(self._connection_established, timeout=300)
                except AssertionError as e:
                    return False, '{}\n{}'.format(str(req), str(e))
            except Exception as e:
                return False, str(e)
        return True, ''

    def get_pristine_config(self):
        """Cisco specific get pristine config
           Checkpoint the file, and read from the file.

           Disable acks for this command, because if the file exists
           it will lock up NXAPI [AOS-10682], we will overwrite it always.
        """
        self._create_aos_dir()
        self.sdk_device.driver.exec_config('terminal dont-ask')
        self.sdk_device.driver.exec_config('checkpoint file {}'
                                           .format(self.pristine_file_cli_path))
        self._upload_file(self.local_temp_file,
                          self.pristine_file_path_under_bootflash, get=True)
        with open(self.local_temp_file) as fl:
            pristine_config = fl.read()
        # pristine_config = self._exec_bash('cat {}'.format(self.pristine_file_path))
        return SpecialCharHandler.convert_to_aos_format(pristine_config)

    def apply_incremental_config(self, config_blob):
        """Cisco-specific apply incremental config"""
        LOGGER.debug('Applying incremental config: %s', config_blob)
        return self._apply_config_snippets(self._create_config_snippets(config_blob))

    def save_running_config_to_startup(self):
        """Save running config to startup config"""
        try:
            self.sdk_device.driver.exec_config('copy running-config startup-config')
        except RequestException:
            LOGGER.error('Write to startup failed')
            raise
        except Exception as e:
            return False, str(e)
        return True, ''
