# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

import json
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.compat.aos.sdk.system_agent.device import \
    get_running_aos_version
from aosstdcollectors.utils.data_util import format_generic_value


class VlanCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(VlanCollector, self).__init__(*args, **kwargs)
        self.aos_version = get_running_aos_version()

    def process(self, collected):
        return {
            "items": [
                {
                    'identity': vlan_id,
                    'value': format_generic_value(self.aos_version, {
                        'vlan_id': int(vlan_id),
                        # TODO There is actually no 'name' in cumulus
                        'name': vlan_id,
                        'interfaces': [iface['interface'] for iface in vlan_data]
                    })
                } for vlan_id, vlan_data in collected.iteritems()
            ]
        }

    def collect(self):
        collected = self.device.get_json('netshow vlan json')['vlans']
        self.post_data(json.dumps(self.process(collected)))


def collector_plugin(_device):
    """
    Collects information about all VLANs on a box
    """

    return VlanCollector
