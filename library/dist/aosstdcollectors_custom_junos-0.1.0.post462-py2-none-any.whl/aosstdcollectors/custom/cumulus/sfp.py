# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula


# flake8: noqa E501


import json
from aosstdcollectors.utils.textparsing import TextFsmParser
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from collections import defaultdict
import logging
import re


LOG = logging.getLogger(__name__)
QSFP_NUM_CHANNELS_PER_PORT = 4
PER_CHANNEL_HEADER_REGEX = re.compile(r'channel(\d)_(.+)$')


# This template extract SFP/QSFP stats from ethtool command for one interface:
# e.g. > sudo ethtool -m swp1
TEMPLATE = r''' #TextFSM
Value transceiver_type (\S+)
Value wave_length (\d+.\d+)
Value vendor_sn (\S+)
Value vendor_pn (\S+)
Value vendor_name ([\w ]+)
Value media_type (.+)
Value temperature (-?\d+.\d+)
Value voltage (-?\d+.\d+)
Value tx_bias_high_alarm (-?\d+.\d+)
Value tx_bias_low_alarm (-?\d+.\d+)
Value tx_bias_high_warn (-?\d+.\d+)
Value tx_bias_low_warn (-?\d+.\d+)
Value tx_power_high_alarm (-?\d+.\d+)
Value tx_power_low_alarm (-?\d+.\d+)
Value tx_power_high_warn (-?\d+.\d+)
Value tx_power_low_warn (-?\d+.\d+)
Value rx_power_high_alarm (-?\d+.\d+)
Value rx_power_low_alarm (-?\d+.\d+)
Value rx_power_high_warn (-?\d+.\d+)
Value rx_power_low_warn (-?\d+.\d+)
Value temperature_high_alarm (-?\d+.\d+)
Value temperature_low_alarm (-?\d+.\d+)
Value temperature_high_warn (-?\d+.\d+)
Value temperature_low_warn (-?\d+.\d+)
Value voltage_high_alarm (-?\d+.\d+)
Value voltage_low_alarm (-?\d+.\d+)
Value voltage_high_warn (-?\d+.\d+)
Value voltage_low_warn (-?\d+.\d+)
Value tx_bias (-?\d+.\d+)
Value tx_power (-?\d+.\d+)
Value rx_power (-?\d+.\d+)
Value channel1_tx_bias (-?\d+.\d+)
Value channel2_tx_bias (-?\d+.\d+)
Value channel3_tx_bias (-?\d+.\d+)
Value channel4_tx_bias (-?\d+.\d+)
Value channel1_tx_power (-?\d+.\d+)
Value channel2_tx_power (-?\d+.\d+)
Value channel3_tx_power (-?\d+.\d+)
Value channel4_tx_power (-?\d+.\d+)
Value channel1_rx_power (-?\d+.\d+)
Value channel2_rx_power (-?\d+.\d+)
Value channel3_rx_power (-?\d+.\d+)
Value channel4_rx_power (-?\d+.\d+)


Start
  ^\s*Identifier\s+:\s+\S+\s+\((${transceiver_type})\)
  ^\s*Laser wavelength\s+: *${wave_length}\s*nm
  ^\s*Vendor SN\s+: ${vendor_sn}
  ^\s*Vendor PN\s+: ${vendor_pn}
  ^\s*Vendor name\s+: ${vendor_name}
  ^\s*Transceiver type\s+: .*(Ethernet|Extended): ${media_type}
  ^\s*Module temperature\s+:.*degrees C / ${temperature} degrees F
  ^\s*Module voltage\s+: ${voltage} V
  ^\s*Laser bias current high alarm threshold\s+: ${tx_bias_high_alarm} mA
  ^\s*Laser bias current low alarm threshold\s+: ${tx_bias_low_alarm} mA
  ^\s*Laser bias current high warning threshold\s+: ${tx_bias_high_warn} mA
  ^\s*Laser bias current low warning threshold\s+: ${tx_bias_low_warn} mA
  ^\s*Laser output power high alarm threshold\s+:.*mW / ${tx_power_high_alarm} dBm
  ^\s*Laser output power low alarm threshold\s+:.*mW / ${tx_power_low_alarm} dBm
  ^\s*Laser output power high warning threshold\s+:.*mW / ${tx_power_high_warn} dBm
  ^\s*Laser output power low warning threshold\s+:.*mW / ${tx_power_low_warn} dBm
  ^\s*Laser rx power high alarm threshold\s+:.*mW / ${rx_power_high_alarm} dBm
  ^\s*Laser rx power low alarm threshold\s+:.*mW / ${rx_power_low_alarm} dBm
  ^\s*Laser rx power high warning threshold\s+:.*mW / ${rx_power_high_warn} dBm
  ^\s*Laser rx power low warning threshold\s+:.*mW / ${rx_power_low_warn} dBm
  ^\s*Module temperature high alarm th.*:.*degrees C / ${temperature_high_alarm} degrees F
  ^\s*Module temperature low alarm th.*:.*degrees C / ${temperature_low_alarm} degrees F
  ^\s*Module temperature high warning th.*:.*degrees C / ${temperature_high_warn} degrees F
  ^\s*Module temperature low warning th.*:.*degrees C / ${temperature_low_warn} degrees F
  ^\s*Module voltage high alarm threshold\s+: ${voltage_high_alarm} V
  ^\s*Module voltage low alarm threshold\s+: ${voltage_low_alarm} V
  ^\s*Module voltage high warning threshold\s+: ${voltage_high_warn} V
  ^\s*Module voltage low warning threshold\s+: ${voltage_low_warn} V
  ^\s*Laser bias current\s+: ${tx_bias} mA
  ^\s*Laser output power\s+:.*mW / ${tx_power} dBm
  ^\s*Receiver signal average optical power\s+:.*mW / ${rx_power} dBm
  ^\s*Laser tx bias current \(Channel 1\)\s+: ${channel1_tx_bias} mA
  ^\s*Laser tx bias current \(Channel 2\)\s+: ${channel2_tx_bias} mA
  ^\s*Laser tx bias current \(Channel 3\)\s+: ${channel3_tx_bias} mA
  ^\s*Laser tx bias current \(Channel 4\)\s+: ${channel4_tx_bias} mA
  ^\s*Transmit avg optical power \(Channel 1\)\s+:.*mW / ${channel1_tx_power} dBm
  ^\s*Transmit avg optical power \(Channel 2\)\s+:.*mW / ${channel2_tx_power} dBm
  ^\s*Transmit avg optical power \(Channel 3\)\s+:.*mW / ${channel3_tx_power} dBm
  ^\s*Transmit avg optical power \(Channel 4\)\s+:.*mW / ${channel4_tx_power} dBm
  ^\s*(Receiver signal OMA|Rcvr signal avg optical power)\(Channel 1\)\s+:.*mW / ${channel1_rx_power} dBm
  ^\s*(Receiver signal OMA|Rcvr signal avg optical power)\(Channel 2\)\s+:.*mW / ${channel2_rx_power} dBm
  ^\s*(Receiver signal OMA|Rcvr signal avg optical power)\(Channel 3\)\s+:.*mW / ${channel3_rx_power} dBm
  ^\s*(Receiver signal OMA|Rcvr signal avg optical power)\(Channel 4\)\s+:.*mW / ${channel4_rx_power} dBm
'''


CHANNEL_AWARE_METRICS = [
    "tx_bias",
    "tx_power",
    "rx_power"
]

# Used to generate has_warn|has_alarm fields
THRESHOLD_SUPPORTED_METRICS = [
    'tx_bias',
    'tx_power',
    'rx_power',
    'voltage',
    'temperature'
]


class SfpCollector(BaseTelemetryCollector):
    """SFP Collector

    Collect:
        Identity: each element is in the format of '<interface>|<metric>'
            where interface is interface name
            and metric is one of tx_power, rx_power, temperature, tx_bias, voltage.

            And for each (interface, metric) pair, there are 6 accompanying metrics
            whose identities are of the form '<interface>|<metric>_<sub-metric>'
            where 'sub-metric' is one of low_warn, high_warn, low_alarm, high_alarm,
            has_warn, has_alarm.
        Value:
            - rx_power/tx_power/tx_bias: string '-8.3425' or
              '-0.25|-11.25|-0.23|-0.24' if QSFP
            - temperature: '31' Fahrenheit etc.
            - wave_length: '850.0' nm etc.
            - media_type: '10GBASE-CR' etc.
            - voltage: '3.3' volt
            - *_low_warn/*_high_warn/*_low_alarm/*_high_alrm: string
            - *_has_warn/*_has_alarm: '2' if any data outside thresholds,
                                      otherwise '1'

        NOTE: For QSFP, the identity includes the channel information
            like '<interface>|channel<channel_id>|<metric>'.
            *_has_warn/*_has_alarm will be '2' if any of the channel
            data is outside the threshold.
    """

    def __init__(self, *args, **kwargs):
        super(SfpCollector, self).__init__(*args, **kwargs)
        self.log_ethtool_output_if_metric_missing = defaultdict(lambda: True)
        self.parser = TextFsmParser(TEMPLATE)
        self.header_to_index = {
            header:idx for idx, header in enumerate(self.parser.headers)}

    def get_column(self, row, column_name):
        return row[self.header_to_index[column_name]]

    def _enable_interface_ethtool_output_logging(self, intf_name):
        self.log_ethtool_output_if_metric_missing[intf_name] = True

    def _disable_interface_ethtool_output_logging(self, intf_name):
        self.log_ethtool_output_if_metric_missing[intf_name] = False

    def _interface_ethtool_output_logging_enabled(self, intf_name):
        return self.log_ethtool_output_if_metric_missing.get(intf_name, True)

    def log_interface_ethtool_output(
            self, intf_name, ethtool_output, intf_parsed_output):
        '''
        This function logs the ethtool command output once for specified interface
        when collected value of any metric of the interface is missing. And it
        resets the log_ethtool_output_if_metric_missing flag when it detects that
        values for all metrics get populated.
        '''
        metrics_missing_value = [
            k for k, v in intf_parsed_output.iteritems()
            if not v
        ]
        # We are conditionalizing the logging to avoid bloating the log file.
        # The idea is to log only once in case of missing metrics
        if (self._interface_ethtool_output_logging_enabled(intf_name) and
                metrics_missing_value):
            LOG.warning(
                '%s values are missing for interface %s. Ethtool command '
                'output: \n%s\n', metrics_missing_value, intf_name, ethtool_output)
            self._disable_interface_ethtool_output_logging(intf_name)
            return

        if (not self._interface_ethtool_output_logging_enabled(intf_name) and
                not metrics_missing_value):
            self._enable_interface_ethtool_output_logging(intf_name)

    def parse_ethtool_output(self, intf_name, text_output):
        if intf_name is None or text_output is None:
            return {}

        parsed_data = self.parser.parse(text_output)
        if not parsed_data:
            return {}

        assert len(parsed_data) == 1, (
            'Only one row is expected given the template is invoked once per port')
        row = parsed_data[0]
        is_qsfp = 'qsfp' in self.get_column(row, 'transceiver_type').lower()

        eff_output = {}
        # step1: copy all parsed values into output
        for column_idx, column_val in enumerate(row):
            header = self.parser.headers[column_idx]
            m = PER_CHANNEL_HEADER_REGEX.match(header)
            # per channel metrics need a tweak based on what's expected in output
            # because '|' is not allowed in header name of FSM template
            if m:
                key = '{}|channel{}|{}'.format(intf_name, m.group(1), m.group(2))
                if not column_val and not is_qsfp:
                    continue
            else:
                key = '{}|{}'.format(intf_name, header)
            eff_output[key] = column_val if column_val else None

        # step2: check threshold and store result in output
        def threshold(val, low, high):
            if not (val and low and high):
                return '0'
            return '1' if float(high) > float(val) > float(low) else '2'

        for tsm in THRESHOLD_SUPPORTED_METRICS:
            low_warn = self.get_column(row, '{}_low_warn'.format(tsm))
            high_warn = self.get_column(row, '{}_high_warn'.format(tsm))
            low_alarm = self.get_column(row, '{}_low_alarm'.format(tsm))
            high_alarm = self.get_column(row, '{}_high_alarm'.format(tsm))

            metric_value = self.get_column(row, tsm)
            eff_output['{}|{}_has_warn'.format(intf_name, tsm)] = threshold(
                metric_value, low_warn, high_warn)
            eff_output['{}|{}_has_alarm'.format(intf_name, tsm)] = threshold(
                metric_value, low_alarm, high_alarm)

            if not (tsm in CHANNEL_AWARE_METRICS and is_qsfp):
                continue

            # threshold ranges are specified at port level, but metric values are
            # available per channel. So process these metrics using port-level ranges
            for i in xrange(1, QSFP_NUM_CHANNELS_PER_PORT+1):
                metric_value = self.get_column(row, 'channel{}_{}'.format(i, tsm))
                key_prefix = '{}|channel{}|{}_has_'.format(intf_name, i, tsm)
                eff_output[key_prefix + 'warn'] = threshold(
                    metric_value, low_warn, high_warn)
                eff_output[key_prefix + 'alarm'] = threshold(
                    metric_value, low_alarm, high_alarm)

        # step3: compose per-channel values and report on parent keys
        # Values for channel aware metrics are absent for qsfp ports but these are
        # ingested into IBA, so we don't want to leave them empty
        def compose_per_channel_values():
            def agg_threshold(element_results):
                if any(er == '2' for er in element_results):
                    return '2'
                if all(er == '0' for er in element_results):
                    return '0'
                return '1'

            for cam in CHANNEL_AWARE_METRICS:
                parent_val = self.get_column(row, cam)
                if parent_val:
                    # Based on our examination, this should not happen, because
                    # Cumulus does NOT report value for these metrics. But if it did
                    # (due to a change in behavior or bug fix etc), we respect it
                    # In this case, even thresholds would have been filled in step2
                    continue

                eff_output['{}|{}'.format(intf_name, cam)] = '|'.join(
                    self.get_column(row, 'channel{}_{}'.format(i, cam)) or 'NA'
                    for i in xrange(1, QSFP_NUM_CHANNELS_PER_PORT+1)
                )

                eff_output['{}|{}_has_warn'.format(intf_name, cam)] = agg_threshold([
                    eff_output['{}|channel{}|{}_has_warn'.format(intf_name, i, cam)]
                    for i in xrange(1, QSFP_NUM_CHANNELS_PER_PORT+1)
                ])
                eff_output['{}|{}_has_alarm'.format(intf_name, cam)] = agg_threshold(
                    [
                        eff_output['{}|channel{}|{}_has_alarm'.format(
                            intf_name, i, cam)]
                        for i in xrange(1, QSFP_NUM_CHANNELS_PER_PORT+1)
                    ])

        if is_qsfp:
            compose_per_channel_values()

        # step4: replace per-channel metric values with integer for IBA analytics
        # channels are not present in intent and they don't map 1-1 to port breakouts
        # Per-channel metric values are anyways reported (in aggregate) under parent
        # metric. Hence we replace per-channel keys with integers to enable analytics
        # in IBA and to workaround lack of float support in IBA
        def convert_per_channel_values_to_int():
            def intify(val):
                return str(int(1000 * float(val))) if val else None

            for cam in CHANNEL_AWARE_METRICS:
                for i in xrange(1, QSFP_NUM_CHANNELS_PER_PORT+1):
                    key = '{}|channel{}|{}'.format(intf_name, i, cam)
                    if key in eff_output:
                        eff_output[key + '_int'] = intify(eff_output.pop(key))

        if is_qsfp:
            convert_per_channel_values_to_int()

        return eff_output

    def collect(self):
        def get_ethtool_output(intf):
            try:
                return self.device.get_text(
                    'sudo ethtool -m {}'.format(intf.strip()))
            except RuntimeError:
                # For some interfaces, will get the runtime error while calling
                # get_text(), skip it
                #
                # $ sudo ethtool -m swp8
                # Cannot get module EEPROM information: No such device
                return None

        def process_interface(interface):
            ethtool_output = get_ethtool_output(interface)
            parsed_output = self.parse_ethtool_output(interface, ethtool_output)
            self.log_interface_ethtool_output(
                interface, ethtool_output, parsed_output)
            return parsed_output

        interfaces = self.device.get_json('sudo net show interface pluggables json')

        self.post_data(json.dumps({
            'items': [
                {
                    'identity': key,
                    'value': value
                }
                for intf in interfaces
                if interfaces[intf].get('vendorPartNumber')
                for key, value in process_interface(intf).iteritems()
            ]
        }))


def collector_plugin(_device):
    return SfpCollector
