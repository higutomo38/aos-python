# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula


from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.data_util import to_extensible_postdata
from aosstdcollectors.compat.aos.sdk.system_agent.device import \
    get_running_aos_version
from aosstdcollectors.utils.eos_vrf_util import read_vrfs


class VrfCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(VrfCollector, self).__init__(*args, **kwargs)
        self.aos_version = get_running_aos_version()

    def collect(self):
        self.post_data(
            to_extensible_postdata(
                read_vrfs(self.device, no_cache=True), aos_version=self.aos_version)
        )


def collector_plugin(_device):
    return VrfCollector
