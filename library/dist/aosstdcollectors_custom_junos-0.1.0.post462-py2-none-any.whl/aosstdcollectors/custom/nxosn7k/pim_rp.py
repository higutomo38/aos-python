# Copyright 2019-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula


import json
import logging
from collections import defaultdict
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.nxosn7k_util import get_tree, get_value
from aosstdcollectors.utils.nxosn7k_vrf_util import read_vrfs

LOG = logging.getLogger(__name__)


class PimRPCollector(BaseTelemetryCollector):
    def get_pim_rps_in_vrf(self, vrf):
        pim_tree, pim_nsmap = get_tree(
            self.device.get_text('show ip pim rp vrf ' + vrf + ' | xml'))

        rp_to_groups = defaultdict(list)
        for rp in pim_tree.xpath('//aos:show//aos:rp//aos:ROW_rp',
                                 namespaces=pim_nsmap):
            crp = get_value(rp, pim_nsmap, 'rp-addr')

            for grange in rp.xpath('//aos:ROW_grange', namespaces=pim_nsmap):
                group = '%s/%s' % (get_value(grange, pim_nsmap, 'grange-grp'),
                                   get_value(grange, pim_nsmap, 'grange-masklen'))
                rp_to_groups[crp].append(group)

        return rp_to_groups

    def collect(self):
        # For each VRF+RP, return list of groups in sorted order separated by comma
        vrfs = read_vrfs(self.device)
        self.post_data(json.dumps({
            'items': [
                {
                    'identity': '%s|%s|%s' % (vrf, rp, '|'.join(sorted(groups))),
                    'value': '1'
                }
                for vrf, vrf_info in vrfs.iteritems()
                if vrf_info['role'] != 'management' and
                vrf_info['multicast_mode'] == 'enabled'
                for rp, groups in self.get_pim_rps_in_vrf(vrf).iteritems()
            ]
        }))


def collector_plugin(_device):
    return PimRPCollector
