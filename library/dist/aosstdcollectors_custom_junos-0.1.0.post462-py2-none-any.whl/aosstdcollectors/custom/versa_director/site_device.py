# Copyright 2020-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.custom.versa_director.site_inventory import SiteInventoryCache


class SiteDeviceCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(SiteDeviceCollector, self).__init__(*args, **kwargs)
        self.cache = SiteInventoryCache(self.device.client, self.device.org_name)

    def collect(self):
        self.post_data([
            {
                'key': {
                    'device_id': device_id,
                    'property': property_name,
                },
                'value': device_info[property_name],
            }
            for device_id, device_info in self.cache.get_data(
                self.service_config.executionInterval).list_devices().iteritems()
            for property_name in ['label', 'site_id', 'device_group_id']
        ])


def collector_plugin(device):
    return SiteDeviceCollector
