# Copyright 2020-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.custom.versa_director.site_inventory import SiteInventoryCache


class SiteDeviceGroupCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(SiteDeviceGroupCollector, self).__init__(*args, **kwargs)
        self.cache = SiteInventoryCache(self.device.client, self.device.org_name)

    def collect(self):
        self.post_data([
            {
                'key': {
                    'device_group_id': device_group_id,
                    'property': property_name
                },
                # VD doesn't have a dedicated id for device groups, use label for
                # device_group_id
                'value': (device_group_id if property_name == 'label'
                          else template_name)
            }
            for device_group_id, template_name in (
                self.cache.get_data(self.service_config.executionInterval)
                .list_device_groups().iteritems()
            )
            for property_name in ['label', 'template_label']
        ])


def collector_plugin(device):
    return SiteDeviceGroupCollector
