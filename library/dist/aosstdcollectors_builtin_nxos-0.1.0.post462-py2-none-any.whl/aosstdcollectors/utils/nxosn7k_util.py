# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

import re
from lxml import etree

MGMT_INTF_REGEX = re.compile('mgmt')
ETH_REGEX = re.compile(r'Eth(\d+\/.*$)')


def get_tree(data):
    tree = etree.fromstring(data.decode('ISO-8859-1').encode('utf-8'))
    nsmap = tree.nsmap.copy()
    nsmap['aos'] = nsmap.pop(None)
    return tree, nsmap


def get_value(tree, nsmap, tag):
    element = tree.find('./aos:%s' % tag, nsmap)
    if element is not None:
        return element.text
    return None


def normalize_intf_name(nbor, nsmap, intf):
    intf_name = get_value(nbor, nsmap, intf)
    intf_match = ETH_REGEX.match(intf_name)
    if intf_match:
        return 'Ethernet%s' % intf_match.group(1)

    return intf_name
