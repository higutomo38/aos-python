# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula


import re
import logging
from pyeapi.eapilib import CommandError

LOG = logging.getLogger(__name__)
MGMT_INTF_PATTERN = re.compile("Management.*")
ETH_REGEX = re.compile(r'Eth(\d[0-9/]*\.?\d+)')


# TODO(Rajeev): Move this code to eos device driver once it is absorbed to Leblon.
def try_get_json(device, cmd):
    try:
        return device.get_json(cmd)
    except CommandError as e:
        if e.error_code == 1000:  # general error
            LOG.warning(
                "Command '%s' failed with error: %s, output: %s", cmd, e, e.output)
            return {}

        raise


def make_item_lldp_nei(if_name, lldp_nei):
    """
    this function creates the collector item for when an interface
    has an LLDP neighbor
    """

    ifinfo = lldp_nei['neighborInterfaceInfo']

    def get_iface_name(info):
        iface_id = info.get('interfaceId').replace('"', '')
        if info['interfaceIdType'] == 'macAddress':
            iface_name = info.get('interfaceDescription') or iface_id
        else:
            iface_name = iface_id

        return str(iface_name)

    return {
        'interface_name': if_name,
        'neighbor_system_id': str(lldp_nei.get('systemName', '')),
        'sys_description': str(lldp_nei.get('systemDescription', '')),
        'neighbor_interface_name':
            normalize_intf_name(get_iface_name(ifinfo),
                                lldp_nei.get('systemDescription', ''))
    }


def normalize_intf_name(intf_name, sys_description):
    # Cisco returns shortened interface names via lldp
    # e.g., Eth1/2 instead of Ethernet1/2
    intf_match = ETH_REGEX.match(intf_name)
    if intf_match and sys_description.startswith('Cisco'):
        return 'Ethernet%s' % intf_match.group(1)

    return intf_name
