# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula
import base64
import re
from enum import EnumMeta
from lxml import etree


def parse(data, path):
    parsed_data = data.find(path)
    if parsed_data is not None:
        return parsed_data.text
    return None


def parse_list(root, path):
    return [
        element.text
        for element in root.findall(path)
        if element is not None
    ]


def is_management_interface(iface_type):
    return iface_type == 'base-if:management'


def is_valid_interface(iface_type):
    # filter out interface of type null
    if 'null' in iface_type:
        return False
    return True


def extract_vlan_id_from_name(vlan_name):
    if vlan_name:
        ids = re.findall(r'\d+', vlan_name)
        if ids and len(ids) == 1:
            return int(ids[0])
    return None


def parse_multiple_xmls(data):
    # Some commands output return multiple xml trees
    # This method split them into a list of xml trees
    data_entries = re.split(r'\<\?xml version=\"1.0\".*\?\>', data)
    return [
        xml_data
        for xml_data in data_entries
        if xml_data not in ['', '\n']
    ]


class BgpVrfValue(EnumMeta):
    # pylint: disable=invalid-name
    up = 'up'
    down = 'down'
    unknown = 'unknown'
    missing = 'missing'


def decode_mac_address(encoded_mac):
    return ':'.join(
        '{:02x}'.format(ord(c))
        for c in base64.b64decode(encoded_mac))


def get_vlt_running_config(device):
    cmd_output = device.get_text('show running-configuration vlt | display-xml')
    if not cmd_output:
        return None
    return etree.fromstring(cmd_output.encode('utf8'))


def get_vlt(device, vlt_id, detailed=False):
    show_vlt_args = [vlt_id, 'vlt-port-detail'] if detailed else [vlt_id]
    show_vlt_cmd = 'show vlt {args} | display-xml'.format(
        args=' '.join(show_vlt_args))
    show_vlt = device.get_text(show_vlt_cmd).encode('utf8')
    return etree.fromstring(show_vlt)
