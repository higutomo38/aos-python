# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula
import json

from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.junos_util import is_management_interface


class LldpCollector(BaseTelemetryCollector):
    @property
    def lldp_neighbors_spec(self):
        return self.device.load_table_view_spec(
            {
                "LldpNeighborTable": {
                    "rpc": "get-lldp-neighbors-information",
                    "item": "lldp-neighbor-information",
                    "key": "lldp-local-port-id",
                    "view": "LldpNeighborView",
                },
                "LldpNeighborView": {
                    "fields": {
                        "interface_name": "lldp-local-port-id",
                        "neighbor_interface_name": "lldp-remote-port-id",
                        "neighbor_system_id": "lldp-remote-system-name",
                        "neighbor_chassis_id": "lldp-remote-chassis-id",
                        "neighbor_chassis_id_type": "lldp-remote-chassis-id-subtype",
                    }
                },
            }
        )

    def _lldp_info(self, lldp):
        def sys_description(_lldp):
            """The actual LLDP system description on Junos is only available by
            executing additional get-lldp-interface-neighbors RPC call per interface.
            Since LLDP collector is run every 10 seconds by default, switches
            often have several dozens of connected interfaces, and system description
            not being used in network discovery code in AOS CLI, it was decided
            to use combination of chassis ID type and chassis ID as system
            description to save resources."""
            return ": ".join(
                [_lldp.neighbor_chassis_id_type, _lldp.neighbor_chassis_id]
            )

        return {
            "chassis_id":
                lldp.neighbor_chassis_id
                if lldp.neighbor_chassis_id_type == 'Mac address'
                else '',
            "interface_name": lldp.interface_name,
            "neighbor_interface_name": lldp.neighbor_interface_name,
            "neighbor_system_id": (
                lldp.neighbor_system_id or lldp.neighbor_chassis_id
            ),
            "sys_description": sys_description(lldp),
        }

    def collect(self):
        lldp_neighbors = self.device.create_table(
            self.lldp_neighbors_spec["LldpNeighborTable"]
        )

        items = [
            self._lldp_info(lldp)
            for lldp in lldp_neighbors.get()
            if not is_management_interface(lldp.interface_name)
        ]

        self.post_data(json.dumps(dict(items=items)))


def collector_plugin(_):
    return LldpCollector
