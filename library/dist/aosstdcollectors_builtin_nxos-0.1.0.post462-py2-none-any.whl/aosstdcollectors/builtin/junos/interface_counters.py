# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula
import json
import datetime
import math
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.junos_util import VALID_INTF_REGEX


DEFAULT_DELTA_SECONDS = 5


class InterfaceCounterRateCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(InterfaceCounterRateCollector, self).__init__(*args, **kwargs)
        self._spec = None
        self.prev_counters = None
        self.prev_timestamp = None

    @property
    def spec(self):
        if self._spec:
            return self._spec

        self._spec = self.device.load_table_view_spec({
            'InterfaceCountersTable': {
                'rpc': 'get-interface-information',
                'item': 'physical-interface',
                'args': {
                    'extensive': True,
                },
                'view': 'InterfaceCountersView',
            },
            'InterfaceCountersView': {
                'fields': {
                    'rx_unicast_pkts': 'ethernet-mac-statistics/input-unicasts',
                    'rx_broadcast_pkts': 'ethernet-mac-statistics/input-broadcasts',
                    'rx_multicast_pkts': 'ethernet-mac-statistics/input-multicasts',
                    'rx_error_pkts': 'input-error-list/input-errors',
                    'rx_discard_pkts': 'input-error-list/input-drops',
                    'rx_bytes': 'ethernet-mac-statistics/input-bytes',
                    'tx_unicast_pkts': 'ethernet-mac-statistics/output-unicasts',
                    'tx_broadcast_pkts': 'ethernet-mac-statistics/output-broadcasts',
                    'tx_multicast_pkts': 'ethernet-mac-statistics/output-multicasts',
                    'tx_error_pkts': 'output-error-list/output-errors',
                    'tx_discard_pkts': 'output-error-list/output-drops',
                    'tx_bytes': 'ethernet-mac-statistics/output-bytes',
                    'alignment_errors': 'ethernet-mac-statistics/input-crc-errors',
                    'fcs_errors': 'input-error-list/framing-errors',
                    'symbol_errors': 'ethernet-mac-statistics/input-code-violations',
                    'runts': 'input-error-list/input-runts',
                    'giants': 'ethernet-mac-statistics/input-oversized-frames',
                }
            },
        })

        return self._spec

    def collect(self):
        counters = self.device.create_table(
            self.spec['InterfaceCountersTable']).get()
        timestamp = datetime.datetime.now()

        if not self.prev_timestamp:
            self.prev_counters = counters
            self.prev_timestamp = timestamp
            return

        delta_seconds = (timestamp - self.prev_timestamp).total_seconds()

        def data(intf_name):

            def rate(counter_name):
                old_val = int(self.prev_counters[intf_name][counter_name])
                new_val = int(counters[intf_name][counter_name])
                if new_val <= old_val:
                    # this can happen when counters are reset
                    return 0
                return int(math.ceil(
                    ((new_val - old_val) / delta_seconds) * DEFAULT_DELTA_SECONDS))

            return {
                'interface_name': intf_name,
                'rx_unicast_packets': rate('rx_unicast_pkts'),
                'rx_broadcast_packets': rate('rx_broadcast_pkts'),
                'rx_multicast_packets': rate('rx_multicast_pkts'),
                'rx_error_packets': rate('rx_error_pkts'),
                'rx_discard_packets': rate('rx_discard_pkts'),
                'rx_bytes': rate('rx_bytes'),
                'tx_unicast_packets': rate('tx_unicast_pkts'),
                'tx_broadcast_packets': rate('tx_broadcast_pkts'),
                'tx_multicast_packets': rate('tx_multicast_pkts'),
                'tx_error_packets': rate('tx_error_pkts'),
                'tx_discard_packets': rate('tx_discard_pkts'),
                'tx_bytes': rate('tx_bytes'),
                'alignment_errors': rate('alignment_errors'),
                'fcs_errors': rate('fcs_errors'),
                'symbol_errors': rate('symbol_errors'),
                'runts': rate('runts'),
                'giants': rate('giants'),
            }

        self.post_data(
            json.dumps({
                'items': [
                    data(intf_counters.name)
                    for intf_counters in counters
                    if VALID_INTF_REGEX.match(intf_counters.name)
                ],
                'delta_seconds': int(delta_seconds)
            })
        )

        self.prev_counters = counters
        self.prev_timestamp = timestamp


def collector_plugin(_device):
    return InterfaceCounterRateCollector
