# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula
import json

from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.junos_util import intf_name, VALID_LAG_MEMBER_INTF_REGEX


class LagCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(LagCollector, self).__init__(*args, **kwargs)
        self._spec = None

    @property
    def spec(self):
        if self._spec:
            return self._spec

        self._spec = self.device.load_table_view_spec({
            "InterfaceTable": {
                "rpc": "get-interface-information",
                "item": "physical-interface",
                "args": {
                    "terse": True,
                },
                "view": "InterfaceView",
            },
            "InterfaceView": {
                "fields": {
                    "status": "oper-status",
                    "bundle_name":
                        "logical-interface/address-family/ae-bundle-name",
                },
            },
        })

        return self._spec

    def collect(self):
        def get_lag_member_info(lag, intfs):

            return [
                {
                    "interface_name": intf.name,
                    "value": "up" if intf.status == "up" else "down",
                }
                for intf in intfs
                if VALID_LAG_MEMBER_INTF_REGEX.match(intf.name) and
                intf.bundle_name and intf_name(intf.bundle_name) == lag
            ]

        items = [
            {
                "lag_name": intf.name,
                "value": "up" if intf.status == "up" else "down",
                "interfaces": get_lag_member_info(
                    intf.name,
                    self.device.create_table(self.spec["InterfaceTable"]).get()),
            }
            for intf in
            self.device.create_table(self.spec["InterfaceTable"]).get()
            if intf.name.startswith("ae")
        ]

        self.post_data(json.dumps(dict(items=items)))


def collector_plugin(_):
    return LagCollector
