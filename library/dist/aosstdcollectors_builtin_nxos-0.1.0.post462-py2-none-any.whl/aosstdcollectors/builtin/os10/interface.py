# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula
import json

from lxml import etree

from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.os10_util import parse


class InterfaceCollector(BaseTelemetryCollector):
    def _interfaces(self):
        # `show interface status | display-xml` only returns physical interfaces
        # `show port-channel summary | display-xml` returns all interfaces, but
        # that might be a bug, because `show port-channel summary` only shows
        # port channel interfaces.
        xml_data = self.device.get_text("show port-channel summary | display-xml")
        show_port_channels = etree.fromstring(xml_data.encode("utf8"))

        def name(_xml):
            return parse(_xml, "./name")

        def status(_xml):
            return "up" if parse(_xml, "./oper-status") == "up" else "down"

        def all_interfaces(_xml):
            # pick first entry of `interfaces-state`, second has port channel
            # details, and we're only interested in interface status
            return _xml.xpath("//data/interfaces-state[1]/interface")

        for interface in all_interfaces(show_port_channels):
            yield name(interface), status(interface)

    def collect(self):
        self.post_data(
            json.dumps(
                {
                    "items": [
                        {
                            "interface_name": name,
                            "value": status,
                        }
                        for name, status in self._interfaces()
                    ]
                }
            )
        )


def collector_plugin(_):
    return InterfaceCollector
