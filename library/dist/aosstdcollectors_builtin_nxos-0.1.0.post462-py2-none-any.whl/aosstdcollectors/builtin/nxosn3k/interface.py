# Copyright 2019-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

import json
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector


class InterfaceCollector(BaseTelemetryCollector):
    # TODO: this function is not required if n3k is printing Port-Channel
    # in lower case. I copied this code from eos platform and retaining
    # it for now as I don't have dump for port channel interface for n3k.
    def _make_if_name(self, ifname):
        # existing code expects the port-channel to be lowercase, following
        # suit in this collector
        return ifname.lower() if ifname.startswith("Port-Channel") else ifname

    def _process(self, data):
        return json.dumps({
            'items': [
                {
                    "interface_name": self._make_if_name(intf['interface']),
                    "value": 'up' if intf['state'] == 'connected' else 'down',
                }
                for intf in data['TABLE_interface']['ROW_interface']
            ]
        })

    def collect(self):
        data = self.device.get_json('show interface status')
        parsed_data = self._process(data)
        self.post_data(parsed_data)


def collector_plugin(_device):
    return InterfaceCollector
