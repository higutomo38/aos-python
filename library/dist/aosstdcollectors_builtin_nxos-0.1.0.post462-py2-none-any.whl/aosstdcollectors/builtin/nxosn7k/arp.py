# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

import json
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.nxosn7k_util import get_tree, get_value


class ArpCollector(BaseTelemetryCollector):

    def _make_mac_address(self, value):
        """
        covert the value that looks like this: '5254.009d.d990'
        into a macaddr that looks like this:  '52:54:00:9d:d9:90'
        """
        if value:
            mac = value.replace('.', '')
            return ':'.join(mac[c:c + 2] for c in xrange(0, 12, 2))
        return None

    def _process(self, data):
        tree, nsmap = get_tree(data)
        vrfs = tree.xpath('//aos:ROW_vrf', namespaces=nsmap)
        return json.dumps({
            'items': [
                {
                    "vrf_name": get_value(v, nsmap, 'vrf-name-out'),
                    "ip_address": get_value(n, nsmap, 'ip-addr-out'),
                    "mac_address":
                        self._make_mac_address(get_value(n, nsmap, 'mac')),
                    "interface_name": get_value(n, nsmap, 'intf-out'),
                    "type":
                        'dynamicArp'
                        if get_value(n, nsmap, 'time-stamp') is not None
                        else 'staticArp',
                    "l2_info": ''
                }
                for v in vrfs
                for n in v.xpath('.//aos:ROW_adj', namespaces=nsmap)
            ]
        })

    def collect(self):
        data = self.device.get_text('show ip arp | xml')
        parsed_data = self._process(data)
        self.post_data(parsed_data)


def collector_plugin(_device):
    return ArpCollector
