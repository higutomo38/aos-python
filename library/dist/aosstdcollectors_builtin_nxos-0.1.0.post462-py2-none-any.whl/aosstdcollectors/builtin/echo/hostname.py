# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula
import json
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector


class HostnameCollector(BaseTelemetryCollector):
    def collect(self):
        input_tac_json = json.loads(self.service_config.input) \
            if self.service_config.input else {}

        self.post_data(json.dumps({
            'items': [
                {
                    'domain': input_tac_json['domain'],
                    'hostname': input_tac_json['hostname'],
                }
            ]
        }))


def collector_plugin(_device):
    return HostnameCollector
