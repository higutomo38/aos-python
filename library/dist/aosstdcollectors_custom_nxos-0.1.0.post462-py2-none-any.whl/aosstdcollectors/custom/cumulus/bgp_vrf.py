# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.compat.aos.sdk.system_agent.device import \
    get_running_aos_version
from aosstdcollectors.utils.data_util import format_generic_value
from aosstdcollectors.utils.platform_independent import valid_ipv4_addr
import json


def get_asn(info):
    for cast in info.itervalues():
        for intf in cast.itervalues():
            for cast2 in intf.itervalues():
                asn = cast2.get('as')
                if asn:
                    return asn
    return None


class BgpVrfCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(BgpVrfCollector, self).__init__(*args, **kwargs)
        self.aos_version = get_running_aos_version()

    def process(self, info):
        my_asn = get_asn(info)
        return {
            'items': [
                {
                    'identity': '%s_%s' % (vrf_info['vrfName'], peer_id),
                    'value': format_generic_value(self.aos_version, {
                        'vrf': vrf_info['vrfName'],
                        'dest_ip': peer_id if valid_ipv4_addr(peer_id) else None,
                        'dest_asn': str(peer_data.get('remoteAs')),
                        'value': 'up' if peer_data.get(
                            'state') == 'Established' else 'down',
                        'source_asn': str(vrf_info['as']),
                        'interface': (
                            peer_id if peer_data['idType'] == 'interface' else None),
                    })
                }
                for unicast in info.itervalues()
                for vrf in unicast.itervalues()
                for vrf_info in vrf.itervalues()
                if 'peers' in vrf_info
                for peer_id, peer_data in vrf_info['peers'].iteritems()
            ],
            'global': json.dumps({
                'asn': int(my_asn) if my_asn else None
            })
        }

    def collect(self):
        collected = self.device.get_json('sudo net show bgp vrf all summary json')
        self.post_data(json.dumps(self.process(collected)))


def collector_plugin(_device):
    return BgpVrfCollector
