# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula
from aosstdcollectors.custom.linux.resource_usage import ResourceUsageCollector


class SonicResourceUsageCollector(ResourceUsageCollector):
    pass


def collector_plugin(_device):
    return SonicResourceUsageCollector
