# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula


import json
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.data_util import to_extensible_postdata
from aosstdcollectors.utils.os10_util import parse, get_vlt_running_config, get_vlt


class MlagDomainCollector(BaseTelemetryCollector):
    def collect(self):
        def parse_vlt(vlt_id):
            if not vlt_id:
                return {
                    'domain_id': None,
                    'system_id': None,
                    'domain_state': None,
                    'local_interface': None,
                    'local_interface_status': None,
                    'local_interface_vlan_id': None,
                    'peer_link': None,
                    'peer_link_status': None,
                    'peer_address': None,
                    'config_sanity': None,
                }
            vlt_info = get_vlt(self.device, vlt_id)
            return {
                'domain_id': json.dumps(vlt_id),
                'system_id': parse(
                    vlt_info,
                    './data/topology-oper-data/vlt-domain/local-info/vlt-mac'),
                'domain_state': 1,
                # TODO show vlt output doesn't contain local_interface and vlan
                # information, check if we can extract them from other commands
                'local_interface': None,
                'local_interface_status': 1,
                'local_interface_vlan_id': None,
                'peer_link': parse(
                    vlt_info,
                    './data/topology-oper-data/vlt-domain/peer-link-info/if-name'),
                'peer_link_status': 1 if parse(
                    vlt_info,
                    './data/topology-oper-data/vlt-domain/peer-link-info/link'
                    '-status') == 'up' else 2,
                'peer_address': parse(
                    vlt_info,
                    './data/topology-oper-data/vlt-domain/peer-info/ip-address'),
                'config_sanity': 1
            }

        vlt_id = None
        vlt = get_vlt_running_config(self.device)
        if vlt is not None:
            vlt_id = parse(vlt, './data/node-topology/topology-id')

        self.post_data(to_extensible_postdata(parse_vlt(vlt_id)))


def collector_plugin(_device):
    return MlagDomainCollector
