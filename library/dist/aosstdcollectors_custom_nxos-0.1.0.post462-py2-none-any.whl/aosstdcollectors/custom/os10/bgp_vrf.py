# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula
import json
from lxml import etree
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.compat.aos.sdk.system_agent.device import \
    get_running_aos_version
from aosstdcollectors.utils.data_util import format_generic_value
from aosstdcollectors.utils.platform_independent import DEFAULT_VRF_NAME
from aosstdcollectors.utils.os10_util import parse, parse_multiple_xmls, BgpVrfValue


def get_asn(data_entries):
    for bgp_entry in data_entries:
        vrf = parse(bgp_entry, './data/bgp-oper/vrf/vrf-name')
        print vrf
        if vrf and vrf == 'default':
            return int(parse(bgp_entry, './data/bgp-oper/vrf/summary-info/local-as'))
    return None


class BgpVrfCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(BgpVrfCollector, self).__init__(*args, **kwargs)
        self.aos_version = get_running_aos_version()

    def parse_bgp(self):
        def parse_data(bgp_data):
            peer_entries = bgp_data.xpath('//bulk/data/peer-oper')
            if not peer_entries or len(peer_entries) < 1:
                return []
            return [
                {
                    'identity': '%s_%s' % (
                        vrf_name(peer_entry),
                        parse(peer_entry, './remote-address')),
                    'value': format_generic_value(self.aos_version, {
                        'vrf': vrf_name(peer_entry),
                        'dest_ip': parse(peer_entry, './remote-address'),
                        'dest_asn': parse(peer_entry, './remote-as'),
                        'value': BgpVrfValue.up if parse(
                            peer_entry,
                            './bgp-state') == 'established' else BgpVrfValue.down,
                        'source_asn': parse(peer_entry, './local-as'),
                    })
                }
                for peer_entry in peer_entries
            ]

        def vrf_name(_peer_entry):
            return (parse(_peer_entry, './data/bgp-oper/vrf/vrf-name') or
                    DEFAULT_VRF_NAME)

        data_xmls = parse_multiple_xmls(
            self.device.get_text('show ip bgp summary | display-xml'))
        data_entries = [etree.fromstring(data_xml.encode('utf8')) for data_xml in
                        data_xmls if 'BGP not active' not in data_xml]

        return {
            'items': [
                bgp_entry
                for data_entry in data_entries
                for bgp_entry in parse_data(data_entry)

            ],
            'global': json.dumps({
                'asn': get_asn(data_entries)
            })
        }

    def collect(self):
        self.post_data(json.dumps(self.parse_bgp()))


def collector_plugin(_):
    return BgpVrfCollector
