# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula
import json
import logging

from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.compat.aos.sdk.system_agent.device import \
    get_running_aos_version
from aosstdcollectors.utils.data_util import to_extensible_postdata
from aosstdcollectors.utils.junos_util import bgp_neighbor_state, vrf_name
from aosstdcollectors.utils.platform_independent import DEFAULT_VRF_NAME

LOG = logging.getLogger(__name__)


class BgpVrfCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(BgpVrfCollector, self).__init__(*args, **kwargs)
        self._spec = None
        self.aos_version = get_running_aos_version()

    @property
    def spec(self):
        if self._spec:
            return self._spec

        self._spec = self.device.load_table_view_spec(
            {
                "BgpNeighborTable": {
                    "rpc": "get-bgp-neighbor-information",
                    "item": "bgp-peer",
                    "view": "BgpNeighborView",
                    "key": "peer-address",
                },
                "BgpNeighborView": {
                    "fields": {
                        "vrf_name": "peer-cfg-rti",
                        "peer_address": "peer-address",
                        "peer_asn": "peer-as",
                        "state": "peer-state",
                        "source_asn": "local-as",
                    }
                },
            }
        )

        return self._spec

    def collect(self):
        def identity(_bgp_neigh):
            return "%s_%s" % (vrf_name(_bgp_neigh.vrf_name), dest_ip(_bgp_neigh))

        def default_vrf_asn(_items):
            for v in _items.itervalues():
                if v["vrf"] == DEFAULT_VRF_NAME:
                    return v["source_asn"]
            return None

        def dest_ip(_bgp_neigh):
            # The address is followed by the neighbor port number, e.g.
            # 10.10.10.25+5678
            # see https://www.juniper.net/documentation/en_US/junos/topics/reference
            # /command-summary/show-bgp-neighbor.html
            ip, _, _port = _bgp_neigh.peer_address.partition("+")
            return ip

        items = {
            identity(bgp_neighbor): {
                "vrf": vrf_name(bgp_neighbor.vrf_name),
                "dest_ip": dest_ip(bgp_neighbor),
                "dest_asn": bgp_neighbor.peer_asn,
                "value": bgp_neighbor_state(bgp_neighbor.state),
                "source_asn": bgp_neighbor.source_asn,
            }
            for bgp_neighbor in self.device.create_table(
                self.spec["BgpNeighborTable"]
            ).get()
        }

        global_items = json.dumps({"asn": default_vrf_asn(items)})

        self.post_data(to_extensible_postdata(items, global_items,
                                              aos_version=self.aos_version))


def collector_plugin(_):
    return BgpVrfCollector
