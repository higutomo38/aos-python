# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula
import json
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector


def make_if_name(if_name):
    # existing code expects the port-channel to be lowercase, following
    # suit in this collector
    return str(if_name.lower() if if_name.startswith("Port-Channel") else if_name)


def parse_interface_status(collected):
    return json.dumps({
        'items': [
            {
                'identity': make_if_name(if_name),
                'value': str(1 if if_data['linkStatus'] == 'connected' else 2)
            }
            for if_name, if_data in collected['interfaceStatuses'].iteritems()
        ]
    })


class InterfaceIbaCollector(BaseTelemetryCollector):
    def collect(self):
        interface_status = self.device.get_json('show interfaces status')
        self.post_data(parse_interface_status(interface_status))


def collector_plugin(_device):
    return InterfaceIbaCollector
