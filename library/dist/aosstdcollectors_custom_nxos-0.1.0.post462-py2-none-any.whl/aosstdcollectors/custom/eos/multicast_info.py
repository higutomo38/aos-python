# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula


"""
Collector used for multicast discovery
"""

import json
import logging
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.compat.aos.sdk.system_agent.device import \
    get_running_aos_version
from aosstdcollectors.utils.data_util import format_generic_value
from aosstdcollectors.utils.eos_util import try_get_json
from aosstdcollectors.utils.eos_vrf_util import read_vrfs

LOG = logging.getLogger(__name__)


class MulticastInfoCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(MulticastInfoCollector, self).__init__(*args, **kwargs)
        self.aos_version = get_running_aos_version()

    def get_multicast_config(self, vrf):
        anycast_data = try_get_json(
            self.device, 'show ip pim vrf ' + vrf + ' anycast-rp')
        rp_data = try_get_json(self.device, 'show ip pim vrf ' + vrf + ' rp')

        def get_group_mode(group_info):
            return {
                'Sparse': 'pim-sparse'
            }.get(group_info['mode'])

        def get_rp_discovery_mode(rp_info):
            return {
                'staticRp': 'static'
            }.get(rp_info['rpType'])

        return {
            'sparse_mode': {
                'groups': {
                    group_cidr: {
                        'mode': get_group_mode(group_info),
                        'rps': {
                            rp_ip: {
                                'discovery_mode': get_rp_discovery_mode(rp_info),
                            }
                            for rp_ip, rp_info in group_info.get(
                                'crp', {}).iteritems()
                        },
                    }
                    for group_cidr, group_info in rp_data.get(
                        'sparseMode', {}).get('crpSet', {}).iteritems()
                },
                'anycast_rps': anycast_data.get('anycastRpAddrs', []),
                'anycast_peers': anycast_data.get('peerAddrs', []),
            }
        }

    def collect(self):
        vrfs = read_vrfs(self.device)
        self.post_data(json.dumps({
            'items': [
                {
                    'identity': vrf,
                    'value': format_generic_value(self.aos_version,
                                                  self.get_multicast_config(vrf))
                }
                for vrf, vrf_info in vrfs.iteritems()
                if vrf_info['role'] != 'management' and
                vrf_info['multicast_mode'] == 'enabled'
            ]
        }))


def collector_plugin(_device):
    return MulticastInfoCollector
