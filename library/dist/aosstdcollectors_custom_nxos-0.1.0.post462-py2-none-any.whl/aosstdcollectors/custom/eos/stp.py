# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

"""
Collector that collects STP forwarding state and state change history.
"""

import json

import datetime

from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector


def normalize_interface_name(intf_name):
    if 'Port-Channel' in intf_name:
        return intf_name.lower()
    return intf_name


def normalize_field_name(name):
    field_name_normalization = {
        "lastChange": "last_change",
        "numChanges": "num_changes",
        "state": "stp_state"
    }
    return field_name_normalization[name]


def delay_from_past_time_to_current_time(past_time):
    """
    Return the time in seconds between current time and a previous point in time.
    The previous point in time is expressed in EPOCH time.
    """
    return int((datetime.datetime.now() -
                datetime.datetime.fromtimestamp(past_time)).total_seconds())


def value_for_stp_state(stp_state_field):
    stp_state_text_to_integer = {
        "forwarding": 1,
        "blocking": 2,
        "listening": 3,
        "learning": 4
    }
    return stp_state_text_to_integer[stp_state_field]


def process(info):
    return {
        'items': [
            {
                'identity': str('%s|%s|%s' % (
                    normalize_interface_name(interface),
                    vlan,
                    normalize_field_name(item))),
                'value': str(
                    value_for_stp_state(interface_data[item]) if item == 'state'
                    else delay_from_past_time_to_current_time(interface_data[item])
                    if item == 'lastChange'
                    else interface_data[item])
            }
            for topology_data in info.get('topologies', {}).itervalues()
            for interface, interface_data in topology_data['interfaces'].iteritems()
            for item in interface_data
            for vlan in topology_data.get('vlans', [])
        ]
    }


class StpCollector(BaseTelemetryCollector):
    """
    Collect:
        Identity: for each {{ interface }}/{{ vlan }}:
            - {{ interface }}|{{ vlan }}|last_change
            - {{ interface }}|{{ vlan }}|num_changes
            - {{ interface }}|{{ vlan }}|stp_state
        Value:
            - stp_state =
                1 for forwarding,
                2 for blocking,
                3 for listening,
                4 for learning.
            - last_change = Time(sec) between current time and last state change.
                example: If last change happened a minute ago, value is 60.
            - num_changes = Counter, incrementing for each state change.
    """
    def collect(self):
        self.post_data(
            json.dumps(
                process(self.device.get_json(
                    'show spanning-tree topology vlan status detail'))
            )
        )


def collector_plugin(_device):
    return StpCollector
