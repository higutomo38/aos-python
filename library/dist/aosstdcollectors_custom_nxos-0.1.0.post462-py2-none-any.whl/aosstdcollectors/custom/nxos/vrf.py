# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

from itertools import groupby
from aosstdcollectors.compat.aos.sdk.system_agent.device import \
    get_running_aos_version
from aosstdcollectors.utils.data_util import to_extensible_postdata
from aosstdcollectors.utils.nxos_util import MANAGEMENT_VRF_NAME
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector


class VrfCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(VrfCollector, self).__init__(*args, **kwargs)
        self.aos_version = get_running_aos_version()

    def parse_vrf_detail(self, data):
        return {
            vrf.get('vrf_name'): {
                'rd': vrf.get('rd', ''),
                'role': 'management' if (
                    vrf.get('vrf_name') == MANAGEMENT_VRF_NAME) else 'data'
            }
            for vrf in data.get('TABLE_vrf', {}).get('ROW_vrf', [])
        }

    def parse_vrf_interface(self, data):
        def vrf_key(vrf):
            return vrf['vrf_name']

        return {
            vrf_name: {
                'interfaces': [interface['if_name'] for interface in interfaces
                               if interface['if_name'] != 'Null0']
            }
            for vrf_name, interfaces in groupby(sorted(
                data.get('TABLE_if', {}).get('ROW_if', []),
                key=vrf_key), vrf_key)
        }

    def parse_vrf_multicast(self, data):
        return {
            pim['out-context']: {'multicast_mode': 'enabled'}
            for pim in data.get('TABLE_context', {}).get('ROW_context', [])
            }

    def collect(self):
        vrf_detail = self.parse_vrf_detail(
            self.device.get_json('show vrf all detail'))
        vrf_interface = self.parse_vrf_interface(
            self.device.get_json('show vrf all interface'))
        try:
            vrf_multicast = self.parse_vrf_multicast(
                self.device.get_json('show ip pim vrf all'))
        except RuntimeError:
            vrf_multicast = {}

        self.post_data(to_extensible_postdata({
            vrf_name: dict(
                rd=vrf['rd'],
                interfaces=vrf_interface.get(vrf_name, {}).get('interfaces', []),
                role=vrf['role'],
                multicast_mode='enabled' if (
                    vrf_multicast.get(vrf_name)) else 'disabled')
            for vrf_name, vrf in vrf_detail.iteritems()},
                                              aos_version=self.aos_version))


def collector_plugin(_device):
    return VrfCollector
