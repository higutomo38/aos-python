# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

import json
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector


class RouteCountCollector(BaseTelemetryCollector):
    """
    Returns number of routes for all networks contextualized by VRFs.
    """
    def collect(self):
        info = self.device.get_json('show ip route vrf all')
        self.post_data(json.dumps({
            'items': [
                {
                    'identity':
                        str(vrf_data['vrf-name-out']) + "|" +
                        str(data['ipprefix']),
                    'value': str(data['ucast-nhops'])
                }
                for vrf_data in info["TABLE_vrf"]["ROW_vrf"]
                for key, addrf_data in vrf_data.get("TABLE_addrf", {}).iteritems()
                if key == "ROW_addrf"
                for data in addrf_data.get("TABLE_prefix", {}).get("ROW_prefix", [])
                if data['attached'] != 'true'
            ]
        }))


def collector_plugin(_device):
    return RouteCountCollector
