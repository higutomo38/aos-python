# Copyright 2019-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula


import json
import logging
from collections import defaultdict
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.nxosn3k_vrf_util import read_vrfs

LOG = logging.getLogger(__name__)


class PimRPCollector(BaseTelemetryCollector):
    def get_pim_rps_in_vrf(self, vrf):
        vrf_json = self.device.get_json('show ip pim rp vrf {}'.format(vrf))

        rp_to_groups = defaultdict(list)
        rp_rows = vrf_json.get('TABLE_vrf', {}).get('ROW_vrf', [])

        if rp_rows:
            rows = rp_rows[0].get(
                'TABLE_rp', {}).get('ROW_rp', [])

        for rp in rows:
            crp = rp['rp-addr']

            granges = rp['TABLE_grange']['ROW_grange']
            for grange in granges:
                group = '%s/%s' % (grange['grange-grp'],
                                   grange['grange-masklen'])
                rp_to_groups[crp].append(group)

        return rp_to_groups

    def collect(self):
        # For each VRF+RP, return list of groups in sorted order separated by comma
        vrfs = read_vrfs(self.device)
        self.post_data(json.dumps({
            'items': [
                {
                    'identity': '%s|%s|%s' % (vrf, rp, '|'.join(sorted(groups))),
                    'value': '1'
                }
                for vrf, vrf_info in vrfs.iteritems()
                if vrf_info['role'] != 'management' and
                vrf_info['multicast_mode'] == 'enabled'
                for rp, groups in self.get_pim_rps_in_vrf(vrf).iteritems()
            ]
        }))


def collector_plugin(_device):
    return PimRPCollector
