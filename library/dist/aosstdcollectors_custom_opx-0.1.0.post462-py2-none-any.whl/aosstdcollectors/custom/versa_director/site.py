# Copyright 2020-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.custom.versa_director.site_inventory import SiteInventoryCache


class SiteCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(SiteCollector, self).__init__(*args, **kwargs)
        self.cache = SiteInventoryCache(self.device.client, self.device.org_name)

    def collect(self):
        self.post_data([
            {
                'key': {
                    'site_id': site_id,
                    'property': property_name,
                },
                'value': site_info[property_name],
            }
            for site_id, site_info in self.cache.get_data(
                self.service_config.executionInterval).list_sites().iteritems()
            for property_name in ['label', 'site_group', 'device_ids']
        ])


def collector_plugin(device):
    return SiteCollector
