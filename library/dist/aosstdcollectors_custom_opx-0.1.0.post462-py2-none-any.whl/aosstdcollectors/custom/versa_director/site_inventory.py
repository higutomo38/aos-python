# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

import json
import logging

from collections import defaultdict
from aosstdcollectors.utils.cache_base import CacheBase


LOGGER = logging.getLogger(__name__)


class SiteInventoryData(object):
    def __init__(self):
        # site_id -> (site_label, [device_ids])
        # site_id is location_id for HA site
        self.site_device_map = defaultdict(
            lambda: {'site_labels': [], 'device_ids': [], 'site_group': None})
        # device_label -> site_id
        self.device_label_site_map = {}
        # device_label -> device_uuid
        self.device_label_uuid_map = {}
        # device_label -> device_group_label
        self.device_label_device_group_map = {}
        # device_group_label -> device_template
        self.device_group_device_template_map = {}
        # device_template -> work_flow_template
        self.device_template_workflow_template_map = {}

    def list_sites(self):
        return {
            site_id: {
                'label': ','.join(site_fields['site_labels']),
                'site_group': site_fields['site_group'],
                'device_ids': json.dumps(site_fields['device_ids'])
            }
            for site_id, site_fields in self.site_device_map.iteritems()
        }

    def list_devices(self):
        return {
            self.device_label_uuid_map[device_label]: {
                'label': device_label,
                'site_id': self.device_label_site_map[device_label],
                'device_group_id': self.device_label_device_group_map[device_label],
            }
            for device_label in self.device_label_uuid_map
        }

    def list_device_groups(self):
        return {
            group_id: self.device_template_workflow_template_map[label]
            for group_id, label in self.device_group_device_template_map.iteritems()
        }


class SiteInventory(object):
    def __init__(self, client, org_name):
        super(SiteInventory, self).__init__()

        self.client = client
        self.org_name = org_name

    def fetch(self):
        output = SiteInventoryData()

        for device_group in self.client.device_groups.list():
            output.device_group_device_template_map[device_group['name']] = (
                device_group['poststaging-template'])

            for device_label in device_group['inventory-name']:
                output.device_label_device_group_map[device_label] = (
                    device_group['name'])

            wf_template = self.client.workflow_templates.template[
                device_group['poststaging-template']].get()

            if not wf_template:
                LOGGER.debug(
                    'Workflow template for device template %s is not found',
                    device_group['poststaging-template']
                )
                continue

            if wf_template.get('redundantPair', {}).get('enable', False):
                if (wf_template['templateName'] ==
                        wf_template['redundantPair']['templateName']):
                    # VD workflow template API still provide response for redundant
                    # template with the same template name and redundant template
                    # name. Skip here.
                    continue

                output.device_template_workflow_template_map[
                    wf_template['redundantPair']['templateName']] = (
                        wf_template['templateName'])

            output.device_template_workflow_template_map[
                device_group['poststaging-template']] = wf_template['templateName']

        for device in self.client.appliances.list():
            device_name = device['name']
            if device_name in output.device_label_device_group_map:
                output.device_label_uuid_map[device_name] = device['uuid']
                site = self.client.devices[device_name].site.get()

                location_id = site.get('paired-site', {}).get('location-id')
                site_id = 'lc' + location_id if location_id else str(site['site-id'])

                output.device_label_site_map[device_name] = site_id
                output.site_device_map[site_id]['site_labels'].append(
                    site['chassis-id'])
                # For VD, site device workflow template name is the site_group name.
                # device_label -> device_group -> device_template ->
                # workflow_template(site_group_name)
                output.site_device_map[site_id]['site_group'] = (
                    output.device_template_workflow_template_map[
                        output.device_group_device_template_map[
                            output.device_label_device_group_map[device_name]]]
                )
                output.site_device_map[site_id]['device_ids'].append(
                    device['uuid'])

        return output


class SiteInventoryCache(CacheBase):  # pylint: disable=too-few-public-methods
    '''The reason for maintaining this cache is, VD does not have separate APIs to
    fetch site, device and device group data. But AOS has separate services for site,
    device and device group. AOS does not allow one collector to publish data for
    multiple services. We use this cache in order to reduce load on the VD while
    still maintaining the data freshness that is required'''

    def __init__(self, client, org_name):
        self.site_inventory = SiteInventory(client, org_name)
        super(SiteInventoryCache, self).__init__()

    def fetch_data(self):
        return self.site_inventory.fetch()
