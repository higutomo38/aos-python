# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula


"""
Collector used for multicast discovery
"""

import json
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector


class MulticastInfoCollector(BaseTelemetryCollector):
    def collect(self):
        # TODO(Rags): to be done
        self.post_data(json.dumps({
            'items': []
        }))


def collector_plugin(_device):
    return MulticastInfoCollector
