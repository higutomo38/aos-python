# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.data_util import to_extensible_postdata
import json


def mlag_domain_state_mapping(state):
    if state == 'true':
        return 'active'
    elif state == 'none':
        return 'unknown'
    return 'inactive'


def mlag_intf_state_mapping(state):
    if state == 'dual':
        return 'active_full'
    elif state == 'single':
        return 'active_partial'
    elif state == 'None':
        return 'unknown'
    return 'inactive'


def get_intf(collected, interfaces):
    for intf_name, intf_data in interfaces.iteritems():
        if not intf_name.startswith('bond') and intf_data['iface_obj']['mac'] == \
                collected['status']['ourId']:
            return


def process(collected):
    if collected:
        return {
            'domain_id': json.dumps(
                str(collected['clagIntfs'].values()[0]['clagId'])),
            # TODO: if there are more than 1 configured LAG servers
            # this filed would contain more items. Which one will be a domain_id?
            'system_id': collected['status']['sysMac'],
            'domain_state':
                1 if collected['clagIntfs'].values()[0]['operstate'] == 'up' else 2,
            'local_interface': collected['status']['peerIf'],
            'local_interface_status':
                1 if collected['clagIntfs'].values()[0]['operstate'] == 'up' else 2,
            'local_interface_vlan_id':
                int(collected['status']['peerIf'].partition('.')[2]),
            'peer_link': collected['status']['peerIf'].partition('.')[0],
            'peer_link_status': 1 if collected['status']['peerAlive'] else 2,
            'peer_address': collected['status']['peerIp'],
            'config_sanity': 1
        }
    return {
        'domain_id': '',
        'system_id': None,
        'domain_state': 2,
        'local_interface': None,
        'local_interface_status': 2,
        'local_interface_vlan_id': None,
        'peer_link': '',
        'peer_link_status': 2,
        'peer_address': None,
        'config_sanity': 2,
    }


class MlagDomainCollector(BaseTelemetryCollector):
    def collect(self):
        collected = self.device.get_text('sudo net show clag verbose json')
        if collected:
            collected = json.loads(collected)
        self.post_data(to_extensible_postdata(process(collected)))


def collector_plugin(_device):
    return MlagDomainCollector
