# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.compat.aos.sdk.system_agent.device import \
    get_running_aos_version
from aosstdcollectors.utils.data_util import format_generic_value
import json

# TODO: THIS IS MOCK FILE:
# since pim is not configured this collector produces no information
# but for 'blueprint create-from-network' command output is needed.
# As for devices with enabled multicast work is in progress, but currently
# output is mocked for every device to run the command above.


class MulticastInfoCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(MulticastInfoCollector, self).__init__(*args, **kwargs)
        self.aos_version = get_running_aos_version()

    def get_multicast_config(self, _vrf):
        return {
            'sparse_mode': {
                'groups': {},
                'anycast_rps': [],
                'anycast_peers': [],
            }
        }

    def collect(self):
        self.post_data(json.dumps({
            'items': [
                {
                    'identity': 'aux',
                    'value': format_generic_value(self.aos_version,
                                                  self.get_multicast_config('aux'))
                }
            ]
        }))


def collector_plugin(_device):
    return MulticastInfoCollector
