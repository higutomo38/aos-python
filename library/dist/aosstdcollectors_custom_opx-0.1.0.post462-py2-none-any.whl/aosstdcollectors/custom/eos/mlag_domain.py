# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula


from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.data_util import to_extensible_postdata
import json


class MlagDomainCollector(BaseTelemetryCollector):
    def collect(self):
        info = self.device.get_json('show mlag')
        self.post_data(to_extensible_postdata({
            # without json.dumps the value becomes integer thus violating schema
            'domain_id': json.dumps(str(info.get('domainId'))),
            'system_id': info.get('systemId'),
            'domain_state': 1 if info.get('state') == 'active' else 2,
            'local_interface': info.get('localInterface'),
            'local_interface_status':
                1 if info.get('localIntfStatus') == 'up' else 2,
            'local_interface_vlan_id':
                int(info['localInterface'].lstrip('Vlan'))
                if info.get('localInterface')
                else None,
            'peer_link': info.get('peerLink'),
            'peer_link_status': 1 if info.get('peerLinkStatus') == 'up' else 2,
            'peer_address': info.get('peerAddress'),
            'config_sanity': 1 if info.get('configSanity') == 'consistent' else 2,
        }))


def collector_plugin(_device):
    return MlagDomainCollector
