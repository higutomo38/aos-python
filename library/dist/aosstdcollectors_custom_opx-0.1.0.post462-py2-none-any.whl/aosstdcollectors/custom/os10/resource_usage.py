# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula
from aosstdcollectors.custom.linux.resource_usage import ResourceUsageCollector


class OS10ResourceUsageCollector(ResourceUsageCollector):
    def get_process_memory_usage(self):
        system_cmd = ("find /proc -maxdepth 2 -name status "
                      "-execdir grep -E 'Name|Vm' {} \\\\;")
        s = 'system "{}"'.format(system_cmd)
        return self.device.get_text(s)

    def get_meminfo(self):
        return self.device.get_text('system "cat /proc/meminfo"')


def collector_plugin(_device):
    return OS10ResourceUsageCollector
