# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula
import json
import logging
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.compat.aos.sdk.system_agent.device import \
    get_running_aos_version
from aosstdcollectors.utils.data_util import format_generic_value


DEFAULT_BANDWIDTH_MB = 10000
LOG = logging.getLogger(__name__)


def to_mbps(kbps):
    assert kbps, locals()
    return int(kbps) / 1000


def bandwidth(bw):
    # nxosn3k provides bw in kbps
    # 10G links appear as 10000000
    if bw == 0:
        return DEFAULT_BANDWIDTH_MB
    return to_mbps(bw)


def type_of(intf):
    """
    Possible interface types:

     - loopback
     - ethernet
     - subinterface
     - management
     - ip
    """

    intf_type = None

    if intf['interface'].startswith('mgmt'):
        intf_type = 'management'

    elif '.' in intf['interface']:
        intf_type = 'subinterface'

    elif intf['eth_hw_desc'] == 'Loopback':
        intf_type = 'loopback'

    elif 'eth_mode' not in intf:
        if intf.get('eth_ip_addr'):
            intf_type = 'ip'
        elif 'ethernet' in intf['eth_hw_desc'].lower():
            intf_type = 'ethernet'

    elif intf['eth_mode'] == 'access':
        intf_type = 'ethernet'

    if not intf_type:
        LOG.warn("Unable to determine interface type for %s",
                 intf['interface'])
    return intf_type


def intf_name(intf):
    # lower case to be consistent with the behavior of
    # lag and interface builtin collectors
    return intf.lower() \
        if intf.startswith('portChannel') else intf


def get_subinterface(intf):

    if '.' not in intf['interface']:
        return None, None
    return intf['interface'].split('.')


def get_mode(intf):
    if 'eth_ethertype' not in intf:
        return 'access'
    if intf['eth_ethertype'] == '0x8100':
        return 'trunk'
    return 'access'


def get_vlan_id(intf):
    vlan_id = intf.get('eth_encap_vlan', None)
    if vlan_id:
        return int(vlan_id)
    return None


def primary_ip(intf):
    ip_addr = intf.get('eth_ip_addr', None)
    if not ip_addr:
        return None

    return '{}/{}'.format(intf['eth_ip_addr'], intf['eth_ip_mask'])


def get_bw_value(intf):
    eth_bw = intf.get('eth_bw', None)
    if eth_bw:
        return eth_bw

    return 0


def update_parents(data):
    # for all subinterfaces, mark parent as type 'ip'
    parents = []
    for d in data:
        if isinstance(d['value'], str):
            val = json.loads(d['value'])
            if val['parent'] is not None:
                parents.append(val['parent'])
        else:
            if d['value']['parent'] is not None:
                parents.append(d['value']['parent'])
    for d in data:
        if d['identity'] in parents:
            if isinstance(d['value'], str):
                val = json.loads(d['value'])
                val['type'] = 'ip'
                d['value'] = json.dumps(val)
            else:
                d['value']['type'] = 'ip'
    return data


class InterfaceDetailsCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(InterfaceDetailsCollector, self).__init__(*args, **kwargs)
        self.aos_version = get_running_aos_version()

    def parse_interface_details(self, intfs):

        def build(intf):
            parent, subinterface_id = get_subinterface(intf)
            return {
                'name': intf_name(intf['interface']),
                'description': intf.get('desc', None),
                'speed_mbps': bandwidth(get_bw_value(intf)),
                'ipv4_addr': primary_ip(intf),
                'type': type_of(intf),
                'parent': parent,
                'subinterface_id': subinterface_id,
                'mode': get_mode(intf),
                'vlan_id': get_vlan_id(intf),
                'allowed_vlans': [],
                'mlag_id': None,
                'native_vlan': None,
                'virtual_ips': [],
                'virtual_macs': [],
            }

        data = [
            {
                'identity': intf['interface'],
                'value': format_generic_value(self.aos_version, build(intf))
            }
            for intf in intfs
        ]
        data = update_parents(data)

        return data

    def collect(self):
        intfs = self.device.get_json('show interface')
        details = self.parse_interface_details(
            intfs['TABLE_interface']['ROW_interface'])
        self.post_data(json.dumps({'items': details}))


def collector_plugin(_device):
    return InterfaceDetailsCollector
