# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula


import json
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.cisco_util import convert_mac_address


class MacCollector(BaseTelemetryCollector):
    def collect(self):
        def sanitize(l):
            return l if isinstance(l, list) else [l]

        macs = [
            {
                'mac_address': convert_mac_address(m['disp_mac_addr']),
                'vlan': int(m['disp_vlan']),
                'interface_name': m['disp_port'],
                'type': 'staticMac' if m[
                    'disp_is_static'] == 'enabled' else 'dynamicMac',
            }
            for m in sanitize(self.device.get_json('show mac address-table')[
                'TABLE_mac_address']['ROW_mac_address'])
            # TODO(Rags): Remove the following condition after AOS-12593 is fixed
            if int(m['disp_vlan']) > 0
        ]
        self.post_data(json.dumps(dict(items=macs)))


def collector_plugin(_device):
    return MacCollector
