# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula
import json
from lxml import etree
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector


class HostnameCollector(BaseTelemetryCollector):
    def collect(self):
        def parse_hostname(data):
            hostname = data.find('./data/system-state/system-status/hostname')
            if hostname is not None:
                return hostname.text
            return None

        show_version_data = self.device.get_text('show version | display-xml')
        xml_data = etree.fromstring(show_version_data.encode('utf8'))
        host = parse_hostname(xml_data)
        hostname, _, domain = host.partition(".")

        self.post_data(json.dumps(
            {
                'items': [
                    {
                        'hostname': hostname,
                        'domain': domain,
                    }
                ]
            }))


def collector_plugin(_device):
    return HostnameCollector
