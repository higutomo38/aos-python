# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula
import json
from lxml import etree
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.os10_util import parse, extract_vlan_id_from_name


def make_mac_entry(item):
    return {
        'mac_address': parse(item, './mac-addr'),
        'vlan': extract_vlan_id_from_name(parse(item, './vlan')),
        'interface_name': parse(item, './if-name'),
        'type': 'staticMac' if parse(item,
                                     './entry-type') == 'static' else 'dynamicMac'
    } if parse(item, './vlan') else None


def process(collected):
    return {
        "items": [
            item for item in [make_mac_entry(entry) for entry in
                              collected.findall('./bulk/data/fwd-table')] if item
        ]
    }


class MacCollector(BaseTelemetryCollector):
    def collect(self):
        collected = self.device.get_text('show mac address-table | display-xml')
        mac_address_table = etree.fromstring(collected.encode('utf8'))
        self.post_data(json.dumps(process(mac_address_table)))


def collector_plugin(_):
    return MacCollector
