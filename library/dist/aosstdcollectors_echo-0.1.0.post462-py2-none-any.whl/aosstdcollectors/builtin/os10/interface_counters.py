# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

import json
import datetime
import math
from lxml import etree
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.os10_util import parse, is_management_interface, \
    parse_multiple_xmls

DEFAULT_DELTA = 5


class InterfaceCounterRateCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(InterfaceCounterRateCollector, self).__init__(*args, **kwargs)
        self.prev_counters = None
        self.prev_timestamp = None

    def collect(self):
        timestamp = datetime.datetime.now()

        def extract_counter_values(intf_entry_root):
            counter_info = intf_entry_root.xpath(
                '//bulk/data/interface/statistics')[0]

            def counter_value(counter):
                path = './%s' % counter
                return int(parse(counter_info, path))

            return {
                'rx_unicast_packets': counter_value('in-unicast-pkts'),
                'rx_broadcast_packets': counter_value('in-broadcast-pkts'),
                'rx_multicast_packets': counter_value('in-multicast-pkts'),
                'rx_error_packets': counter_value('in-errors'),
                'rx_discard_packets': counter_value('in-discards'),
                'rx_bytes': counter_value('in-octets'),
                'tx_unicast_packets': counter_value('out-unicast-pkts'),
                'tx_broadcast_packets': counter_value('out-broadcast-pkts'),
                'tx_multicast_packets': counter_value('out-multicast-pkts'),
                'tx_error_packets': counter_value('out-errors'),
                'tx_discard_packets': counter_value('out-discards'),
                'tx_bytes': counter_value('out-octets'),
                'alignment_errors': counter_value('alignment-errors'),
                'fcs_errors': counter_value('fcs-errors'),
                'symbol_errors': counter_value('symbol-errors'),
                # Dell OS10 doesn't report runts in interface statistics
                'runts': 0,
                'giants': counter_value('frame-too-long'),
            }

        def filter_interfaces(intf_xmls):
            intf_entries = (etree.fromstring(counter_xml.encode('utf8')) for
                            counter_xml in intf_xmls)
            return {
                parse(intf_entry, './bulk/data/interface/name'):
                    extract_counter_values(intf_entry)
                for intf_entry in intf_entries
                if parse(intf_entry,
                         './bulk/data/interface/statistics/in-broadcast-pkts') is
                not None and not is_management_interface(
                    parse(intf_entry, './bulk/data/interface/type'))
            }

        counters = filter_interfaces(parse_multiple_xmls(
            self.device.get_text('show interface | display-xml')))

        if not self.prev_timestamp:
            self.prev_counters = counters
            self.prev_timestamp = timestamp
            return

        delta_seconds = (timestamp - self.prev_timestamp).total_seconds()

        def data(intf_name):
            def rate(value, prev_value):
                if value <= prev_value:
                    # this can happen when counters are reset
                    return 0

                # IBA and other parts of AOS assume counters are expressed in rate
                #  per 5 seconds
                rate_per_second = (value - prev_value) / delta_seconds
                return int(math.ceil(rate_per_second * DEFAULT_DELTA))

            def counter_rate(key):
                return rate(counters[intf_name][key],
                            self.prev_counters[intf_name][key])

            result = {
                counter_key: counter_rate(counter_key)
                for counter_key in self.prev_counters[intf_name]
            }
            result['interface_name'] = intf_name
            return result

        self.post_data(
            json.dumps({
                'items': [
                    data(intf_name)
                    for intf_name in counters.iterkeys()
                    # new interfaces (ex: port-channels, port breakouts) can get
                    # added dynamically. We need at-least a baseline to publish a
                    # rate
                    if intf_name in self.prev_counters
                ],
                'delta_seconds': DEFAULT_DELTA,
            })
        )
        self.prev_counters = counters
        self.prev_timestamp = timestamp


def collector_plugin(_device):
    return InterfaceCounterRateCollector
