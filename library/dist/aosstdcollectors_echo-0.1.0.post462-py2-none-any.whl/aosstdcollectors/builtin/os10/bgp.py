# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula
import json
from lxml import etree
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.os10_util import parse, parse_multiple_xmls, BgpVrfValue
from aosstdcollectors.utils.platform_independent import DEFAULT_VRF_NAME


class BgpCollector(BaseTelemetryCollector):

    def parse_bgp(self):
        def parse_data(bgp_data):
            peer_entries = bgp_data.xpath('//bulk/data/peer-oper')
            if not peer_entries or len(peer_entries) < 1:
                return []
            peer_entry = peer_entries[0]
            address_family = 'ipv4' if parse(peer_entry,
                                             './peer-negotiated-version') == '4' \
                else 'ipv6'
            fsm_state = parse(peer_entry, './bgp-state')
            value = BgpVrfValue.up if fsm_state == 'established' \
                else BgpVrfValue.down

            return [
                {
                    'source_ip': parse(peer_entry, './local-address'),
                    'source_asn': parse(peer_entry, './local-as'),
                    'dest_ip': parse(peer_entry, './remote-address'),
                    'dest_asn': parse(peer_entry, './remote-as'),
                    'vrf_name': (parse(bgp_data, './data/bgp-oper/vrf/vrf-name') or
                                 DEFAULT_VRF_NAME),
                    'addr_family': address_family,
                    'fsm_state': fsm_state,
                    'value': value,
                }
            ]

        data_xmls = parse_multiple_xmls(
            self.device.get_text('show ip bgp summary | display-xml'))

        return [
            bgp_entry
            for data_xml in data_xmls
            if 'BGP not active' not in data_xml
            for bgp_entry in parse_data(etree.fromstring(data_xml.encode('utf8')))

        ]

    def collect(self):
        self.post_data(json.dumps(dict(items=self.parse_bgp())))


def collector_plugin(_):
    return BgpCollector
