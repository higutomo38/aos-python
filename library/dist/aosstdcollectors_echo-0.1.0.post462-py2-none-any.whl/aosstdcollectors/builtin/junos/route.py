# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula
import json
import logging

from netaddr import IPNetwork, AddrFormatError
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector

LOG = logging.getLogger(__name__)


class RouteCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(RouteCollector, self).__init__(*args, **kwargs)
        self._spec = None

    @property
    def spec(self):
        if self._spec:
            return self._spec

        self._spec = self.device.load_table_view_spec(
            {
                "RouteTable": {
                    "rpc": "get-route-information",
                    # TODO(roman) ignore IPv6 routes until
                    # https://apstrktr.atlassian.net/browse/AOS-8965 is resolved
                    "item": "route-table[table-name='inet.0']/rt",
                    "view": "RouteView",
                    "key": "rt-destination",
                },
                "RouteView": {
                    "fields": {
                        "destination": "rt-destination",
                        "route_entries": "_RtEntryTable",
                    }
                },
                "_RtEntryTable": {
                    "item": "rt-entry",
                    "view": "_RtEntryView",
                },
                "_RtEntryView": {
                    "fields": {
                        "active_tag": "active-tag",
                        "protocol_name": "protocol-name",
                        "is_active": {"current-active": "flag"},
                        "next_hops": "_HopsTable",
                    }
                },
                "_HopsTable": {
                    # only select entries with <to> node set for better efficiency
                    "item": "nh[to]",
                    "view": "_HopsView",
                },
                "_HopsView": {
                    "fields": {
                        "ip": "to",
                        "via": "via",
                        "local_interface": "nh-local-interface",
                    }
                },
            }
        )

        return self._spec

    def collect(self):
        def hop_type(r):
            # AOS expected values: ['unknown', 'direct', 'bgp', 'stat']
            if r.protocol_name in ["Static", "Local"]:
                return "stat"
            if r.protocol_name == "BGP":
                return "bgp"
            if r.protocol_name == "Direct":
                return "direct"
            return "unknown"

        def route_status(r):
            return "up" if any(re.is_active for re in r.route_entries) else "unknown"

        def hop_status(_h):
            # AOS expected values: ['unknown', 'up', 'missing']
            # Interpret hops that are present as "up".
            # TODO(roman): return "missing" if actual config deviates from expected.
            # This requires changes in route collectors for all platforms (eos, nxos,
            # etc), and change to device driver.
            return "up"

        def tag(rt_entry, h):
            return h.local_interface if rt_entry.protocol_name == "Local" else h.via

        def prefix(dest):
            return str(IPNetwork(dest).ip)

        def prefix_len(dest):
            return str(IPNetwork(dest).prefixlen)

        def valid(dest):
            # Consider any destination that is not IPv4 CIDR as invalid
            # According to https://www.juniper.net/documentation/en_US/junos/topics/
            #                     reference/command-summary/show-route.html
            # `destination` field may have following values:
            #  * Route destination (for example:10.0.0.1/24).
            #  * MPLS-label (for example, 80001).
            #  * interface-name (for example, ge-1/0/2).
            #  * neighbor-address:control-word-status:encapsulation_type:vc-id:source
            #    Layer 2 circuit only. E.g, `10.1.1.195:NoCtrlWord:1:1:Local/96`,
            #    where:
            #    ** `neighbor-address` - Address of the neighbor.
            #    ** `control-word-status` - Whether the use of the control word has
            #        been negotiated for this virtual circuit: NoCtrlWord or
            #        CtrlWord.
            #    ** `encapsulation_type` - Type of encapsulation, represented by a
            #        number: (1) Frame Relay DLCI, (2) ATM AAL5 VCC transport,
            #        (3) ATM transparent cell transport, (4) Ethernet, (5) VLAN
            #        Ethernet, (6) HDLC, (7) PPP, (8) ATM VCC cell transport,
            #        (10) ATM VPC cell transport.
            #    ** `vc-id` - Virtual circuit identifier.
            #    ** `source` - Source of the advertisement: Local or Remote.
            try:
                IPNetwork(dest)
                return True
            except AddrFormatError as e:
                LOG.warning("Route ignored: '%s'. Error message: '%s'", dest, e)
                return False

        items = []
        for route in self.device.create_table(self.spec["RouteTable"]).get():
            if valid(route.destination):
                for entry in route.route_entries:
                    if entry.active_tag == "*":
                        next_hop_list = []
                        for hop in entry.next_hops:
                            next_hop_list.append(
                                {
                                    "prefix": hop.ip,
                                    # Junos doesn't have prefix len
                                    # for hops, default to 32
                                    "prefix_len": "32",
                                    "tag": tag(entry, hop),
                                    "type": hop_type(entry),
                                    "status": hop_status(hop),
                                }
                            )
                        items.append({"prefix": prefix(route.destination),
                                      "prefix_len": prefix_len(route.destination),
                                      "route_status": route_status(route),
                                      "next_hops": next_hop_list})
                        break

        self.post_data(json.dumps(dict(items=items)))


def collector_plugin(_):
    return RouteCollector
