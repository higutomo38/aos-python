# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula
import json

from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.junos_util import is_management_interface
from aosstdcollectors.utils.platform_independent import DEFAULT_VRF_NAME


class ArpCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(ArpCollector, self).__init__(*args, **kwargs)
        self._spec = None

    @property
    def spec(self):
        if self._spec:
            return self._spec

        self._spec = self.device.load_table_view_spec(
            {
                "ArpTable": {
                    "rpc": "get-arp-table-information",
                    "item": "arp-table-entry",
                    "args": {"no-resolve": True},
                    "view": "ArpTableView",
                },
                "ArpTableView": {
                    "fields": {
                        "mac_address": "mac-address",
                        "ip_address": "ip-address",
                        "interface_name": "interface-name",
                        "is_dynamic": {"arp-table-entry-flags/none": "flag"},
                    }
                },
            }
        )

        return self._spec

    def collect(self):
        # TODO(roman): l2_info
        # `l2_info` in builtin agents:
        #   - cisco - unused;
        #   - cumulus - unused;
        #   - arista - for `interface_name == "Vlan2999, Port-Channel1"` l2_info
        #     would be set to "Port-Channel1" and interface_name to "Vlan2999".
        items = [
            {
                "vrf_name": DEFAULT_VRF_NAME,
                "ip_address": arp.ip_address,
                "mac_address": arp.mac_address,
                "interface_name": arp.interface_name,
                "type": "dynamicArp" if arp.is_dynamic else "staticArp",
            }
            for arp in self.device.create_table(self.spec["ArpTable"]).get()
            if not is_management_interface(arp.interface_name)
        ]

        self.post_data(json.dumps(dict(items=items)))


def collector_plugin(_):
    return ArpCollector
