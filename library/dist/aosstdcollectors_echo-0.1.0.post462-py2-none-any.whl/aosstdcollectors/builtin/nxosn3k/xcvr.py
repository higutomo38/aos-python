# Copyright 2019-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula
import json
import logging

from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector

LOG = logging.getLogger(__name__)


class XcvrCollector(BaseTelemetryCollector):
    def _xcvr_global(self):
        for iface in self.device.get_json(
                'show interface status').get(
                    'TABLE_interface', {}).get('ROW_interface', {}):
            if iface['state'] == 'connected' and iface['type'] == '10Gbase-SR':
                yield iface['interface']

    def _xcvr_interfaces(self):
        return [
            {
                'interface': iface,
                'xcvr_detail': self.device.get_text(
                    'show interface ethernet %s transceiver details' % iface)
            }
            for iface in self._xcvr_global()
            if not iface.startswith('mgmt')
        ]

    def collect(self):
        self.post_data(json.dumps({'items': self._xcvr_interfaces()}))


def collector_plugin(_device):
    return XcvrCollector
