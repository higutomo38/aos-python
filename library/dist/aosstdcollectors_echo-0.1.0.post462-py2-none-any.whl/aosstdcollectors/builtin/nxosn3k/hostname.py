# Copyright 2019-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

import json
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector


def parse_hostname(collected):
    return json.dumps({
        'items': [
            {
                "domain": '',
                "hostname": collected['hostname'],
            }
        ]
    })


class HostnameCollector(BaseTelemetryCollector):
    def collect(self):
        collected_data = self.device.get_json('show hostname')
        self.post_data(parse_hostname(collected_data))


def collector_plugin(_device):
    return HostnameCollector
