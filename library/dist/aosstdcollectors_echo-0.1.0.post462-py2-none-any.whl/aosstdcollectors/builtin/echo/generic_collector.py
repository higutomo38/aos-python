# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

# Pylint disable required because of the virtual env behavior.
# https://github.com/PyCQA/pylint/issues/73
# pylint: disable=no-name-in-module
from distutils.version import LooseVersion as Version
import json
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.compat.aos.sdk.system_agent.device import \
    get_running_aos_version


class GenericCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(GenericCollector, self).__init__(*args, **kwargs)
        self.aos_version = get_running_aos_version()

    def get_value(self, data):
        if not data:
            return None

        if Version(self.aos_version) < Version('2.3.0'):
            return data

        try:
            loaded_data = json.loads(data)
        except ValueError:
            pass
        else:
            if isinstance(loaded_data, dict):
                return loaded_data

        return data

    def collect(self):
        input_tac_json = json.loads(self.service_config.input) \
            if self.service_config.input else {}

        self.post_data(json.dumps({
            'global': input_tac_json.get('global', ''),
            'items': [
                {
                    'identity': entry.get('id', ''),
                    'value': self.get_value(entry.get('data', '')),
                }
                for entry in input_tac_json.get('state', {}).itervalues()
            ]
        }))


def collector_plugin(_device):
    return GenericCollector
