# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

import re

from aosstdcollectors.utils.platform_independent import DEFAULT_VRF_NAME

VALID_LAG_MEMBER_INTF_REGEX = re.compile(r'^(ge|xe|xle|fte|et).*$')

# Unable to find a deterministic way (even with non-terse output) to only
# include physical and lag interfaces. So resorting to regex here..
# ge - 1g ethernet
# xe - 10g ethernet
# xle - 40g ethernet
# fte - 40g data plane uplink interface
# et - 40g or 100g ethernet
# ae - aggregate interface (aka port channels)
VALID_INTF_REGEX = re.compile(r'^(ge|xe|xle|fte|et|ae).*')


def is_management_interface(iface_name):
    # see https://www.juniper.net/documentation/en_US/junos/topics/concept
    # /interfaces-interface-naming-overview.html
    return iface_name.startswith("em") or iface_name.startswith("fxp")


def intf_name(if_name):
    # We want to treat first logical interface without the suffix. Ex: 'xe-0/0/0.0'
    # becomes 'xe-0/0/0'. This is done to make the default case more intuitive and
    # stuff like lldp also reports only the base names
    return re.sub(r"\.0$", "", if_name)


def bgp_neighbor_state(state):
    """Converts Junos BGP neighbor state (see below) to AOS BGP state - 'up' or
    'down'

    Junos BGP neighbor states:
     - `Active` - BGP is initiating a transport protocol connection in an
    attempt to connect to a peer. If the connection is successful, BGP
    sends an Open message.
     - `Connect` - BGP is waiting for the transport protocol connection to be
    completed.
     - `Established` - The BGP session has been established, and the peers are
    exchanging update messages.
     - `Idle` - This is the first stage of a connection. BGP is waiting for a
    Start event.
     - `OpenConfirm` - BGP has acknowledged receipt of an open message from
    the peer and is waiting to receive a keepalive or notification message.
     - `OpenSent` - BGP has sent an open message and is waiting to receive an
    open message from the peer.
     - `route reflector client` - The BGP session is established with a route
    reflector client.

    see https://www.juniper.net/documentation/en_US/junos/topics/reference/
               command-summary/show-bgp-neighbor.html
    """
    up_states = ["Established", "route reflector client"]
    return "up" if state in up_states else "down"


def vrf_name(name):
    if name == "master":
        return DEFAULT_VRF_NAME
    return name


def bgp_address_family(name):
    if name == 'evpn':
        return 'evpn'
    if name == 'inet6-unicast':
        return 'ipv6'
    if name == 'inet-unicast':
        return 'ipv4'
    return 'ipv4'
