# Copyright 2019-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

from collections import namedtuple

SfpMetricInfo = namedtuple(
    'SfpMetricInfo',
    ['value_field', 'threshold_field_prefix', 'output_field'])


SFP_METRICS = [
    SfpMetricInfo('temperature', 'temp', 'temperature'),
    SfpMetricInfo('voltage', 'volt', 'voltage'),
    SfpMetricInfo('current', 'current', 'tx_bias'),
    SfpMetricInfo('tx_pwr', 'tx_pwr', 'tx_power'),
    SfpMetricInfo('rx_pwr', 'rx_pwr', 'rx_power'),
]


def convert_mac_address(mac_address):
    """ Convert other common mac address formats to standard
        e.g ab-cd-12-34-56-78 or abcd.1234.5678 => ab:cd:12:34:56:78
    """
    if '-' in mac_address:
        return mac_address.replace('-', ':')
    elif '.' in mac_address:
        mac_addr_str = mac_address.replace('.', '')
        return ':'.join(
            [''.join(x) for x in zip(*[iter(mac_addr_str)]*2)]
        )
    return mac_address
