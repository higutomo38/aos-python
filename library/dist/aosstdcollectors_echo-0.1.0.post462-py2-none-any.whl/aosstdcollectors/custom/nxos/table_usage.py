# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula


import json

from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.nxos_util import MANAGEMENT_VRF_NAME
from collections import defaultdict


def parse_vrf(data):
    vrf_data_list = data["TABLE_vrf"]["ROW_vrf"]
    vrfs = [vrf_data["vrf_name"] for vrf_data in vrf_data_list]
    return vrfs


class TableUsage(BaseTelemetryCollector):
    """
    Multicast, routing and ARP tables usage
    """

    def get_ip_routes(self, vrfs):
        results = defaultdict(lambda: dict(num_ip_routes=0))
        for vrf in vrfs:
            data = self.device.get_json('show ip route summary vrf ' + vrf)
            ip_routes = int(data["TABLE_vrf"]["ROW_vrf"]["TABLE_addrf"]
                            ["ROW_addrf"]["TABLE_summary"]["ROW_summary"]
                            ["routes"])

            results[vrf]['num_ip_routes'] = ip_routes
            results['total']['num_ip_routes'] += ip_routes

        return [
            {
                'identity': '%s|num_ip_routes' % vrf,
                'value': str(results[vrf]['num_ip_routes'])
            }
            for vrf in results
        ]

    def get_arp_entries(self, vrfs):
        results = defaultdict(lambda: dict(num_arp_entries=0))

        for vrf in vrfs:
            total_entries = int(self.device.get_json('show ip arp vrf ' + vrf)
                                ["TABLE_vrf"]["ROW_vrf"]["cnt-total"])

            results[vrf]['num_arp_entries'] = total_entries
            results['total']['num_arp_entries'] += total_entries

        return [
            {
                'identity': '%s|num_arp_entries' % vrf,
                'value': str(results[vrf]['num_arp_entries'])
            }
            for vrf in results
        ]

    def get_mcast_table(self, vrfs):
        results = defaultdict(lambda: dict(
            num_mcast_routes=0,
            num_mcast_sources=0,
            num_mcast_groups=0
        ))

        for vrf in vrfs:
            data = self.device.get_json('show ip mroute summary vrf ' + vrf)
            mcast_data = data.get("TABLE_vrf", {}).get("ROW_vrf", {}).\
                get("TABLE_route_summary", {}).get("ROW_route_summary", {})
            if mcast_data:
                results[vrf]['num_mcast_routes'] = int(mcast_data.get('sg-route', 0))
                results[vrf]['num_mcast_groups'] = \
                    int(mcast_data.get('group-count', 0))
                results['total']['num_mcast_routes'] += \
                    int(mcast_data.get('sg-route', 0))
                results['total']['num_mcast_groups'] += \
                    int(mcast_data.get('group-count', 0))

        return [
            {
                'identity': '%s|%s' % (vrf, metric),
                'value': str(results[vrf][metric])
            }
            for vrf in results
            for metric in results[vrf]
        ]

    def create_breakdown(self, data, key):
        breakdown = defaultdict(dict)

        for e in data:
            vrf = e['identity'].split('|')[0]
            value = e['value']
            breakdown[vrf] = value

        return [
            {
                'identity': key,
                'value': json.dumps(breakdown, indent=2, sort_keys=True)
            }
        ]

    def create_mcast_breakdown(self, data):
        breakdown = defaultdict(dict)
        for e in data:
            key, metric = e['identity'].split('|')
            value = e['value']
            breakdown[metric][key] = value

        return [
            {
                'identity': 'mcast_data',
                'value': json.dumps(breakdown, indent=2, sort_keys=True)
            }
        ]

    def collect(self):
        vrfs = parse_vrf(self.device.get_json('show vrf'))
        vrfs.remove(MANAGEMENT_VRF_NAME)
        mcast_data = self.get_mcast_table(vrfs)
        arp_entries = self.get_arp_entries(vrfs)
        ip_routes = self.get_ip_routes(vrfs)
        arp_breakdown = self.create_breakdown(arp_entries, 'arp_entries')
        ip_route_breakdown = self.create_breakdown(ip_routes, 'ip_routes')
        mcast_breakdown = self.create_mcast_breakdown(mcast_data)
        self.post_data(json.dumps({
            'items':
                mcast_data + arp_entries + ip_routes
                + arp_breakdown + ip_route_breakdown + mcast_breakdown
        }))


def collector_plugin(_device):
    return TableUsage
