# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.compat.aos.sdk.system_agent.device import \
    get_running_aos_version
from aosstdcollectors.utils.data_util import to_extensible_postdata
from aosstdcollectors.utils.nxos_util import get_interface_fullname, \
    build_lldp_neighbor


class LldpDetailsCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(LldpDetailsCollector, self).__init__(*args, **kwargs)
        self.aos_version = get_running_aos_version()

    def parse_lldp_details(self, data):
        neighbors = data.get('TABLE_nbor_detail', {}).get('ROW_nbor_detail', [])
        if not isinstance(neighbors, list):
            neighbors = [neighbors]

        return {
            get_interface_fullname(neighbor.get('l_port_id', 'None')): dict({
                'chassis_id': neighbor.get('chassis_id'),
                'chassis_id_type': neighbor.get('chassis_type')
            }, **build_lldp_neighbor(neighbor)) for neighbor in neighbors
        }

    def collect(self):
        data = self.device.get_json('show lldp neighbors detail')
        self.post_data(to_extensible_postdata(
            self.parse_lldp_details(data),
            aos_version=self.aos_version,
        ))


def collector_plugin(_device):
    return LldpDetailsCollector
