# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

from lxml import etree
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.compat.aos.sdk.system_agent.device import \
    get_running_aos_version
from aosstdcollectors.utils.data_util import to_extensible_postdata
from aosstdcollectors.utils.os10_util import parse, parse_list, \
    is_management_interface, parse_multiple_xmls, is_valid_interface, \
    extract_vlan_id_from_name

DEFAULT_BANDWIDTH_MB = 10000


def bandwidth(speed):
    if speed is None:
        return DEFAULT_BANDWIDTH_MB
    if int(speed) == 0:
        return DEFAULT_BANDWIDTH_MB
    return int(speed) / 1000000


def type_of(intf_type, ipv4_addr):
    """
        Possible interface types:

         - ethernet (L2)
         - loopback
         - svi
         - port_channel
         - management

        :param iface: interface name and type from 'show interface | display-xml'
        :return:
        """
    if intf_type == 'ianaift:ethernetCsmacd':
        return 'ip' if ipv4_addr else 'ethernet'
    if intf_type == 'ianaift:ieee8023adLag':
        return 'port_channel'
    if intf_type == 'ianaift:l2vlan':
        return 'svi'
    if is_management_interface(intf_type):
        return 'management'
    return 'ethernet'


def get_vlan_id(intf_name, intf_type):
    if intf_type == 'svi':
        return extract_vlan_id_from_name(intf_name)
    return None


def get_mlag_id(id_str):
    if id_str is not None:
        return int(id_str)
    return None


def populate_interfaces(xml_interfaces):
    parent_interfaces = {}

    def build(intf):
        def get_parent():
            cms_info = intf.xpath(
                '//rpc-reply/data/cms-interface-backptr/interface-in-running')
            return parse(cms_info[0], './lag-member') if cms_info else None

        intf_info = intf.xpath('//bulk/data/interface')[0]
        intf_name = parse(intf_info, './name')
        ipv4_addr = parse(intf_info, './ipv4-info/addr')
        intf_type = type_of(parse(intf_info, './type'), ipv4_addr)
        allowed_vlans = [extract_vlan_id_from_name(vlan_name) for vlan_name in
                         parse_list(intf_info, './tagged-vlans')]
        interface = {
            'name': intf_name,
            'allowed_vlans': allowed_vlans,
            'description': parse(intf_info, './description'),
            'speed_mbps': bandwidth(parse(intf_info, './speed')),
            'ipv4_addr': ipv4_addr,
            'type': intf_type,
            'parent': get_parent(),
            'native_vlan': extract_vlan_id_from_name(
                parse(intf_info, './untagged-vlan')),
            'mlag_id': get_mlag_id(
                parse(intf, './data/interfaces/interface/vlt/vlt-id')),
            # TODO left empty for now since boeing don't have them configured
            'subinterface_id': None,
            # OS10 has 'access' as default
            'mode': 'trunk' if allowed_vlans else 'access',
            # TODO left empty for now since boeing don't have them configured
            'virtual_ips': [],
            'virtual_macs': [],
            'vlan_id': get_vlan_id(intf_name, intf_type)
        }

        # sometimes we've seen os10 not report lag-member field, so still following
        # this alternate path to discover membership
        if intf_type == 'port_channel':
            member_interfaces = intf_info.findall('./active-member-ports')
            for member_interface in member_interfaces:
                parent_interfaces[member_interface.text] = intf_name

        return interface

    return {
        parse(interface, './bulk/data/interface/name'): build(interface)
        for interface in xml_interfaces
        if (parse(interface, './bulk/data/interface/name') is not None and
            is_valid_interface(parse(interface, './bulk/data/interface/type')))
    }, parent_interfaces


def update_parent_interfaces(interfaces, parent_interfaces):
    for interface_name, interface in interfaces.iteritems():
        if interface.get('parent'):
            continue
        interface['parent'] = parent_interfaces.get(interface_name)

    return interfaces


class InterfaceDetailsCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(InterfaceDetailsCollector, self).__init__(*args, **kwargs)
        self.aos_version = get_running_aos_version()

    def collect(self):
        intf_xmls = parse_multiple_xmls(
            self.device.get_text('show interface | display-xml'))
        intf_entries = (etree.fromstring(intf_xml.encode('utf8'))
                        for intf_xml in intf_xmls)
        interfaces, parent_interfaces = populate_interfaces(intf_entries)
        interfaces = update_parent_interfaces(interfaces, parent_interfaces)
        self.post_data(to_extensible_postdata(interfaces,
                                              aos_version=self.aos_version))


def collector_plugin(_device):
    return InterfaceDetailsCollector
