# Copyright 2020-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula


# flake8: noqa E501


from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.textparsing import TextFsmParser

DISK_UTIL_CMD = 'df'
MOUNT_CMD = 'mount'

MOUNT_TEMPLATE = r''' #TextFSM
Value partition (\S+)
Value file (\S+)
Value mount_info (\(.*\))

Start
  ^${partition}\son\s${file}\s${mount_info} -> Record

EOF
'''

DISK_UTIL_TEMPLATE = r''' #TextFSM
Value fs (\S+)
Value blocks (\d+)
Value used (\d+)
Value available (\d+)
Value use_percentage (\d+)
Value mounted_on (\S+)

Start
  ^${fs}\s+${blocks}\s+${used}\s+${available}\s+${use_percentage}%\s+${mounted_on} -> Record

EOF
'''


# TODO (pranshu): Extend this collector class from DiskUtilCollector of linux once
#  this is moved to Leblon. Ref Jira issue: AOS-17488
class JunosDiskUtilCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(JunosDiskUtilCollector, self).__init__(*args, **kwargs)
        self.mount_buffer_parser = TextFsmParser(MOUNT_TEMPLATE)
        self.df_buffer_parser = TextFsmParser(DISK_UTIL_TEMPLATE)

    def collect(self):
        def collect_writable_mount_partitions():
            parsed_mount_data = self.mount_buffer_parser.parse(
                self.device.get_text(MOUNT_CMD)
            )

            return [
                mounted_on
                for _, mounted_on, mount_info in parsed_mount_data
                if all(
                    param not in mount_info
                    for param in ['read-only', 'devfs', 'procfs']
                )
            ]

        def collect_disk_util():
            df_data = self.device.get_text(DISK_UTIL_CMD)
            parsed_df_data = self.df_buffer_parser.parse(df_data)

            if not parsed_df_data:
                raise ValueError('Unable to parse df output {}'.format(df_data))

            return [
                {
                    'key': {
                        'metric': mounted_on
                    },
                    'value': int(used_percentage)
                }
                for _, _, _, _, used_percentage, mounted_on in parsed_df_data
                if mounted_on in writable_partitions
            ]

        writable_partitions = collect_writable_mount_partitions()
        output = collect_disk_util()

        output.append(
            {
                'key': {
                    'metric': 'highest_utilized_partition_perc'
                },
                'value': max(item.get('value') for item in output)
            }
        )

        self.post_data(output)


def collector_plugin(_):
    return JunosDiskUtilCollector
