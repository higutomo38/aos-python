# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula


from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
import logging
from aosstdcollectors.utils.data_util import to_extensible_postdata, \
    format_generic_value
from aosstdcollectors.compat.aos.sdk.system_agent.device import \
    get_running_aos_version


LOG = logging.getLogger(__name__)


class EVPNType3Collector(BaseTelemetryCollector):

    def __init__(self, *args, **kwargs):
        super(EVPNType3Collector, self).__init__(*args, **kwargs)
        self.aos_version = get_running_aos_version()

    def collect(self):

        data = self.device.get_json(
            'show bgp evpn route-type imet detail')

        if not data:
            self.post_data(
                to_extensible_postdata({}, aos_version=self.aos_version))
            return
        vteps = {}

        # pylint: disable=unused-variable
        def get_ip(path):
            return path.get('routeDetail', {}).get('peerEntry', {}).get(
                'peerRouterId', {})

        for rd_data in data.get('evpnRoutes', {}).itervalues():
            rd = rd_data.get('routeKeyDetail', {}).get('rd')
            vtep = rd_data.get('routeKeyDetail', {}).get('ipGenAddr')
            identity = '%s|%s' % (rd, vtep)
            # TODO JP: use this when we have a better chance of stronger schemas,
            # but leave it here.
            # value = {
            #     'rd': rd,
            #     'vtep': vtep,
            #     'next_hops': list(set([
            #         get_ip(path)
            #         for path in rd_data.get('evpnRoutePaths', [])
            #         if get_ip(path) != '0.0.0.0'
            #     ])),
            # }
            value = "1"
            vteps[identity] = format_generic_value(self.aos_version, value)

        self.post_data(to_extensible_postdata(vteps, aos_version=self.aos_version))


def collector_plugin(_device):
    return EVPNType3Collector

# EOF
