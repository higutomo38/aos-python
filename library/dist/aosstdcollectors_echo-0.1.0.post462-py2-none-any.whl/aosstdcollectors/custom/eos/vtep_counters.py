# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

"""
Objective 1: Have to first check if hardware telemetry is enabled on device to
capture VXLAN counters (only applicable on Arista Trident platforms like the 7050X)
Objective 2: To count the amount of encapsulated and decapsulated VXLAN packets
that are received and sent by a VTEP, and to compare the percentage of BUM
traffic present in the network

CLI command: show platform trident flexcounters vtep decap summary
CLI command: show vxlan counters vtep decap
CLI command: show vxlan counters vtep decap unlearnt

Expected output (which parts of the command result to fetch?):
 - Collect the total amount of decap Bytes - gives the total amount of packets on
   a VXLAN VLAN
 - Collect the total amount of decap known unicast packets on a VXLAN VLAN
 - Collect the total amount of decap BUM packets on a VXLAN VLAN
 - Collect the total amount of decap packets from unlearnt vteps
"""

from pyeapi.eapilib import CommandError

from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.data_util import to_extensible_postdata


class VtepCountersCollector(BaseTelemetryCollector):
    def collect(self):
        feature_supported = True
        vtep_counters = {}
        try:
            vtep_decap_summary = self.device.get_json(
                "show platform trident flexcounters vtep decap summary"
            )['vteps']
            if not vtep_decap_summary or any(
                    d['baseCounterIndex'] == -1 and d['poolId'] == -1 and d[
                        'offsetMode'] == -1
                    for d in vtep_decap_summary.itervalues()):
                feature_supported = False

            vtep_counters = self.device.get_json("show vxlan counters vtep decap")
        except CommandError:
            feature_supported = False

        def counters_enabled():
            return {"counters_enabled": "1" if feature_supported else "0"}

        def counters_data():
            def get_vtep_data(vtep, data):
                bum_pkts = data["decapBUMPkts"]
                total_pkts = data["decapBUMPkts"] + data["decapKnownUcastPkts"]
                bum_to_total = (
                    100.0 * bum_pkts / total_pkts if total_pkts != 0 else 0
                )
                return {
                    "%s_decap_bum_pkts" % vtep: bum_pkts,
                    "%s_decap_total_pkts" % vtep: total_pkts,
                    "%s_bum_to_total_percentage" % vtep: bum_to_total,
                }

            return {
                k: v
                for vtep, vtep_data in vtep_counters["vteps"].iteritems()
                for k, v in get_vtep_data(vtep, vtep_data).iteritems()
            }

        def unlearnt_data():
            if not vtep_counters.get('unlearntVteps'):
                return {}
            return {
                "unlearnt_vteps_decap_bum_pkts": str(
                    vtep_counters["unlearntVteps"]["decapBUMPkts"]
                )
            }

        def merge_dicts(dicts):
            return {k: v for d in dicts for k, v in d.iteritems()}

        dicts = (
            [counters_enabled(), counters_data(), unlearnt_data()]
            if feature_supported
            else [counters_enabled()]
        )

        self.post_data(to_extensible_postdata(merge_dicts(dicts)))


def collector_plugin(_device):
    return VtepCountersCollector
