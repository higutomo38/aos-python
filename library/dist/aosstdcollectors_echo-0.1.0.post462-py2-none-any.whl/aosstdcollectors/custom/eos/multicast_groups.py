# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

"""
Collector to check the number of sources per group
"""

import json
import logging
from collections import defaultdict
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.compat.aos.sdk.system_agent.device import \
    get_running_aos_version
from aosstdcollectors.utils.eos_util import try_get_json
from aosstdcollectors.utils.eos_vrf_util import read_vrfs

LOG = logging.getLogger(__name__)


class MulticastGroupsCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(MulticastGroupsCollector, self).__init__(*args, **kwargs)
        self.aos_version = get_running_aos_version()

    def get_groups(self, vrf):
        sg_data = try_get_json(self.device, 'show ip mroute vrf ' + vrf)
        groups = {
            group: {
                'sources': sorted(
                    source
                    for source in group_info.get('groupSources', {})
                    if source != '0.0.0.0'
                )
            }
            for group, group_info in sg_data.get('groups', {}).iteritems()
        }

        groups_by_source_count = defaultdict(list)
        for group, group_data in groups.iteritems():
            groups_by_source_count[len(group_data['sources'])].append(group)

        return {
            'groups': groups,
            'groups_by_source_count': groups_by_source_count,
        }

    def collect(self):
        vrfs = read_vrfs(self.device)
        self.post_data(json.dumps({
            'items': [
                {
                    'identity': vrf,
                    'value': json.dumps(
                        self.get_groups(vrf), indent=2, sort_keys=True)
                }
                for vrf, vrf_info in vrfs.iteritems()
                if vrf_info['role'] != 'management' and
                vrf_info['multicast_mode'] == 'enabled'
            ]
        }, sort_keys=True))


def collector_plugin(_device):
    return MulticastGroupsCollector
