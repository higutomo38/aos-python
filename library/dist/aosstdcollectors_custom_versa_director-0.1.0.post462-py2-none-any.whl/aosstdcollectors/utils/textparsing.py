# Copyright 2018, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula


import io
import csv
from textfsm import TextFSM

__all__ = [
    'TextFsmParser',
    'TextTableParser',
    'TextTableFixedColumnParser'
]


class TextFsmParser(object):
    """
    A TextFsmParser is used to parse Text string input using a TextFSM
    template definition.  For details on TextFSM, see the Google library
    documentation available here: <TODO>
    """
    def __init__(self, template):
        """
        Initialize this instance using the TextFSM template provided
        :attr:`template`.

        Parameters
        ----------
        template : str
            The TextFSM definition as a string.
        """
        self.fsm_table = TextFSM(io.BytesIO(template))
        self.headers = map(str, self.fsm_table.header)

    def clear(self):
        """
        This method is used to clear the values currently stored
        withing the TextFSM object structure.  When a TextFSM
        object is used multiple times, the data needs to be
        cleared before each use.
        """
        self.fsm_table.Reset()

    def parse(self, text):
        """
        Returns a table of data resulting from parsing the input
        :attr:`test` through the TextFSM template.

        Parameters
        ----------
        text: str
            The text string to parse.

        Returns
        -------
        list[list]
            A list object containing a list of data for each "parsed row"
            from the TextFSM template.
        """
        self.clear()
        return [map(str, item) for item in self.fsm_table.ParseText(text)]


class TextTableParser(object):
    """
    A TextTableParser is used to parse string input that is organized
    as table matrix, where each column of data is separated by a known
    delimiter.  A perfect example is a comma-separated-value (CSV) table.

    A TextTableParser uses the standard Python `csv` module to handle
    the specific string parsing.
    """
    def __init__(self, headings=None, key_handler=None, delimiter=' ',
                 data_lineno=None):
        """
        If a :attr:`table_key` is provided, then
        the User wants the parse function to return a dictionary
        representation of the data.  Otherwise the parse
        function will return a table (list[list]) structure.

        Parameters
        ----------
        key_handler: callable
            *optional* function that is invoked on each row to formulate the
            dictionary key.  If not provided, the :meth:`parse` returns a list
            of row items list[list].

        delimiter: char
            identifies the column delimiter character.  This
            is typically either ' ' (spaces) or ',' for CSV.

        data_lineno: int
            Identifies the specific line-number in the text where the
            data begins.  This allows the caller to skip any initial
            header/banner string text before processing the actual data.

        Any other optional parameters are specific to the `csv`
        module and used during the parsing function.
        """
        self.config = dict(
            key_handler=key_handler,
            delimiter=delimiter,
            data_lineno=data_lineno
        )

        self.headers = None

        self.csv_opts = dict(delimiter=delimiter)

        if delimiter == ' ':
            self.csv_opts['skipinitialspace'] = True

        if headings:
            self.csv_opts['fieldnames'] = headings

    def parse(self, text):
        read_io = io.BytesIO(text) if isinstance(text, str) else io.StringIO(text)
        reader = csv.DictReader(read_io, **self.csv_opts)
        self.headers = reader.fieldnames

        key_handler = self.config.get('key_handler')
        if not key_handler:
            return list(reader)

        return {
            key_handler(row): row
            for row in reader
        }


class TextTableFixedColumnParser(object):
    """
    A TextTableFixedColumnParser is used when the Text is arranged
    like a table (columns,rows), but the row data cannot be
    parsed by a simple character delimiter.  This happens when the
    row text itself has spaces within the value.

    A TextTableFixedColumnParser allows the user to define the
    column widths explicitly, which allows the parser to "cut"
    the data out of the text.  The resulting parsed data is
    returned to the caller as a list[list] structure.
    """
    def __init__(self, headings, headings_lineno,
                 data_widths, data_lineno,
                 key_handler):
        """
        When creating a new instance, the caller must provide the
        table parse definitions :attr:`table_def`.  This dictionary
        contains the following key/values:

        Parameters
        ----------
        headings: list[str]
            *Optional*
            This list is generally the table column header values.
            The caller can define any values, however, and these
            values are used when parsing each row of data.  These
            values become the inner key names of the data values.
            For example:
                'column_names': ['Module', 'Sensor', 'Temperature',
                                 'Thresholds', 'Status'],
            will result in each item in the parsed dictionary having
            a dictionary with keys named 'Module', 'Sensor', etc.

        headings_lineno: int
            *Optional*
            Identifies the specific line0number in the text where the
            table header begins.  When this option is used, the
            TextTableFixedColumnParser will auto-create the column_names
            based on parsing the data at the given `header_offset`

        data_widths: list[int]
            This list contains the select column width in characters.
            The length of column_widths must be the same as
            column_names.

        data_lineno: int
            Identifies the specific line-number in the text where the
            data begins.  This allows the caller to skip any initial
            header/banner string text before processing the actual data.

        key_handler: callable
            This is a user-defined callable that will get invoked
            on each data-item.  The callable is returned to
            return the key-name for the given row-item.
            For example, if we want a key constructed from
            multiple columns in the data:

                def make_table_key(data_item):
                    return "{}-{}".format(data_item['Sensor'],
                                          data_item['Module'])
        """
        self.config = dict(
            headings=headings,
            headings_lineno=headings_lineno,
            data_widths=data_widths,
            data_lineno=data_lineno,
            key_handler=key_handler)

        template = self.make_textfsm_template()
        self.textfsm_parser = TextFsmParser(template)
        self.headings = headings

    def make_textfsm_template(self):
        """
        This method is used to create a TextFSM based template
        from the table_def values.  The TextFSM library is used
        to perform the actual parsing right now.

        # TODO: could replace TextFSM within simplified slicing approach

        Returns
        -------
        str
            The TextFSM template string
        """
        values = [
            "Value Col{col_idx} (.{{,{col_len}}})".format(
                col_idx=idx, col_len=col_len)
            for idx, col_len in enumerate(self.config['data_widths'])]

        template = '\n'.join(values)
        template += '\n\nStart\n'

        record_def = ["${{Col{idx}}}".format(idx=idx)
                      for idx in range(len(values))]

        template += "  ^%s -> Record" % ''.join(record_def)
        template += '\n\nEOF\n'

        return template

    def parse_header_from_data(self, data):
        """
        This method is used to auto-create the column_headers
        value.  This is done either by using the table_def
        header_index value if given.  If it is not given,
        then the parser will simply use the first non-empty
        line of text.

        Parameters
        ----------
        data: str
            Text to parse

        Returns
        -------
        list
            The column_header values.
        """
        hdr_idx = self.config.get('headings_lineno')
        if hdr_idx:
            return data[hdr_idx]

        for row in enumerate(data):
            if row[0]:
                return map(str.strip, row)

    def parse(self, data_text):
        """
        This method will parse the given `data_text` string using
        the table_def parameters.

        Parameters
        ----------
        data_text: str
            Text input to parse.

        Returns
        -------
        dict
            The parsed data returned as a dictionary where each
            item has a key per the table_def.key_handler, and the
            data is a dictionary of key/value pairs using each
            row data.
        """
        table_def = self.config

        data = self.textfsm_parser.parse(data_text)

        column_headers = self.headings or self.parse_header_from_data(data)

        table_key_handler = table_def['key_handler']

        collected_data = dict()

        for data_row in data[table_def['data_lineno'] + 1:]:
            data_item = dict(zip(column_headers, map(str.strip, data_row)))
            data_key = table_key_handler(data_item)
            collected_data[data_key] = data_item

        return collected_data
