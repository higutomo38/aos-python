# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.data_util import to_extensible_postdata


class DeviceInfoCollector(BaseTelemetryCollector):
    def collect(self):
        collected = self.device.get_device_info()
        data = to_extensible_postdata(collected)
        self.post_data(data)
