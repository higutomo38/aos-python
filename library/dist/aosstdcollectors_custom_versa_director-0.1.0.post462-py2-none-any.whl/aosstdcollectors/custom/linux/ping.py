# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

import json
import logging
from aosstdcollectors.utils.platform_independent import valid_ipv4_addr
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.data_util import to_extensible_postdata
from aosstdcollectors.utils.textparsing import TextFsmParser

# flake8: noqa: line too long
# PING 8.8.8.8 (8.8.8.8): 56 data bytes
# ..Request timeout for icmp_seq 58
# ..Request timeout for icmp_seq 60
# .
# --- 8.8.8.8 ping statistics ---
# 100 packets transmitted, 99 packets received, 1.0% packet loss
# round-trip min/avg/max/stddev = 4.963/6.852/20.607/2.513 ms


# $ ping -c 100 10.0.0.3
# Password:
# PING 10.0.0.3 (10.0.0.3): 56 data bytes
# ..Request timeout for icmp_seq 0
# .Request timeout for icmp_seq 1
# .Request timeout for icmp_seq 2
# .Request timeout for icmp_seq 3
# .Request timeout for icmp_seq 98
#
# --- 10.0.0.3 ping statistics ---
# 100 packets transmitted, 0 packets received, 100.0% packet loss


# --- 8.8.8.8 ping statistics ---
# 100 packets transmitted, 99 packets received, 1.0% packet loss
# round-trip min/avg/max/stddev = 4.963/6.852/20.607/2.513 ms

# PING 8.8.8.8 (8.8.8.8) 56(84) bytes of data.


# --- 8.8.8.8 ping statistics ---
# 100 packets transmitted, 100 received, 0% packet loss, time 168ms
# rtt min/avg/max/mdev = 1.344/1.472/2.940/0.158 ms, ipg/ewma 1.704/1.435 ms

LOG = logging.getLogger(__name__)
DEFAULT_PING_COUNT = 10
ping_template = r''' #TextFSM
Value PacketCount (\d+)
Value PacketLoss (\d+(\.\d+)?)
Value RTMin (\d+(\.\d+)?)
Value RTAvg (\d+(\.\d+)?)
Value RTMax (\d+(\.\d+)?)
Value RTStdv (\d+(\.\d+)?)

Start
  ^.*--- .+ ping statistics -> TABLE

TABLE
  ^\s*${PacketCount}\s+packets\s+transmitted,\s+\d+.+received,( .+ errors,)?\s+${PacketLoss}%\s+
  ^(.+ min/avg/max/.+dev = ${RTMin}/${RTAvg}/${RTMax}/${RTStdv})? -> Record

EOF
'''
ping_parser = TextFsmParser(ping_template)


class PingStats(object):
    def __init__(
            self, packet_transmitted=0, packet_loss_percent=0, round_trip_min=0,
            round_trip_avg=0, round_trip_max=0, round_trip_stddev=0):
        self.packet_transmitted = int(packet_transmitted)
        self.packet_loss_percent = self._val(packet_loss_percent)
        self.round_trip_min = self._val(round_trip_min, 1000)
        self.round_trip_avg = self._val(round_trip_avg, 1000)
        self.round_trip_max = self._val(round_trip_max, 1000)
        self.round_trip_stddev = self._val(round_trip_stddev, 1000)
        self.__count = 1

    def _val(self, v, multiplier=1):
        return int(round(float(v) * multiplier)) if v else 0

    def aggregate(self, other):
        curr_count = self.__count
        curr_loss_percent = self.packet_loss_percent

        def avg(field):
            return self._val(
                ((getattr(self, field) * curr_count) + getattr(other, field)) /
                (curr_count+1)
            )

        self.__count += 1
        self.packet_transmitted += other.packet_transmitted
        self.packet_loss_percent = avg('packet_loss_percent')

        # round-trip stats are valid only when at-least one packet was sent
        if curr_loss_percent == 100 and other.packet_loss_percent == 100:
            return self

        if curr_loss_percent == 100:
            self.round_trip_min = other.round_trip_min
            self.round_trip_avg = other.round_trip_avg
            self.round_trip_max = other.round_trip_max
            self.round_trip_stddev = other.round_trip_stddev
            return self

        if other.packet_loss_percent == 100:
            return self

        self.round_trip_min = min(self.round_trip_min, other.round_trip_min)
        self.round_trip_avg = avg('round_trip_avg')
        self.round_trip_max = max(self.round_trip_max, other.round_trip_max)
        # TODO(Mahi): find the procedure to compute stddev for overall stats
        self.round_trip_stddev = 0
        return self

    def __eq__(self, other):
        return (
            self.packet_transmitted == other.packet_transmitted and
            self.packet_loss_percent == other.packet_loss_percent and
            self.round_trip_min == other.round_trip_min and
            self.round_trip_avg == other.round_trip_avg and
            self.round_trip_max == other.round_trip_max and
            self.round_trip_stddev == other.round_trip_stddev
        )

    def __ne__(self, other):
        return not self == other

    def __repr__(self):
        return 'pkts=%d, loss=%d, rtmin=%d, rtavg=%d, rtmax=%d, rtstddev=%d' % (
            self.packet_transmitted, self.packet_loss_percent, self.round_trip_min,
            self.round_trip_avg, self.round_trip_max, self.round_trip_stddev)


class PingCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(PingCollector, self).__init__(*args, **kwargs)
        self.processed_input = None
        self.processed_input_source = None

    def format_stats(self, ip_stats, output, prefix=None):
        def key(k):
            return '%s_%s' % (prefix, k) if prefix else k

        def _set(field):
            k = key(field)
            assert k not in output
            output[k] = getattr(ip_stats, field)

        for field in ('packet_transmitted', 'packet_loss_percent', 'round_trip_min',
                      'round_trip_avg', 'round_trip_max', 'round_trip_stddev'):
            _set(field)

    def parse_stats(self, ip, collected_ping):
        ping_data = ping_parser.parse(collected_ping)
        assert ping_data, str(locals())
        return PingStats(*ping_data[0])

    # TODO: (Mahi) this should be replaced with schema validation
    def validate_input(self, json_input):
        # make sure json_input having required fields
        keys = ['targets', 'packet_count_per_target']
        if sorted(keys) != sorted(json_input.keys()):
            raise ValueError('JSON has unexpected keys')

        if not isinstance(json_input['packet_count_per_target'], int):
            raise ValueError('packet_count_per_target must be an integer')

        if not isinstance(json_input['targets'], list):
            raise ValueError('targets must be a list')

        for ip in json_input['targets']:
            if not valid_ipv4_addr(ip):
                raise ValueError('Invalid IPAddress %s' % ip)

    def parse_input(self):
        default_input = {
            'targets': ['8.8.8.8'],
            'packet_count_per_target': DEFAULT_PING_COUNT
        }
        if self.service_config.input:
            try:
                json_input = json.loads(self.service_config.input)
            except ValueError:
                json_input = {
                    'targets': [self.service_config.input],
                    'packet_count_per_target': DEFAULT_PING_COUNT
                }
        else:
            json_input = default_input

        self.validate_input(json_input)
        return json_input

    def collect(self):
        if not self.processed_input_source or (
                self.processed_input_source != self.service_config.input):
            self.processed_input = self.parse_input()
            self.processed_input_source = self.service_config.input

        agg_stats = None
        output = {}
        for ip in self.processed_input['targets']:
            ip_stats = self.parse_stats(
                ip,
                self.device.get_text('ping -c {} {}'.format(
                    self.processed_input['packet_count_per_target'], ip))
            )
            self.format_stats(ip_stats, output, ip)
            if not agg_stats:
                agg_stats = ip_stats
            else:
                agg_stats.aggregate(ip_stats)

        # Also store aggregates across targets - this helps in general as a summary
        # and also aid ingestion into iba without mandating target ip in the key
        if agg_stats:
            self.format_stats(agg_stats, output)
        self.post_data(to_extensible_postdata(output))


def collector_plugin(_device):
    return PingCollector
