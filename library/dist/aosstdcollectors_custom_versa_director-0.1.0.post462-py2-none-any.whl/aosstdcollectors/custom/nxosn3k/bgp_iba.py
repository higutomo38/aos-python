# Copyright 2019-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula


from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
import json


def process(info):
    vrfs = info['TABLE_vrf']['ROW_vrf']
    if not isinstance(vrfs, list):
        vrfs = [vrfs]

    return {
        'items': [
            {
                'identity': '%s_%s' % (vrf['vrf-name-out'], neighbor['neighborid']),
                'value': str(
                    1 if neighbor['state'] == 'Established' else 2
                )
            }

            for vrf in vrfs
            for neighbor in vrf['TABLE_af']['ROW_af'][0]['TABLE_saf'][
                'ROW_saf'][0]['TABLE_neighbor']['ROW_neighbor']
        ]
    }


class BgpIbaCollector(BaseTelemetryCollector):
    def collect(self):
        self.post_data(
            json.dumps(
                process(self.device.get_json(
                    'show bgp ipv4 unicast summary vrf all'))
            )
        )


def collector_plugin(_device):
    return BgpIbaCollector
