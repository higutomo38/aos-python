# Copyright 2019-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

import json
import logging
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.nxosn3k_vrf_util import read_vrfs

LOG = logging.getLogger(__name__)


class PimNeighborCountCollector(BaseTelemetryCollector):
    def get_pim_neighbors_in_vrf(self, vrf):
        pim_intf = self.device.get_json('show ip pim interface vrf ' + vrf)

        if pim_intf is not None:
            return {
                intf['if-name']: intf['nbr-cnt']
                for intf in pim_intf[
                    'TABLE_vrf']['ROW_vrf'][0]['TABLE_iod']['ROW_iod']
            }
        return {}

    def collect(self):
        """
        For all VRFs, collect:
            Identity = { VRF-name }}|{{ interface }}
            Value = Count of PIM neighbors
        """
        vrfs = read_vrfs(self.device)
        self.post_data(json.dumps({
            'items': [
                {
                    'identity': '%s|%s' % (vrf, interface),
                    'value': neighbor_count
                }
                for vrf, vrf_info in vrfs.iteritems()
                if vrf_info['role'] != 'management' and
                vrf_info['multicast_mode'] == 'enabled'
                for interface, neighbor_count in self.get_pim_neighbors_in_vrf(
                    vrf).iteritems()
            ]
        }))


def collector_plugin(_device):
    return PimNeighborCountCollector
