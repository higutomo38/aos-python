# Copyright 2019-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.cisco_util import SFP_METRICS
from aosstdcollectors.utils.data_util import to_extensible_postdata

METRIC_WITHIN_THRESHOLD = 1
METRIC_OUTSIDE_THRESHOLD = 2


class SfpCollector(BaseTelemetryCollector):
    def parse(self, in_json):
        def outside_thresholds(actual, low_thres, high_thres):
            if actual > low_thres and actual < high_thres:
                return METRIC_WITHIN_THRESHOLD
            return METRIC_OUTSIDE_THRESHOLD

        all_rows = {}

        for row in in_json['TABLE_interface']['ROW_interface']:
            if row.get('sfp') == 'not present':
                continue

            iname = row['interface']
            # get the deatils from each individual interface
            sfp_detail = self.device.get_json(
                'show interface %s transceiver detail' % iname)[
                    'TABLE_interface']['ROW_interface'][0]

            all_rows[iname] = dict(
                vendor_sn=row['serialnum'],
                media_type=row['type']
            )

            for info in SFP_METRICS:
                current_value = sfp_detail.get(info.value_field)
                if not current_value:
                    continue
                alarm_hi = sfp_detail.get('%s_alrm_hi' % info.threshold_field_prefix)
                alarm_lo = sfp_detail.get('%s_alrm_lo' % info.threshold_field_prefix)
                warn_hi = sfp_detail.get('%s_warn_hi' % info.threshold_field_prefix)
                warn_lo = sfp_detail.get('%s_warn_lo' % info.threshold_field_prefix)

                all_rows[iname].update({
                    info.output_field: current_value,
                    '%s_low_warn' % info.output_field: sfp_detail.get(
                        '%s_warn_lo' % info.threshold_field_prefix),
                    '%s_high_warn' % info.output_field: sfp_detail.get(
                        '%s_warn_hi' % info.threshold_field_prefix),
                    '%s_low_alarm' % info.output_field: sfp_detail.get(
                        '%s_alrm_lo' % info.threshold_field_prefix),
                    '%s_high_alarm' % info.output_field: sfp_detail.get(
                        '%s_alrm_hi' % info.threshold_field_prefix),
                    '%s_has_warn' % info.output_field: outside_thresholds(
                        float(current_value), float(warn_lo), float(warn_hi)),
                    '%s_has_alarm' % info.output_field: outside_thresholds(
                        float(current_value), float(alarm_lo), float(alarm_hi))
                })

        return {
            '{}|{}'.format(ident, k): value
            for ident in all_rows
            for k, value in all_rows[ident].iteritems()
        }

    def collect(self):
        self.post_data(to_extensible_postdata(self.parse(self.device.get_json(
            'show interface transceiver detail'))))


def collector_plugin(device):
    return SfpCollector
