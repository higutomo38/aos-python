# Copyright 2019-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula


import json
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector


class RouteCountCollector(BaseTelemetryCollector):
    """
    Returns number of default routes for all networks contextualized by VRFs.
    """

    def parse(self, in_json):
        vrfs = in_json['TABLE_vrf']['ROW_vrf']
        networks = self.service_config.input.split(
            ',') if self.service_config.input else ['0.0.0.0/0']
        result = {}
        for vrf in vrfs:
            vrf_name = vrf["vrf-name-out"]
            entries = vrf['TABLE_addrf'][
                'ROW_addrf'][0][
                    'TABLE_prefix'][
                        'ROW_prefix']
            for entry in entries:
                prefix = entry['ipprefix']
                count = entry['ucast-nhops']
                if prefix in networks:
                    prefix_key = '{}|{}'.format(vrf_name, prefix)
                    result[prefix_key] = count
        return result

    def collect(self):
        self.post_data(json.dumps({
            'items': [
                {
                    'identity': key,
                    'value': value
                }
                for key, value in self.parse(
                    self.device.get_json('show ip route vrf all')
                ).iteritems()
            ]
        }))


def collector_plugin(_device):
    return RouteCountCollector
