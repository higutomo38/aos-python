# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula


from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.data_util import to_extensible_postdata
from aosdevicedrivers.compat.aos.sdk.system_agent.device import DeviceError
import logging

LOG = logging.getLogger(__name__)


class MlagDomainCollector(BaseTelemetryCollector):
    def collect(self):
        try:
            self.device.get_json('show vpc')
        except DeviceError:
            LOG.warn('vpc feature not enabled')
            self.post_data(
                to_extensible_postdata({
                    'domain_id': None,
                    'system_id': None,
                    'domain_state': None,
                    'local_interface': None,
                    'local_interface_status': None,
                    'local_interface_vlan_id': None,
                    'peer_link': None,
                    'peer_link_status': None,
                    'peer_address': None,
                    'config_sanity': None,
                })
            )
            return

        self.post_data(to_extensible_postdata({
            # TODO (mhutt) need to poplulate the rest of the fields once
            # we get vpc test data from a nexus 3k
            'domain_id': None,
            'system_id': None,
            'domain_state': None,
            'local_interface': None,
            'local_interface_status': None,
            'local_interface_vlan_id': None,
            'peer_link': None,
            'peer_link_status': None,
            'peer_address': None,
            'config_sanity': None
        }))


def collector_plugin(_device):
    return MlagDomainCollector
