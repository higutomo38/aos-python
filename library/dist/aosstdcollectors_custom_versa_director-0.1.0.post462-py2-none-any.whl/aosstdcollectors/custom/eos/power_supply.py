# Copyright 2019-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

import json
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.compat.aos.sdk.system_agent.device import \
    get_running_aos_version
from aosstdcollectors.utils.data_util import to_extensible_postdata


class PowerSupplyCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(PowerSupplyCollector, self).__init__(*args, **kwargs)
        self.aos_version = get_running_aos_version()

    def _get_power_supply_status(self, ps_data):
        for data in ps_data.itervalues():
            if data.get('state') != 'ok':
                return 2
        return 1

    def _get_fan_status(self, ps_data):
        for data in ps_data.itervalues():
            for fan_data in data.get('fans').itervalues():
                if fan_data.get('status') != 'ok':
                    return 2
        return 1

    def _get_temperature_status(self, ps_data):
        for data in ps_data.itervalues():
            for temp_data in data.get('tempSensors').itervalues():
                if temp_data.get('status') != 'ok':
                    return 2
        return 1

    def _get_airflow_direction(self, model):
        if model.endswith('RED'):
            return 'R'
        if model.endswith('BLUE'):
            return 'F'

        return model[-1]

    def _get_ps_info(self, data):
        return {
            ps_id: {
                'ps_status': ps_data.get('state'),
                'input_power': ps_data.get('inputPower'),
                'output_power': ps_data.get('outputPower'),
                'uptime': ps_data.get('uptime', 0),
                'airflow': self._get_airflow_direction(ps_data.get('modelName')),
                'model_number': ps_data.get('modelName'),
                'odm_manufacturer': ps_data.get('mfrId'),
                'temp_sensors': ps_data.get('tempSensors'),
                'fan_status': ps_data.get('fans')
            }
            for ps_id, ps_data in data.iteritems()
        }

    def process_show_env(self, ps_data):
        # Publishing summary values since IBA cannot ingest telemetry
        # from unknown keys, and we don't have power-supply related info
        # available in the blueprint.
        return {
            'power_supply_status': self._get_power_supply_status(ps_data),
            'power_supply_fan_status': self._get_fan_status(ps_data),
            'power_supply_temperature_status': self._get_temperature_status(ps_data),
            'power_supply_info': json.dumps(
                self._get_ps_info(ps_data), indent=2, sort_keys=True),
            # This field represents count of PSUs installed on the box. Arista's
            # output only includes installed PSUs, so just length gives what we need.
            'power_supply_count': len(ps_data)
        }

    def collect(self):
        show_env = self.device.get_json(
            'show environment power detail')['powerSupplies']
        self.post_data(to_extensible_postdata(
            self.process_show_env(show_env)
        ))


def collector_plugin(_device):
    return PowerSupplyCollector
