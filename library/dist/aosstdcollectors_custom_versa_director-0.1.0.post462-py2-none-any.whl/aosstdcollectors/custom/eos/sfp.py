# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula


import json
from collections import defaultdict
from aosstdcollectors.utils.textparsing import TextFsmParser
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector


def parse_buffer_text(collected):
    if collected is None:
        return None
    # This template extracts 'Interface name', 'MediaType' and 'Wavelength' values
    # from the text output of EOS command: show interfaces transceiver hardware
    # And format the data in a table as in the following example:
    #
    # Name: Et49/1
    # Media Type: 40GBASE-UNIV
    # Wavelength (nm): 1310.0
    # Name: Et49/2
    # Media Type: 40GBASE-UNIV
    # Wavelength (nm): 1310.0

    template = r''' #TextFSM
Value Filldown Interface (\S+)
Value MediaType (\S+)
Value Wavelength (\d+(.\d+)?)

Start
  ^\s*Name:\s+${Interface}
  ^\s*Media Type:\s+${MediaType} -> Record
  ^\s*Wavelength \(nm\):\s+${Wavelength} -> Record

EOF
'''

    def normalize_interface_name(intf_name):
        '''
        EOS interface command text output nomally contains simplified interface
        names such as Et42/1, however, the command json output uses complete name.
        This method normalize the interface names and make sure the name is
        complete version.
        :param intf_name:
        :return:
        '''
        if 'Ethernet' in intf_name:
            return intf_name
        return intf_name.replace('Et', 'Ethernet')

    buffer_parser = TextFsmParser(template)
    parsed_data = buffer_parser.parse(collected)
    print parsed_data
    data = defaultdict(dict)
    for intf_name, media_type, wavelength in parsed_data:
        nor_intf_name = normalize_interface_name(intf_name)
        if media_type != '':
            data[nor_intf_name]['mediaType'] = media_type
        if wavelength != '':
            data[nor_intf_name]['wavelength'] = float(wavelength)
    return data


def process(transceiver_hardware, transceiver_detail):
    transceiver_hardware_data = parse_buffer_text(transceiver_hardware)
    transceiver_detail_data = transceiver_detail['interfaces']
    field_to_key = {
        'txPower': 'tx_power',
        'rxPower': 'rx_power',
        'temperature': 'temperature',
        'txBias': 'tx_bias',
        'voltage': 'voltage'
    }

    def get_hardware_value(field, intf_name):
        if intf_name not in transceiver_hardware_data:
            return None
        if field not in transceiver_hardware_data[intf_name]:
            return None
        return str(transceiver_hardware_data[intf_name][field])

    def outside_thresholds(actual, low_thres, high_thres):
        if actual > low_thres and actual < high_thres:
            return '1'
        return '2'

    def get_vendor_sn(intf_name):
        if intf_name not in transceiver_detail_data:
            return None
        if 'vendorSn' not in transceiver_detail_data[intf_name]:
            return None
        return transceiver_detail_data[intf_name]['vendorSn']

    def get_detail_value(intf_name, field):
        sfp_key = field_to_key[field]
        if intf_name in transceiver_detail_data and \
                field in transceiver_detail_data[intf_name]:
            return {
                '%s|%s' % (intf_name, sfp_key): repr(
                    transceiver_detail_data[intf_name][field]),
                '%s|%s_low_warn' % (intf_name, sfp_key): repr(
                    transceiver_detail_data[intf_name]['details'][field]['lowWarn']),
                '%s|%s_high_warn' % (intf_name, sfp_key): repr(
                    transceiver_detail_data[intf_name]['details'][field][
                        'highWarn']),
                '%s|%s_low_alarm' % (intf_name, sfp_key): repr(
                    transceiver_detail_data[intf_name]['details'][field][
                        'lowAlarm']),
                '%s|%s_high_alarm' % (intf_name, sfp_key): repr(
                    transceiver_detail_data[intf_name]['details'][field][
                        'highAlarm']),
                '%s|%s_has_warn' % (intf_name, sfp_key): outside_thresholds(
                    transceiver_detail_data[intf_name][field],
                    transceiver_detail_data[intf_name]['details'][field]['lowWarn'],
                    transceiver_detail_data[intf_name]['details'][field][
                        'highWarn']),
                '%s|%s_has_alarm' % (intf_name, sfp_key): outside_thresholds(
                    transceiver_detail_data[intf_name][field],
                    transceiver_detail_data[intf_name]['details'][field]['lowAlarm'],
                    transceiver_detail_data[intf_name]['details'][field][
                        'highAlarm'])
            }
        return {
            '%s|%s' % (intf_name, sfp_key): None,
            '%s|%s_low_warn' % (intf_name, sfp_key): None,
            '%s|%s_high_warn' % (intf_name, sfp_key): None,
            '%s|%s_low_alarm' % (intf_name, sfp_key): None,
            '%s|%s_high_alarm' % (intf_name, sfp_key): None,
            '%s|%s_has_warn' % (intf_name, sfp_key): None,
            '%s|%s_has_alarm' % (intf_name, sfp_key): None
        }

    def data(intf_name):
        intf_sfp_data = {
            '%s|wave_length' % intf_name: get_hardware_value('wavelength',
                                                             intf_name),
            '%s|media_type' % intf_name: get_hardware_value('mediaType', intf_name),
            '%s|vendor_sn' % intf_name: get_vendor_sn(intf_name)
        }

        for field in field_to_key:
            intf_sfp_data.update(
                get_detail_value(intf_name, field))

        return intf_sfp_data

    return {
        'items': [
            {
                'identity': key,
                'value': value
            }
            for intf_name in transceiver_detail_data
            for key, value in data(intf_name).iteritems()
        ]
    }


class SfpCollector(BaseTelemetryCollector):
    """
    Collect:
        Identity: each element is in the format of '<interface>|<metric>'
            where interface is interface name
            and metric is one of tx_power, rx_power, temperature, tx_bias, voltage.

            And for each interface, metric pair, there are 6 accompanying metrics
            whose identities are of the form '<interface>|<metric>_<sub-metric>'
            where 'sub-metric' is one of low_warn.
        Value:
            - rx_power/tx_power/tx_bias: string '-8.342569585789557' etc.
            - *_low_warn/*_high_warn/*_low_alarm/*_high_alrm: string
            - temperature: '31' Fahrenheit etc.
            - wave_length: '850.0' nm etc.
            - media_type: '10GBASE-CR' etc.
            - voltage: '3.3' volt
            - *_has_warn/*_has_alarm: '2' if outside thresholds, otherwise '1'
    """

    def collect(self):
        self.post_data(
            json.dumps(
                # Not using get_json as this is an unconverted command in EOS 4.17
                process(self.device.get_text('show interfaces transceiver hardware'),
                        self.device.get_json('show interfaces transceiver detail'))
            )
        )


def collector_plugin(_device):
    return SfpCollector
