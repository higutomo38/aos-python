# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

import json
import logging
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.compat.aos.sdk.system_agent.device import \
    get_running_aos_version
from aosstdcollectors.utils.data_util import format_generic_value

LOG = logging.getLogger(__name__)

# vEOS may have unknown bandwidth for an interface, this value would be used as
# default
DEFAULT_BANDWIDTH_MB = 10000


def to_mb(b):
    return b / 1000000


def bandwidth(iface):
    if iface['bandwidth'] == 0:
        return DEFAULT_BANDWIDTH_MB
    return to_mb(iface['bandwidth'])


def primary_ip(iface):
    if iface['hardware'] == 'vxlan':
        return '/'.join([iface['srcIpAddr'], '32'])
    if not iface['interfaceAddress'] \
       or iface['interfaceAddress'][0]['primaryIp']['address'] == '0.0.0.0':
        return None
    ip = iface['interfaceAddress'][0]['primaryIp']
    return '/'.join([ip['address'], str(ip['maskLen'])])


def type_of(iface):
    """
    Possible interface types:

     - ip (L3)
     - ethernet (L2)
     - loopback
     - svi
     - port_channel
     - vxlan

    :param iface: interface dict from 'show interface <iface> | json'
    :return:
    """
    if iface['hardware'] == 'ethernet':
        if iface['forwardingModel'] == 'routed':
            return 'ip'
        if iface['forwardingModel'] in ['dataLink', 'bridged', 'quietDataLink']:
            return 'ethernet'
    type_of_value = {
        'loopback': 'loopback',
        'vlan': 'svi',
        'portChannel': 'port_channel',
        'subinterface': 'subinterface',
    }.get(iface['hardware'])
    if type_of_value:
        return type_of_value
    if iface['name'].startswith('Management'):
        return 'management'
    if iface['hardware'] == 'vxlan':
        return 'vxlan'

    LOG.warn('Could not determine interface type for: %s', iface)
    return None


def intf_name(iface):
    # doing this lowering to match behavior of builtin collectors lag and interface
    # for eos
    return iface['name'].lower() \
        if iface['hardware'] == 'portChannel' else iface['name']


def get_parent(iface, iface_dict):
    """
    There are 2 cases:

    1. sub-interfaces.

    Example:
        Ethernet1 (type - ethernet)
        Ethernet1.400 (type - subinterface)
    get_parent(Ethernet1.400) returns 'Ethernet1'.

    2. Port channels.

    Example:
        Port-Channel1:
            type - portChannel
            memberInterfaces: [Ethernet1, Ethernet2]
    get_parent(Ethernet1) returns 'Port-Channel1'
    get_parent(Ethernet2) returns 'Port-Channel1'

    :returns: None if :iface: has no parent
    """
    if iface['hardware'] == 'subinterface':
        parent = iface['name'].split('.')[0]
        assert parent in iface_dict, iface
        return parent

    if iface['hardware'] == 'ethernet':
        for parent in iface_dict.itervalues():
            if parent['hardware'] == 'portChannel' and \
                    iface['name'] in parent['memberInterfaces']:
                return intf_name(parent)

    return None


def get_subinterface_id(iface, parent):
    if iface['hardware'] != 'subinterface':
        return None

    # for Ethernet1.100, return 100
    assert parent, iface
    return iface['name'][len(parent) + 1:]


def get_mode(show_interfaces_trunk, iface_name):
    return show_interfaces_trunk.get(iface_name, {}).get('portMode', 'trunk')


def get_mlag_id(iface, mlag_ifaces):
    for mlag_id in mlag_ifaces:
        if iface['name'] == mlag_ifaces[mlag_id]['localInterface']:
            return int(mlag_id)

    return None


def first(l):
    return next(iter(l or []), None)


def get_virtual_ips(show_ip_vr, iface):
    def _ipv4_netaddr(address, mask):
        return '/'.join([address, str(mask)])

    vxlan_vip = []

    if iface['interfaceAddress'] \
       and iface['interfaceAddress'][0]['virtualIp']['address'] != '0.0.0.0':
        # interface was configured with ip address virtual for vxlan
        ip = iface['interfaceAddress'][0]['virtualIp']
        vxlan_vip = [_ipv4_netaddr(ip['address'], ip['maskLen'])]

    vips = show_ip_vr['virtualRouters']
    # Different versions of EOS may have different output formats:
    # 1. "virtualIps": [{
    #      "ip": <ip>,
    #      "mask": <mask>
    #    }]
    # 2. "virtualIps": [<ip>]
    # in both cases use the ipAddress mask
    return [
        _ipv4_netaddr(v['ip'], vip['ipAddress']['mask'])
        if 'ip' in v
        else _ipv4_netaddr(v, vip['ipAddress']['mask'])
        for vip in vips
        if vip['interface'] == iface['name']
        for v in vip['virtualIps']
    ] + vxlan_vip


def get_allowed_vlans(trunk_interfaces_iface):
    # merge active and allowed vlan IDs
    all_vlans_allowed = trunk_interfaces_iface.get('allowedVlans', {}).get(
        'allVlans', False)
    active_vlans = trunk_interfaces_iface.get('activeVlans', {}).get('vlanIds', [])
    allowed_vlans = trunk_interfaces_iface.get('allowedVlans', {}).get('vlanIds', [])

    return active_vlans if all_vlans_allowed else \
        list(set(active_vlans) & set(allowed_vlans))


def get_vlan_id(iface):
    if iface['hardware'] == 'vlan':
        return int(iface['name'].lstrip('Vlan'))
    return None


def virtual_macs(show_ip_vr):
    if 'virtualMac' in show_ip_vr:
        return [show_ip_vr['virtualMac']]
    return [mac['macAddress'] for mac in show_ip_vr['virtualMacs']]


def get_native_vlan(ifaces_trunk, port_ifaces, ifname):
    native_vlan = ifaces_trunk.get(ifname, {}).get('nativeVlan')
    if native_vlan is not None:
        return native_vlan

    return port_ifaces.get(ifname, {}).get('switchportInfo', {}).get('accessVlanId')


class InterfaceDetailsCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(InterfaceDetailsCollector, self).__init__(*args, **kwargs)
        self.aos_version = get_running_aos_version()

    def parse_interface_details(self, ifaces_trunk, ifaces,
                                show_ip_vr, mlag_ifaces, port_ifaces):
        def build(iface):
            parent = get_parent(iface, ifaces)
            return {
                'name': intf_name(iface),
                'allowed_vlans': get_allowed_vlans(ifaces_trunk.get(iface['name'],
                                                                    {})),
                'description': iface['description'],
                'speed_mbps': bandwidth(iface),
                'ipv4_addr': primary_ip(iface),
                'type': type_of(iface),
                'parent': parent,
                'native_vlan': get_native_vlan(
                    ifaces_trunk, port_ifaces, iface['name']),
                'mlag_id': get_mlag_id(iface, mlag_ifaces),
                'subinterface_id': get_subinterface_id(iface, parent),
                'mode': get_mode(ifaces_trunk, iface['name']),
                'virtual_ips': get_virtual_ips(show_ip_vr, iface),
                'virtual_macs': virtual_macs(show_ip_vr),
                'vlan_id': get_vlan_id(iface)
            }

        return [
            {
                'identity': intf_name(iface),
                'value': format_generic_value(self.aos_version, build(iface))
            }
            for iface in ifaces.itervalues()
        ]

    def collect(self):
        ifaces = self.device.get_json('show interfaces')['interfaces']
        show_ip_vr = self.device.get_json('show ip virtual-router vrf all')
        ifaces_trunk = self.device.get_json('show interfaces trunk')['trunks']
        mlag_ifaces = self.device.get_json('show mlag interfaces')['interfaces']
        port_ifaces = self.device.get_json(
            'show interfaces switchport')['switchports']

        details = self.parse_interface_details(ifaces_trunk, ifaces, show_ip_vr,
                                               mlag_ifaces, port_ifaces)

        self.post_data(json.dumps({'items': details}))


def collector_plugin(_device):
    return InterfaceDetailsCollector
