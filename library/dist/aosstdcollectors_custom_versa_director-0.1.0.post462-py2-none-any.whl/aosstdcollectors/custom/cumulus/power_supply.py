# Copyright 2019-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

import json
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.compat.aos.sdk.system_agent.device import \
    get_running_aos_version
from aosstdcollectors.utils.data_util import to_extensible_postdata

MISSING_DATA = 0
OK_STATUS = 1
FAULT_STATUS = 2


class PowerSupplyCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(PowerSupplyCollector, self).__init__(*args, **kwargs)
        self.aos_version = get_running_aos_version()

    def _get_power_supply_stats(self, ps_data, ps_data_type):
        # fans with a state of ABSENT will not be seen here
        found_stats = False
        for data in ps_data:
            if data.get('type') == ps_data_type:
                found_stats = True
                if data.get('state') != 'OK':
                    return FAULT_STATUS
        return OK_STATUS if found_stats else MISSING_DATA

    def _get_ps_info(self, data):
        return {
            ps_data.get('name'): {
                'ps_status': ps_data.get('state'),
                'uptime': ps_data.get('start_time', 0),
            }
            for ps_data in data
            if ps_data.get('type') == 'power'
        }

    def _get_ps_count(self, data):
        ps_count = 0
        for ps in data:
            if ps.get('type') == 'power' and ps.get('state') != 'ABSENT':
                ps_count += 1
        return ps_count

    def _extract_ps_data(self, sensor_data):
        # collect just the power supply sensor data
        return [
            ps_data
            for ps_data in sensor_data
            if ps_data.get('name').startswith('PSU') and
            ps_data.get('state') != 'ABSENT'
        ]

    def process_sensor_data(self, sensor_data):
        # Publishing summary values since IBA cannot ingest telemetry
        # from unknown keys, and we don't have power-supply related info
        # available in the blueprint.
        ps_data = self._extract_ps_data(sensor_data)
        return {
            'power_supply_status': self._get_power_supply_stats(ps_data, 'power'),
            'power_supply_fan_status': self._get_power_supply_stats(ps_data, 'fan'),
            'power_supply_temperature_status': self._get_power_supply_stats(
                ps_data, 'temp'),
            'power_supply_info': json.dumps(
                self._get_ps_info(ps_data), indent=2, sort_keys=True),
            'power_supply_count': self._get_ps_count(ps_data)
        }

    def collect(self):
        sensor_data = self.device.get_json('sudo smonctl -j')
        self.post_data(to_extensible_postdata(
            self.process_sensor_data(sensor_data)
        ))


def collector_plugin(_device):
    return PowerSupplyCollector
