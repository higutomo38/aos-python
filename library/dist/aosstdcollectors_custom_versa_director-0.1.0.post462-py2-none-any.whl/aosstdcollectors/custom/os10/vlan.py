# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula
import json
import operator
from lxml import etree
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.compat.aos.sdk.system_agent.device import \
    get_running_aos_version
from aosstdcollectors.utils.data_util import format_generic_value
from aosstdcollectors.utils.os10_util import parse, parse_multiple_xmls, parse_list,\
    extract_vlan_id_from_name


class VlanCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(VlanCollector, self).__init__(*args, **kwargs)
        self.aos_version = get_running_aos_version()

    def process_show_vlans(self, vlan_entries):
        def build(vlan_intf):
            vlan_name = parse(vlan_intf, './name')
            return {
                'vlan_id': extract_vlan_id_from_name(vlan_name),
                'name': vlan_name,
                'interfaces': sorted(
                    operator.add(parse_list(vlan_intf, './untagged-ports'),
                                 parse_list(vlan_intf, './tagged-ports'))),
            }

        return [
            {
                'identity': str(extract_vlan_id_from_name(parse(intf, './name'))),
                'value': format_generic_value(self.aos_version, build(intf))
            }
            for vlan_entry in vlan_entries
            for intf in vlan_entry.findall('./bulk/data/interface')
        ]

    def collect(self):
        vlan_xmls = parse_multiple_xmls(
            self.device.get_text('show vlan | display-xml'))
        vlan_entries = (etree.fromstring(vlan_xml.encode('utf8')) for
                        vlan_xml in vlan_xmls)
        self.post_data(json.dumps({
            'items': self.process_show_vlans(vlan_entries)
        }))


def collector_plugin(_device):
    return VlanCollector
