# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

import base64
from lxml import etree
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.data_util import to_extensible_postdata
from aosstdcollectors.utils.os10_util import parse, is_management_interface, \
    parse_multiple_xmls, decode_mac_address
from aosstdcollectors.compat.aos.sdk.system_agent.device import \
    get_running_aos_version


class LldpDetailsCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(LldpDetailsCollector, self).__init__(*args, **kwargs)
        self.aos_version = get_running_aos_version()

    def most_recent_lldp(self, interface):
        return max(interface.findall('./lldp-rem-neighbor-info/info'),
                   key=lambda info: int(parse(info, './rem-last-update-time')))

    def parse_interface_lldp(self, intf_name, lldp_info):
        def parse_not_advertised(value):
            if value == 'Not Advertised':
                return ''
            return value

        neighbor_interface_type = parse(lldp_info, './rem-lldp-port-subtype')
        neighbor_interface_name = parse(lldp_info, './rem-lldp-port-id')
        if neighbor_interface_type == 'mac-address':
            neighbor_interface_name = decode_mac_address(neighbor_interface_name)
        elif neighbor_interface_type == 'interface-name':
            neighbor_interface_name = base64.b64decode(neighbor_interface_name)

        def get_chassis_id(_lldp_info, _chassis_id_type):
            chassis_id = parse(_lldp_info, './rem-lldp-chassis-id')
            if _chassis_id_type == 'mac-address':
                chassis_id = decode_mac_address(chassis_id)

            return chassis_id

        chassis_id_type = parse(lldp_info, './rem-lldp-chassis-id-subtype')

        return {
            'interface_name': intf_name,
            'neighbor_interface_name': neighbor_interface_name,
            'neighbor_system_id': parse_not_advertised(
                parse(lldp_info, './rem-system-name')),
            'sys_description': parse_not_advertised(
                parse(lldp_info, './rem-system-desc')),
            'chassis_id': get_chassis_id(lldp_info, chassis_id_type),
            'chassis_id_type': chassis_id_type,
        }

    def parse_lldp(self, interfaces):
        return [
            self.parse_interface_lldp(parse(interface, 'name'),
                                      self.most_recent_lldp(interface))
            for interface in interfaces.findall('./bulk/data/interface')
            if interface.find(
                './lldp-rem-neighbor-info/info/rem-system-name') is not None and
            not is_management_interface(parse(interface, 'type'))
        ]

    def populate_lldp(self):
        data_xmls = parse_multiple_xmls(
            self.device.get_text('show lldp neighbors | display-xml'))
        return [
            lldp_entry
            for lldp_entries in data_xmls
            for lldp_entry in
            self.parse_lldp(etree.fromstring(lldp_entries.encode('utf8')))
        ]

    def collect(self):
        items = {
            lldp['interface_name']: lldp
            for lldp in self.populate_lldp()
        }
        self.post_data(to_extensible_postdata(items, aos_version=self.aos_version))


def collector_plugin(_):
    return LldpDetailsCollector
