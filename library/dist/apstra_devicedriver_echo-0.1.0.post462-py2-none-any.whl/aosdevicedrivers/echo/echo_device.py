# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

import re
from random import randint

from aos.sdk.system_agent.device import Device

__all__ = ['EchoDevice']


DEFAULT_VALUE = 'configure-me-in-open-options'


def string_to_os_version(version_string):
    """Convert string to os version tac type"""
    match = re.split(r'\.', version_string, 2)
    return {
        'major': match[0] if match else '',
        'minor': match[1] if len(match) > 1 else '',
        'build': match[2] if len(match) > 2 else '',
    }


DEFAULT_FACTS = {
    'chassis_mac_ranges': '',
    'os_arch': 'x86_64',
    'serial_number': DEFAULT_VALUE,
    'hw_model': DEFAULT_VALUE,
    'hw_version': DEFAULT_VALUE,
    'mgmt_macaddr': '52:54:00:%02x:%02x:%02x' % (
        randint(0, 255), randint(0, 255), randint(0, 255)),
    'mgmt_ifname': DEFAULT_VALUE,
    'mgmt_ipaddr': DEFAULT_VALUE,
    'os_version': DEFAULT_VALUE,
    'os_family': DEFAULT_VALUE,
    'vendor': DEFAULT_VALUE,
}


class EchoDevice(Device):
    def open(self):
        pass

    def get_device_info(self):
        facts = dict(
            DEFAULT_FACTS,
            **{
                k[len('facts_'):]: v
                for k, v in (self.open_options or {}).iteritems()
                if k.startswith('facts_')
            }
        )
        facts['os_version_info'] = string_to_os_version(facts['os_version'])
        return facts

    def probe(self):
        pass

    def close(self):
        pass
