# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula


import json


def table_to_dict(hdrs, table, key_index=0):
    """
    This function takes a table of data (list[list]) and
    converts it into a dictionary.  They dictionary value
    key names are taken from the :attr:`hrds`.  They
    specific column that will be the dictionary key is
    the :attr:`key_index` value.  For example, if the
    data in the first column should be the key value,
    then key_index=0.

    Parameters
    ----------
    hdrs: list
        The table column headers.

    table: list[list]
        The table data arranged as a list of lists.  Each
        inner list is the row of data

    key_index: int
        Identifies which row column value will be used as
        the dictionary key value.

    Returns
    -------
    dict:
        The table in dictionary form.
    """
    as_dict = dict()

    for row in table:
        key = row[key_index]
        as_dict[key] = dict()

        for i, field in enumerate(hdrs):
            if i == key_index:
                continue
            as_dict[key][field] = row[i]

    return as_dict


def dict_to_generic_postdata(collected_dict):
    """
    This function transforms the given postdata dictionary
    into the JSON string required by the AOS framework for
    storing this content into the AOS server

    Parameters
    ----------
    collected_dict: dict
        The dictionary of data that the User wants to store
        in the AOS server

    Returns
    -------
    str
        The JSON-string version of the data structured in the
        way required by the AOS framework
    """
    postdata = list()

    def _to_native(_v):
        return _v if isinstance(_v, str) else json.dumps(_v)

    for key, value in collected_dict.items():
        postdata.append(dict(
            identity=key,
            value=_to_native(value)
        ))

    return json.dumps(dict(items=postdata))


def filter_dict_items(data_dict, key=None, value=None):
    if not any((key, value)):
        raise RuntimeError("missing either key or value")

    if key and value:
        def item_check(k, v):
            return key(k) and value(v)
    elif key:
        def item_check(k, v):
            return key(k)
    else:
        def item_check(k, v):
            return value(v)

    return {
        _k: _v
        for _k, _v in data_dict.items()
        if item_check(_k, _v)
    }


def format_repr(obj, attrs=None):
    """Default implementation of __repr__ that prints given object attributes"""
    name = obj.__class__.__name__
    attr_desc = ', '.join(['%s=%s' % (attr, repr(value))
                           for attr in (attrs or [])
                           for value in [getattr(obj, attr)]
                           if value is not None])

    return '%s(%s)' % (name, attr_desc)


def normalize_json_rows(json_struct):
    # make sure all ROW elements
    # contain lists
    if isinstance(json_struct, dict):
        for k, v in json_struct.iteritems():
            if isinstance(v, dict):
                if k.startswith('ROW'):
                    json_struct[k] = [v]
                normalize_json_rows(v)
            elif isinstance(v, (list, tuple)):
                for i in v:
                    normalize_json_rows(i)
    elif isinstance(json_struct, (list, tuple)):
        for i in json_struct:
            normalize_json_rows(i)
    return json_struct


def dictmixin_to_dict(collection):
    ''' Convert dictmixin to normal dict
    '''
    if isinstance(collection, dict):
        return collection

    return {key: val for key, val in collection.iteritems()}
