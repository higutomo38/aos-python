# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula


from netmiko import ConnectHandler
import logging
from aos.sdk.system_agent.device import Device
from aosdevicedrivers.compat.aos.sdk.system_agent.device import DeviceNetworkError
from .os10_facts import get_os_info, get_mgmt_info, get_hw_info

LOGGER = logging.getLogger(__name__)


class Os10Device(Device):
    def __init__(self, *args, **kwargs):
        super(Os10Device, self).__init__(*args, **kwargs)
        assert not self.onbox, 'OS10 supported only with offbox'
        self.os10_device = None

    def open(self):
        self.os10_device = ConnectHandler(
            device_type='dell_os10',
            ip=self.ip_address,
            username=self.username,
            password=self.password,
            global_delay_factor=5,
        )

    def close(self):
        self.os10_device.disconnect()

    def probe(self):
        LOGGER.debug('probe - checking connection is live')

        if not self.os10_device.is_alive():
            raise DeviceNetworkError('Device network error')

    def get_text(self, command):
        # refresh prompt due to bug https://github.com/ktbyers/netmiko/issues/1157
        self.os10_device.set_base_prompt()
        return self.os10_device.send_command(command, auto_find_prompt=False)

    def get_device_info(self):
        try:
            ver, build = get_os_info(self)
            assert ver and build, locals()
            ver_splits = build.split('.')
            assert len(ver_splits) >= 3, locals()
            mgmt_ifname, mgmt_macaddr = get_mgmt_info(self)
            hw_info = get_hw_info(self)
        except Exception:  # pylint: disable=broad-except
            LOGGER.exception('device_info exception')
            self.os10_device.disconnect()
        return {
            'chassis_mac_ranges': '',
            'os_family': 'OS10',
            'os_version': ver,
            'os_version_info': {
                'major': '.'.join(ver_splits[0:2]),
                'minor': '.'.join(ver_splits[2:-1]),
                'build': ver_splits[-1]
            },
            'mgmt_ipaddr': self.ip_address,
            'mgmt_ifname': mgmt_ifname,
            'mgmt_macaddr': mgmt_macaddr,
            'os_arch': hw_info['os_arch'],
            'vendor': hw_info['vendor'],
            'hw_model': hw_info['hw_model'],
            'hw_version': hw_info['hw_version'],
            'serial_number': hw_info['serial_number']
        }
