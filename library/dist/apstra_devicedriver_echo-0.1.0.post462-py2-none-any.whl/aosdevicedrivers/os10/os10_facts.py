# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

from lxml import etree


def _parse(path, data):
    parsed_data = data.find(path)
    if parsed_data is not None:
        return parsed_data.text
    return None


def get_os_info(device):
    show_version_data = device.get_text('show version | display-xml')
    xml_data = etree.fromstring(show_version_data.encode('utf8'))
    return _parse('./data/system-sw-state/sw-version/sw-version', xml_data), _parse(
        './data/system-sw-state/sw-version/sw-build-version', xml_data)


def get_mgmt_info(device):
    show_intf_mgmt_data = device.get_text(
        'show interface mgmt | display-xml')
    xml_data = etree.fromstring(show_intf_mgmt_data.encode('utf8'))
    return _parse('./data/interfaces-state/interface/name', xml_data), _parse(
        './data/interfaces-state/interface/current-phys-address', xml_data)


def get_hw_info(device):
    show_version_data = device.get_text('show version | display-xml')
    version_xml_data = etree.fromstring(show_version_data.encode('utf8'))
    show_system_data = device.get_text('show system | display-xml')
    system_xml_data = etree.fromstring(show_system_data.encode('utf8'))
    return {
        'os_arch': _parse('./data/system-sw-state/sw-version/cpu-arch',
                          version_xml_data),
        'vendor': _parse('./data/system/node/mfg-info/vendor-name', system_xml_data),
        'hw_model': _parse('./data/system/node/mfg-info/product-name',
                           system_xml_data),
        'hw_version': _parse('./data/system/node/mfg-info/hw-version',
                             system_xml_data) or '',
        'serial_number': _parse('./data/system/node/mfg-info/ppid', system_xml_data)
    }
