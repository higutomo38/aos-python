# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula


def build_mac(mac_dict_from_sysdb):
    return ':'.join(
        '%02x' % mac_dict_from_sysdb[k]
        for k in sorted(mac_dict_from_sysdb)
    )


def get_none_for_empty_string(data):
    return None if data == '' else data
