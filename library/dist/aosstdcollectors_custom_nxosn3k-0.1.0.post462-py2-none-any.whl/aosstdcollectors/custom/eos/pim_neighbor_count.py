# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula


"""
Collector to check the count of PIM neighbors on each device
"""

import json
import logging
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.eos_util import try_get_json
from aosstdcollectors.utils.eos_vrf_util import read_vrfs

LOG = logging.getLogger(__name__)


class PimNeighborCountCollector(BaseTelemetryCollector):
    """
    For a specific VRF, show the list of PIM neighbors.
    """

    def get_pim_neighbors_in_vrf(self, vrf):
        return try_get_json(self.device, 'show ip pim vrf ' + vrf + ' interface') \
            .get('interfaces', {})

    def collect(self):
        """
        For all VRFs, collect:
            Identity = { VRF-name }}|{{ interface }}
            Value = Count of PIM neighbors
        """
        vrfs = read_vrfs(self.device)
        self.post_data(json.dumps({
            'items': [
                {
                    'identity': '%s|%s' % (vrf, interface),
                    'value': str(interface_data['neighborCount'])
                }
                for vrf, vrf_info in vrfs.iteritems()
                if vrf_info['role'] != 'management' and
                vrf_info['multicast_mode'] == 'enabled'
                for interface, interface_data in self.get_pim_neighbors_in_vrf(
                    vrf).iteritems()
            ]
        }))


def collector_plugin(_device):
    return PimNeighborCountCollector
