# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula


from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
import logging
from aosstdcollectors.utils.data_util import to_extensible_postdata, \
    format_generic_value
from aosstdcollectors.compat.aos.sdk.system_agent.device import \
    get_running_aos_version
# pylint: disable=no-name-in-module
from distutils.version import LooseVersion as Version


LOG = logging.getLogger(__name__)


class EVPNType5Collector(BaseTelemetryCollector):

    def __init__(self, *args, **kwargs):
        super(EVPNType5Collector, self).__init__(*args, **kwargs)
        self.aos_version = get_running_aos_version()
        self.__collector_callback = None

    def collect(self):
        if not self.__collector_callback:
            device_info = self.device.get_device_info()

            if not isinstance(device_info, dict) or not device_info.get(
                    'os_version'):
                self.__collector_callback = self.dualstack_collector
            else:
                if Version(device_info['os_version']) > Version('4.20.0'):
                    self.__collector_callback = self.dualstack_collector
                else:
                    self.__collector_callback = self.ipv4_collector
        self.__collector_callback()

    def parse_evpn_route_table(self, cmd_response, ip_version):
        vteps = {}
        for rd_data in cmd_response.get('evpnRoutes', {}).itervalues():
            rd = rd_data.get('routeKeyDetail', {}).get('rd')
            subnet = rd_data.get('routeKeyDetail', {}).get('ipGenPrefix')
            identity = '%s|%s|%s' % (rd, ip_version, subnet)
            # TODO JP: use this when we have a better chance of stronger schemas,
            # but leave it here.
            # value = {
            #     'rd': rd,
            #     'vtep': vtep,
            #     'next_hops': list(set([
            #         get_ip(path)
            #         for path in rd_data.get('evpnRoutePaths', [])
            #         if get_ip(path) != '0.0.0.0'
            #     ])),
            # }
            value = "1"
            vteps[identity] = format_generic_value(self.aos_version, value)
        return vteps

    # This collector is used for EVPN collection on devices 4.20 or higher,
    # and is also the default collector for EVPN.
    def dualstack_collector(self):
        vteps = {}

        for ip_version in ('ipv4', 'ipv6'):
            cmd = 'show bgp evpn route-type ip-prefix %s detail' % ip_version
            data = self.device.get_json(cmd)
            if not data:
                continue
            vteps.update(self.parse_evpn_route_table(data, ip_version))

        self.post_data(
            to_extensible_postdata(vteps, aos_version=self.aos_version))

    # This collector is used for EVPN collection on devices earlier than 4.20.
    def ipv4_collector(self):
        data = self.device.get_json(
            'show bgp evpn route-type ip-prefix detail')
        vteps = {}

        vteps.update(self.parse_evpn_route_table(data, 'ipv4'))
        self.post_data(to_extensible_postdata(vteps, aos_version=self.aos_version))


def collector_plugin(_device):
    return EVPNType5Collector

# EOF
