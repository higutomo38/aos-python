# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula


import json
import logging

from pyeapi.eapilib import CommandError

from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.eos_vrf_util import read_vrfs
from collections import defaultdict

LOG = logging.getLogger(__name__)


class TableUsage(BaseTelemetryCollector):
    """
    iproute, arp entry, and multicast(mroute, source, group) counts
    """
    def _try_get_json(self, cmd):
        try:
            return self.device.get_json(cmd)
        except CommandError as e:
            LOG.warning("Command '%s' failed with error: %s", cmd, e)
            return {}

    def get_ip_routes(self, vrfs):
        results = defaultdict(lambda: dict(num_ip_routes=0))

        for vrf in vrfs:
            ip_routes = self._try_get_json(
                'show ip route vrf ' + vrf + ' summary').get('totalRoutes', 0)

            results[vrf]['num_ip_routes'] = ip_routes
            results['total']['num_ip_routes'] += ip_routes

        return [
            {
                'identity': '%s|num_ip_routes' % vrf,
                'value': str(results[vrf]['num_ip_routes'])
            }
            for vrf in results
        ]

    def get_arp_entries(self, vrfs):
        results = defaultdict(lambda: dict(num_arp_entries=0))

        for vrf in vrfs:
            total_entries = self._try_get_json(
                'show ip arp vrf ' + vrf + ' summary').get('totalEntries', 0)

            results[vrf]['num_arp_entries'] = total_entries
            results['total']['num_arp_entries'] += total_entries

        return [
            {
                'identity': '%s|num_arp_entries' % vrf,
                'value': str(results[vrf]['num_arp_entries'])
            }
            for vrf in results
        ]

    def get_mcast_table(self, vrfs):
        results = defaultdict(lambda: dict(
            num_mcast_routes=0,
            num_mcast_sources=0,
            num_mcast_groups=0
        ))

        for vrf, vrf_info in vrfs.iteritems():
            if vrf_info['multicast_mode'] == 'enabled':
                data = self._try_get_json('show ip mroute vrf ' + vrf + ' count')
                results[vrf]['num_mcast_routes'] = data.get('sgRoutes', 0)
                results[vrf]['num_mcast_sources'] = data.get('sources', 0)
                results[vrf]['num_mcast_groups'] = data.get('groups', 0)
                results['total']['num_mcast_routes'] += data.get('sgRoutes', 0)
                results['total']['num_mcast_sources'] += data.get('sources', 0)
                results['total']['num_mcast_groups'] += data.get('groups', 0)

        return [
            {
                'identity': '%s|%s' % (vrf, metric),
                'value': str(results[vrf][metric])
            }
            for vrf in results
            for metric in results[vrf]
        ]

    def create_breakdown(self, data, key):
        breakdown = defaultdict(dict)

        for e in data:
            vrf = e['identity'].split('|')[0]
            value = e['value']
            breakdown[vrf] = value

        return [
            {
                'identity': key,
                'value': json.dumps(breakdown, indent=2, sort_keys=True)
            }
        ]

    def create_mcast_breakdown(self, data):
        breakdown = defaultdict(dict)
        for e in data:
            key, metric = e['identity'].split('|')
            value = e['value']
            breakdown[metric][key] = value

        return [
            {
                'identity': 'mcast_data',
                'value': json.dumps(breakdown, indent=2, sort_keys=True)
            }
        ]

    def collect(self):
        vrfs = read_vrfs(self.device)
        mcast_data = self.get_mcast_table(vrfs)
        arp_entries = self.get_arp_entries(vrfs)
        ip_routes = self.get_ip_routes(vrfs)
        arp_breakdown = self.create_breakdown(arp_entries, 'arp_entries')
        ip_route_breakdown = self.create_breakdown(ip_routes, 'ip_routes')
        mcast_breakdown = self.create_mcast_breakdown(mcast_data)
        self.post_data(json.dumps({
            'items':
                mcast_data + arp_entries + ip_routes
                + arp_breakdown + ip_route_breakdown + mcast_breakdown
        }))


def collector_plugin(_device):
    return TableUsage
