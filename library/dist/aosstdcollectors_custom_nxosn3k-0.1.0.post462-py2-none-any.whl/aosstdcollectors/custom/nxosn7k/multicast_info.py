# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula


"""
Collector used for multicast discovery
"""

import json
import logging
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.nxosn7k_util import get_tree, get_value
from aosstdcollectors.utils.nxosn7k_vrf_util import read_vrfs
from aosstdcollectors.compat.aos.sdk.system_agent.device import \
    get_running_aos_version
from aosstdcollectors.utils.data_util import format_generic_value

LOG = logging.getLogger(__name__)


class MulticastInfoCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(MulticastInfoCollector, self).__init__(*args, **kwargs)
        self.aos_version = get_running_aos_version()

    def get_multicast_config(self, vrf):
        rp_tree, rp_nsmap = get_tree(
            self.device.get_text('show ip pim rp vrf ' + vrf + ' | xml'))
        anycast_rps = rp_tree.xpath(
            '//aos:show//aos:rp//aos:ROW_anycast_rp', namespaces=rp_nsmap)
        anycast_peers = rp_tree.xpath(
            '//aos:show//aos:rp//aos:ROW_arp_rp', namespaces=rp_nsmap)
        rps = rp_tree.xpath('//aos:show//aos:rp//aos:ROW_rp', namespaces=rp_nsmap)

        def get_group_mode(is_bidir):
            if is_bidir == 'true':
                return 'bidir'

            return 'pim-sparse'

        def get_rp_discovery_mode(rp_disc_mode):
            if rp_disc_mode == 'true':
                return 'static'

            return None

        return {
            'sparse_mode': {
                'groups': {
                    '%s/%s' % (
                        get_value(gr, rp_nsmap, 'grange-grp'),
                        get_value(gr, rp_nsmap, 'grange-masklen')
                        ): {
                            'mode': get_group_mode(
                                get_value(gr, rp_nsmap, 'is-bidir-grp')),
                            'rps': {
                                get_value(rp, rp_nsmap, 'rp-addr'): {
                                    'discovery_mode': get_rp_discovery_mode(
                                        get_value(rp, rp_nsmap, 'is-rp-static')),
                                    }
                            },
                        }
                    for rp in rps
                    for gr in rp.xpath('.//aos:ROW_grange', namespaces=rp_nsmap)
                },
                'anycast_rps': [
                    get_value(rp, rp_nsmap, 'anycast-rp-addr') for rp in anycast_rps
                ],
                'anycast_peers': [
                    get_value(rp, rp_nsmap, 'arp-rp-addr') for rp in anycast_peers
                ]
            }
        }

    def collect(self):
        vrfs = read_vrfs(self.device)
        self.post_data(json.dumps({
            'items': [
                {
                    'identity': vrf,
                    'value': format_generic_value(self.aos_version,
                                                  self.get_multicast_config(vrf))
                }
                for vrf, vrf_info in vrfs.iteritems()
                if vrf_info['role'] != 'management' and
                vrf_info['multicast_mode'] == 'enabled'
            ]
        }))


def collector_plugin(_device):
    return MulticastInfoCollector
