# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

import json
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.cumulus_util import make_item_lldp_nei, is_lldp
from aosstdcollectors.compat.aos.sdk.system_agent.device import \
    get_running_aos_version
from aosstdcollectors.utils.data_util import format_generic_value


def process(collected):
    def lldp_chassis_data(nei):
        return {
            'chassis_id': nei['chassis'][0]['id'][0].get('value'),
            'chassis_id_type': nei['chassis'][0]['id'][0].get('type'),
        }

    def make_lldp_nei(nei_data):
        chassis_data = lldp_chassis_data(nei_data)
        nei = make_item_lldp_nei(nei_data)
        return dict(chassis_data, **nei)

    lldp_neighbours = [neigbor for neigbor in collected if is_lldp(neigbor)]
    return {
        "items": [make_lldp_nei(neigbor) for neigbor in lldp_neighbours]
    }


class LldpDetailsCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(LldpDetailsCollector, self).__init__(*args, **kwargs)
        self.aos_version = get_running_aos_version()

    def collect(self):
        collected = self.device.get_json('sudo lldpctl -f json')
        result = process(collected.get('lldp')[0].get('interface'))
        result = {
            'items': [{
                'identity': item['interface_name'],
                'value': format_generic_value(self.aos_version, item)
            } for item in result['items']]
        }

        result = json.dumps(result)
        self.post_data(result)


def collector_plugin(_device):
    r"""
    Extends built-in `lldp` collector with

     - chassis_id
     - chassis_id_type

    Chassis ID is required to generate single system node during topology discovery
    process in case when server is connected to more than one leaf switches, e.g. in
    case of MLAG.

    +--------+  MLAG  +--------+
    | leaf1a |========| Leaf1b |
    +---+----+        +--+-----+
          \           /
           \        /
          +---------+
          | Server1 |
          +---------+

    In this scenario LLDP data available on `leaf1a` would have two interfaces
    discovered on `Server1`, and the same will be on `leaf1b`, and there would be no
    way of determining these two interfaces belong to the same system, unless we
    have chassis ID which would be the same for both interfaces, and thus would allow
    to create valid graph representing the system.

    Uses generic collector schema.
    """
    return LldpDetailsCollector
