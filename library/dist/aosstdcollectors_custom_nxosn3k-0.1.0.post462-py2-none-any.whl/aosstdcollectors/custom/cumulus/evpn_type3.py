# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula


from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
import re
import logging
from aosstdcollectors.utils.data_util import to_extensible_postdata, \
    format_generic_value
from aosstdcollectors.compat.aos.sdk.system_agent.device import \
    get_running_aos_version


LOG = logging.getLogger(__name__)


class EVPNType3Collector(BaseTelemetryCollector):

    def __init__(self, *args, **kwargs):
        super(EVPNType3Collector, self).__init__(*args, **kwargs)
        self.aos_version = get_running_aos_version()

    def collect(self):

        data = self.device.get_json(
            'vtysh -c "show bgp l2vpn evpn route type multicast json"')
        pattern = re.compile(r'\[3\]:\[0\]:\[32\]:\[(?P<vtep>.+)\]')

        def get_prefix(prefix):
            match = re.match(pattern, prefix)
            return match.group('vtep')

        vteps = {}

        for rd, rd_data in data.iteritems():
            # Top level keys in command output include the RD: {dict}, and some
            # unused keys numPrefix and numPaths.
            if not isinstance(rd_data, dict) or not rd_data.get('rd'):
                continue
            for prefix, prefix_item in rd_data.iteritems():
                if not isinstance(prefix_item, dict) or \
                        not prefix_item.get('prefix'):
                    continue

                identity = '%s|%s' % (rd, get_prefix(prefix))
                # Leave this here for future use.
                # value = {
                #     'rd': rd,
                #     'vtep': get_prefix(prefix),
                #     'next_hops': list(set([
                #         entry.get('peerId')
                #         for path in prefix_item.get('paths', [])
                #         for entry in path
                #     ])),
                # }
                value = "1"
                vteps[identity] = format_generic_value(self.aos_version, value)

        self.post_data(to_extensible_postdata(vteps, aos_version=self.aos_version))


def collector_plugin(_device):
    return EVPNType3Collector

# EOF
