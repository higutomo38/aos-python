# Copyright 2019-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

"""
Platform: Cisco Nexus 3K running 6.0(2)A7(2)
Usage: off-box only
"""

import netmiko
import logging
import re
import json
from aos.sdk.system_agent.device import Device
from aosdevicedrivers.compat.aos.sdk.system_agent.device import DeviceError
from aosdevicedrivers.compat.aos.sdk.system_agent.device import DeviceNetworkError
from aosdevicedrivers.utils.datautils import normalize_json_rows

LOGGER = logging.getLogger(__name__)
INVALID_COMMAND_REGEX = re.compile(r'\s+\^\s+% Invalid command.*')
SUPPORTED_VERSIONS = ['7.0(3)I7(6)']


class Nxosn3kDevice(Device):
    def __init__(self, *args, **kwargs):
        super(Nxosn3kDevice, self).__init__(*args, **kwargs)
        assert not self.onbox, (
            'nxos %s supported only with offbox' % ", ".join(SUPPORTED_VERSIONS))
        self.nxosn3k_device = None

    def open(self):
        self.nxosn3k_device = netmiko.ConnectHandler(
            device_type='cisco_nxos',
            ip=self.ip_address,
            username=self.username,
            password=self.password)

    def _get_mgmt_info(self, facts):
        mgmt_info = self.get_json(
            'show interface mgmt 0').get(
                'TABLE_interface', {}).get('ROW_interface', [])
        assert mgmt_info, 'cannot fetch management interface'
        mgmt_info = mgmt_info[0]
        facts['mgmt_ifname'] = mgmt_info.get('interface')

        if mgmt_info.get('eth_hw_addr', None) is not None:
            facts['mgmt_macaddr'] = mgmt_info['eth_hw_addr']
        else:
            LOGGER.warn('cannot fetch mac address - may be a loopback intf')

    def _get_hardware_info(self, facts):
        def _get_hardware_facts(hw_info):
            for row in hw_info:
                row['name'] = row['name'].replace('"', '')
                if row['name'] == 'Chassis':
                    return {
                        'hw_model': row['productid'],
                        'hw_version': row['vendorid'],
                        'serial_number': row['serialnum']
                    }
            raise DeviceError('cannot fetch hardware info')

        hw_info = self.get_json('show inventory').get('TABLE_inv').get('ROW_inv')
        hw_facts = _get_hardware_facts(hw_info)
        facts['hw_model'] = hw_facts['hw_model']
        facts['hw_version'] = hw_facts['hw_version']
        facts['serial_number'] = hw_facts['serial_number']
        facts['chassis_mac_ranges'] = ''

    def _get_version(self, facts):
        version = self.get_json('show version').get('rr_sys_ver', None)

        if version not in SUPPORTED_VERSIONS:
            raise DeviceError(
                'Unsupported version of NXOS3K device %s: '
                'supported versions are: %s' % (
                    version, ", ".join(SUPPORTED_VERSIONS)))

        version_pattern = re.compile(r'(\d+)\.(\d+)\((\d+\w?)\)')
        m = version_pattern.match(version)
        facts['os_version'] = version
        facts['os_version_info'] = {
            'major': m.group(1),
            'minor': m.group(2),
            'build': m.group(3)
        }

    def get_device_info(self):
        facts = {
            'vendor': 'Cisco',
            'os_family': 'NXOSN3K',
            'os_arch': 'x86',
            'mgmt_ipaddr': self.ip_address
        }

        try:
            self._get_version(facts)
            self._get_hardware_info(facts)
            self._get_mgmt_info(facts)
        except Exception:  # pylint: disable=broad-except
            LOGGER.exception('device_info exception')
            self.nxosn3k_device.disconnect()
        return facts

    def probe(self):
        LOGGER.debug('probe - checking connection is live')
        is_alive = self.nxosn3k_device.is_alive()

        if not is_alive:
            raise DeviceNetworkError("Device %s is unavailable" % self.ip_address)

    def close(self):
        self.nxosn3k_device.disconnect()

    def get_json(self, command):
        try:
            output = json.loads(self.get_text(command + " | json"))
            return normalize_json_rows(output)
        except ValueError as e:
            LOGGER.warn('Received invalid json %s', e)
            return {}

    def get_text(self, command):
        # refresh prompt due to bug https://github.com/ktbyers/netmiko/issues/1157
        self.nxosn3k_device.set_base_prompt()
        got = self.nxosn3k_device.send_command(command, auto_find_prompt=False)
        if INVALID_COMMAND_REGEX.match(got):
            LOGGER.warning("Command '%s' failed with error: %s", command, got)
            raise DeviceError(got)

        return got
