# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

try:
    from aos.sdk.system_agent.base_offbox_deployment_helper import \
        BaseOffBoxDeploymentHelper

    AOS_SDK_UNSUPPORTED_VERSION = False
except ImportError as e:
    from aosdevicedrivers.compat.exceptions import UnsupportedServerFeatureError

    AOS_SDK_UNSUPPORTED_VERSION = True

    class BaseOffBoxDeploymentHelper(object):
        def __init__(self, *args, **kwargs):
            raise UnsupportedServerFeatureError(
                "Offbox deployment is only supported with AOS 2.2+. Please check "
                "the AOS SDK version used.")
