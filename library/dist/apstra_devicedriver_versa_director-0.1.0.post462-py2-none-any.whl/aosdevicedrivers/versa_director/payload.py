# Copyright 2020-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

# TODO(ytien) define this as schema objects with default values for local
# validation. AOS-16490
APP_SVC_TRAFFIC_CATEGORY = {
    "name": None,
    "forwardingClass": None,
    "lossPriority": None,
    "appServiceTemplateName": None,
    "applicationServiceTemplateTrafficCategoryPaths": [],
    "applicationServiceTemplateTrafficCategoryActionLists": []
}

APP_SVC_TEMPLATE_RULE = {
    "name": None,
    "description": None,
    "trafficCategoryName": None,
    "applicationServiceTemplateRuleApplicationLists": [],
    "applicationServiceTemplateRuleServiceLists": [],
    "applicationServiceTemplateRuleMatches": [],
    "applicationServiceTemplateRulePaths": [],
    "applicationServiceTemplateRuleUrlCategoryLists": [],
    "applicationServiceTemplateRuleActionLists": [],
    "applicationServiceTemplateRuleFilterLists": [],
    "applicationServiceTemplateRuleGroupLists": []
}
