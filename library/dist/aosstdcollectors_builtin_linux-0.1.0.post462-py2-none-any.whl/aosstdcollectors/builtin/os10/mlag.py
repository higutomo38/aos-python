# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula
import json
import logging

import netaddr

from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.os10_util import get_vlt_running_config, parse, get_vlt

LOG = logging.getLogger(__name__)

CONFIG_SANITY_UNKNOWN = 3


class MlagCollector(BaseTelemetryCollector):
    def collect(self):
        def _peers(_mlag_interface, _local_info):
            local_interface_unit_id = _local_info.find('unit-id').text
            local_port, peer_port = None, None

            for peer in _mlag_interface.findall('peers'):
                peer_unit_id = peer.find('unit-id').text
                if peer_unit_id == local_interface_unit_id:
                    local_port = peer
                else:
                    peer_port = peer

            return local_port, peer_port

        def get_interface_name(_mlag_interface, _local_info):
            local, _ = _peers(_mlag_interface, _local_info)
            return local.find('lag-id').text

        def get_mlag_id(_mlag_interface):
            return int(_mlag_interface.find('id').text)

        def get_mlag_interface_state(_mlag_interface, _local_info):
            local, peer = _peers(_mlag_interface, _local_info)

            local_state = local.find('lag-status').text
            peer_state = peer.find('lag-status').text

            if local_state == 'up' and peer_state == 'up':
                return 'active_full'
            if (local_state == 'up' and peer_state == 'down' or
                    local_state == 'down' and peer_state == 'up'):
                return 'active_partial'
            if local_state == 'down' and peer_state == 'down':
                return 'inactive'

            return 'unknown'

        def get_domain_state(_vlt_brief):
            status = _vlt_brief.find(
                './data/topology-oper-data/vlt-domain/peer-info/peer-status').text

            return {
                'up': 'active',
                'down': 'inactive'
            }.get(status, 'unknown')

        def get_peer_address(_vlt_brief):
            peer_address = parse(
                _vlt_brief,
                './data/topology-oper-data/vlt-domain/peer-info/ip-address')
            # AOS does not support IPv6 for MLAG peer address yet, see AOS-10019
            return peer_address if netaddr.valid_ipv4(peer_address) else None

        vlt_running_config = get_vlt_running_config(self.device)

        domain_id = parse(vlt_running_config, './data/node-topology/topology-id')
        mlag_enabled = domain_id is not None
        mlag = {}

        if mlag_enabled:
            # all mlag interfaces are only available in detailed output
            vlt_detailed = get_vlt(self.device, domain_id, detailed=True)
            # peer link is only available in brief output
            vlt_brief = get_vlt(self.device, domain_id, detailed=False)

            peer_link_status = parse(
                vlt_brief,
                './data/topology-oper-data/vlt-domain/peer-link-info/link-status')
            peer_link = parse(
                vlt_brief,
                './data/topology-oper-data/vlt-domain/peer-link-info/if-name')

            mlag_interfaces = vlt_detailed.findall(
                './data/topology-oper-data/vlt-domain/vlt-port-info')
            local_info = vlt_detailed.find(
                './data/topology-oper-data/vlt-domain/local-info')

            mlag = {
                'mlag_global': {
                    'domain_id': domain_id,
                    'domain_state': get_domain_state(vlt_brief),
                    # TODO show vlt output doesn't contain local_interface and vlan
                    # information, check if we can extract them from other commands
                    'local_interface': None,
                    'local_intf_status': None,
                    'peer_link': peer_link,
                    'peer_link_status': peer_link_status,
                    'peer_address': get_peer_address(vlt_brief),
                    'config_sanity': str(CONFIG_SANITY_UNKNOWN),
                },
                'mlag_interface': [{
                    'intf_name': get_interface_name(mlag_interface, local_info),
                    'mlag_id': get_mlag_id(mlag_interface),
                    'intf_state': get_mlag_interface_state(mlag_interface,
                                                           local_info),
                } for mlag_interface in mlag_interfaces]
            }

        self.post_data(json.dumps(mlag))


def collector_plugin(_):
    return MlagCollector
