# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula


import json

from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.nxosn7k_util import get_tree


class HostnameCollector(BaseTelemetryCollector):
    def collect(self):
        data = self.device.get_text('show hostname | xml')
        tree, nsmap = get_tree(data)
        got = tree.xpath('//aos:show//aos:hostname', namespaces=nsmap)

        self.post_data(json.dumps(
            {
                'items': [
                    {
                        'hostname': got[0].text,
                        'domain': '',
                    }
                ]
            }))


def collector_plugin(_device):
    return HostnameCollector
