# Copyright 2020-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

'''Offbox deploment helper for Eos switches'''
# flake8: noqa: E722

import logging
from aosdevicedrivers.compat.aos.sdk.system_agent.base_telemetry_collector import (
    BaseOffBoxDeploymentHelper
)
import json
from copy import deepcopy
from payload import APP_SVC_TRAFFIC_CATEGORY, APP_SVC_TEMPLATE_RULE
LOGGER = logging.getLogger(__name__)


class VersaDirectorOffboxDeploymentHelper(BaseOffBoxDeploymentHelper):
    '''Offbox Deployment helper for Versa Director'''

    def setup_device_connection(self):
        '''Setup connectivity to the device
        '''
        self.sdk_device.open()
        return True

    def get_running_config(self):
        '''Queries the device for the running config and returns it as a single
           string.
        '''
        # TODO(ytien) check if there's an api to get this
        return 'versa running config'

    def get_system_uptime(self):
        '''Returns the system uptime in seconds (float)
        '''
        # TODO(ytien) check if there's an api to get this
        return 0

    @property
    def client(self):
        return self.sdk_device.client

    def get_device_template_map(self):
        device_template_map = {
            device: {
                'name': device_group['name'],
                'template': device_group['poststaging-template']
            }
            for device_group in (
                self.client.device_groups.list()
            )
            for device in device_group['inventory-name']
        }

        if not device_template_map:
            raise ValueError('No device group matching org {} is found'.format(
                self.sdk_device.org_name))
        return device_template_map

    def get_devices_label(self):
        return {
            device['uuid']: device['name']
            for device in self.client.appliances.list()
        }

    def get_device_template_service_association(
            self, dev_template_name, svc_template_name):
        associations = self.client.device_templates[
            dev_template_name].associations.list()
        if associations:
            for association in associations:
                if association['serviceTemplate'] == svc_template_name:
                    return association
        return None

    def create_device_group_payload(self, device_group_data):
        return {
            'device-group': {
                'name': device_group_data['name'],
                'dg:organization': self.sdk_device.org_name,
                'dg:enable-2factor-auth': device_group_data['enable-2factor-auth'],
                'dg:ca-config-on-branch-notification': device_group_data[
                    'ca-config-on-branch-notification'],
                'template-association': device_group_data['template-association'],
                'inventory-name': device_group_data['inventory-name'],
                'dg:enable-staging-url': device_group_data['enable-staging-url'],
                'dg:poststaging-template': device_group_data['poststaging-template']
            }
        }

    def update_device_group(self, device_group, device_group_data):
        device_group_payload = self.create_device_group_payload(device_group_data)
        return self.client.device_groups[
            device_group['name']].put(device_group_payload)

    def remove_device_group_association(self, device_group, template_name):
        device_group_data = self.client.device_groups[device_group['name']].template[
            device_group['template']].get()
        template_associations = device_group_data.get('template-association', {})

        associations_count = len(template_associations)
        template_associations = [
            association for association in template_associations
            if association['name'] != template_name
        ]

        if len(template_associations) == associations_count:
            LOGGER.exception(
                'device group %s, service template %s, has no association '
                'to remove', device_group['name'], template_associations
            )
            return None

        device_group_data['template-association'] = template_associations
        return self.update_device_group(device_group, device_group_data)

    def add_device_group_association(self, device_group, template_name):
        device_group_data = self.client.device_groups[device_group['name']].template[
            device_group['template']].get()
        template_associations = device_group_data.get('template-association', {})

        if any(association['name'] == template_name
               for association in template_associations):
            LOGGER.info(
                'device group %s, sce template %s are already associated',
                device_group['name'], template_name)
            return None

        template_associations.append({
            'name': template_name,
            'category': 'applications',
            'organization': self.sdk_device.org_name
        })

        device_group_data['template-association'] = template_associations
        return self.update_device_group(device_group, device_group_data)

    def remove_device_and_service_template_association(
            self, svc_template_name, device_group, device):
        device_group_updated = self.remove_device_group_association(
            device_group, svc_template_name)

        if device_group_updated:
            LOGGER.info('Removed device group %s, service template '
                        '%s association. response: %s',
                        device_group['name'], svc_template_name,
                        device_group_updated)

            LOGGER.info(
                'Applying device template %s to device on removing service template '
                '%s', device_group['template'], svc_template_name)
            self.client.device_templates[device_group['template']].apply({
                'versanms.devices': {
                    "device-list": [device]
                }})

    def remove_policy(self, policy_name, policy_data, site_group_device_map,
                      dev_template_map, devices_label):
        try:
            for site_group in policy_data['site_groups']:
                for device_id in site_group_device_map[site_group]:
                    device_label = devices_label[device_id]
                    self.remove_device_and_service_template_association(
                        policy_name, dev_template_map[device_label], device_label)
            self.client.service_workflow_templates[policy_name].delete()
            return True, None
        except Exception as e:  # pylint: disable=broad-except
            LOGGER.exception(
                'exception while removing policy %s, %s', policy_name, policy_data)
            return False, str(e)

    def add_device_and_service_template_association(
            self, svc_template_name, device_group, device):

        device_group_updated = self.add_device_group_association(
            device_group, svc_template_name)

        if device_group_updated:
            LOGGER.info(
                'Associated service template %s to device group %s. response: %s',
                svc_template_name, device_group['name'], device_group_updated)

            LOGGER.info('applying device template %s, service '
                        'template %s to device %s',
                        device_group['template'], svc_template_name, device)
            self.client.device_templates[device_group['template']].apply({
                'versanms.devices': {
                    "device-list": [device]
                }})

    def setup_traffic_conditioning_action(self, action):
        tc_actions = []
        path_selection = action['path_selection']
        # TODO(ytien) Only support criteria type of lowest available now
        if path_selection['latency']:
            tc_actions.append({
                'actionType': 'LOW_LATENCY'
            })
        if path_selection['packet_loss_percent']:
            tc_actions.append({
                'actionType': 'LOW_PACKET_LOSS'
            })
        if path_selection['packet_delay_variation']:
            tc_actions.append({
                'actionType': 'LOW_DELAY_VARIATION'
            })

        traffic_conditioning = action['traffic_conditioning']
        if traffic_conditioning['fec_mode'] == 'enabled':
            tc_actions.append({
                'actionType': 'FEC'
            })

        if traffic_conditioning['replication_mode'] == 'enabled':
            tc_actions.append({
                'actionType': 'REPLICATION'
            })

        return tc_actions

    def get_rule_app_list_by_type(self, rule_data, type_name):
        return [
            {
                'name': app_name,
                'applicationType': 'PREDEFINED'
            }
            for app_name in rule_data['app_criteria'][type_name]
        ]

    def add_policy(self, policy_name, policy_data, site_group_device_map,
                   device_template_map, devices_label):
        traffic_categories = []
        app_svc_template_rules = []
        try:
            for rule_name, rule_data in policy_data['rules'].iteritems():
                action = rule_data['actions']

                traffic_category = deepcopy(APP_SVC_TRAFFIC_CATEGORY)
                traffic_category['name'] = rule_name
                traffic_category['forwardingClass'] = action[
                    'forwarding_class']
                traffic_category['lossPriority'] = 'low'
                traffic_category['appServiceTemplateName'] = policy_name
                traffic_category[
                    'applicationServiceTemplateTrafficCategoryActionLists'
                ] = self.setup_traffic_conditioning_action(action)
                traffic_categories.append(traffic_category)

                app_groups = self.get_rule_app_list_by_type(
                    rule_data, 'application_groups')
                app_filter = self.get_rule_app_list_by_type(
                    rule_data, 'application_filter')

                app_svc_template_rule = deepcopy(APP_SVC_TEMPLATE_RULE)
                app_svc_template_rule['name'] = rule_name
                app_svc_template_rule['trafficCategoryName'] = rule_name
                app_svc_template_rule[
                    'applicationServiceTemplateRuleFilterLists'
                ] = app_filter
                app_svc_template_rule[
                    'applicationServiceTemplateRuleGroupLists'
                ] = app_groups

                app_svc_template_rules.append(app_svc_template_rule)

            policy_svc_template = {
                'name': policy_name,
                'organization': self.sdk_device.org_name,
                'trafficCategories': traffic_categories,
                'applicationServiceTemplateRules': app_svc_template_rules
            }

            if not self.client.service_workflow_templates[policy_name].get():
                self.client.service_workflow_templates.create(policy_svc_template)
                LOGGER.info('Created new service workflow template %s', policy_name)
                # this call generates service template from the workflow
                self.client.service_workflow_templates[policy_name].deploy()
            else:
                # TODO(ytien) need to handle the policy updates
                LOGGER.warn(
                    'Service workflow template %s already exists', policy_name)
                raise ValueError(
                    'Policy update is unsupported. Svc wf tmpl {} exists'.format(
                        policy_name))

            for site_group in policy_data['site_groups']:
                for device_id in site_group_device_map[site_group]:
                    device_label = devices_label[device_id]
                    self.add_device_and_service_template_association(
                        policy_name, device_template_map[device_label], device_label)
            return True, None
        except Exception as e:  # pylint: disable=broad-except
            LOGGER.exception('exception while handling policy %s, %s',
                             policy_name, policy_data)
            return False, str(e)

    def apply_complete_config(self, config_blob, pristine_config):
        '''Overwrite the running config of the device with given config blob
        '''

        return True, ''

    def apply_incremental_config(self, config_blob):
        '''Apply the given incremental config blob on the device
        '''
        try:
            errors = []
            device_template_map = self.get_device_template_map()
            devices_label = self.get_devices_label()

            config = json.loads(config_blob)
            added_policies = config.get('changed').get(
                'policies', {}).get('added', {})
            for policy_name, policy_data in added_policies.iteritems():
                success, err_msg = self.add_policy(
                    policy_name, policy_data, config['new']['site_groups'],
                    device_template_map, devices_label)
                if not success:
                    errors.append(err_msg)

            removed_policies = config.get('changed').get(
                'policies', {}).get('removed', {})
            for policy_name, policy_data in removed_policies.iteritems():
                success, err_msg = self.remove_policy(
                    policy_name, policy_data, config['old']['site_groups'],
                    device_template_map, devices_label)
                if not success:
                    errors.append(err_msg)

            return len(errors) == 0, str(errors)
        except Exception as e:  # pylint: disable=broad-except
            LOGGER.exception('Error applying incremental config')
            return False, str(e)
