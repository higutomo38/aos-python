# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

"""
Platform: Cisco Nexus 7K running 6.2(x)
Usage: off-box only
"""

import netmiko
import logging
import re
from aos.sdk.system_agent.device import Device
from .nxosn7k_getdeviceinfo import nxosn7k_gather_facts

from aosdevicedrivers.compat.aos.sdk.system_agent.device import DeviceError
from aosdevicedrivers.compat.aos.sdk.system_agent.device import DeviceNetworkError

LOGGER = logging.getLogger(__name__)
INVALID_COMMAND_REGEX = re.compile(r'\s+\^\s+% Invalid command.*')


class Nxosn7kDevice(Device):
    def __init__(self, *args, **kwargs):
        super(Nxosn7kDevice, self).__init__(*args, **kwargs)
        assert not self.onbox, 'nxos 6.2 supported only with offbox'
        self.nxosn7k_device = None

    def open(self):
        self.nxosn7k_device = netmiko.ConnectHandler(
            device_type='cisco_nxos',
            ip=self.ip_address,
            username=self.username,
            password=self.password)

    def get_device_info(self):
        facts = {
            'vendor': 'Cisco',
            'os_family': 'NXOSN7K',
            'os_arch': 'x86_64',
            # TODO (mhutt) AOS-9046 Need to resolve management IP from hostname
            'mgmt_ipaddr': self.ip_address
        }

        return nxosn7k_gather_facts(device=self, facts=facts)

    def probe(self):
        LOGGER.debug('probe - checking connection is live')

        try:
            self.nxosn7k_device.is_alive()
        # pylint: disable=broad-except
        except Exception as ex:
            if 'No route to host' in ex.message:
                raise DeviceNetworkError('Device network error', ex)
            else:
                raise DeviceError('Device error', ex)

    def close(self):
        self.nxosn7k_device.disconnect()

    def get_text(self, command):
        # refresh prompt due to bug https://github.com/ktbyers/netmiko/issues/1157
        self.nxosn7k_device.set_base_prompt()
        got = self.nxosn7k_device.send_command(command, auto_find_prompt=False)
        if INVALID_COMMAND_REGEX.match(got):
            LOGGER.warning("Command '%s' failed with error: %s", command, got)
            raise DeviceError(got)

        return got
