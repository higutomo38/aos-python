# Copyright 2019-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

from azure.common.credentials import ServicePrincipalCredentials
from azure.mgmt.compute import ComputeManagementClient
from azure.mgmt.network import NetworkManagementClient
from azure.mgmt.resource import ResourceManagementClient

from aos.sdk.system_agent.device import Device
from aosdevicedrivers.compat.aos.sdk.system_agent.device import DeviceError


class MissingArgumentsError(DeviceError):
    def __init__(self, msg):
        super(MissingArgumentsError, self).__init__(msg)
        self.message = msg

    def __str__(self):
        return self.message


class AzureCloud(Device):
    REQUIRED_ARGUMENTS = ["tenant_id", "subscription_id"]

    def __init__(
            self, ip_address, username, password, onbox=False, open_options=None
    ):
        """
        Azure Cloud driver uses combination of username, password and open_options
        for authentication.

            ip_address - ignored;
            username - Azure appId (applicationId, or clientId);
            password - Azure client secret;
            onbox - ignored (always offbox);
            open_options - must use schema:

              {
                "tenant_id": "<tenant ID>",
                "subscription_id": "<subscription ID>"
              }

        See how to create authentication credentials below.

        Azure user must create Service Principal to authenticate with Azure.

        Below are instructions for Azure CLI for password-based authentication.

        1. Create Service Principal:

            az ad sp create-for-rbac --name ServicePrincipalName --password PASSWORD

        2. The JSON output of the create-for-rbac command is in the following format:

            {
              "appId": "APP_ID",
              "displayName": "ServicePrincipalName",
              "name": "http://ServicePrincipalName",
              "password": ...,
              "tenant": "XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX"
            }

           Use `appId` as `client_id`, `password` as `client_secret`, `tenant` as
           `tenant_id`.

        3. Use `id` for `subscription_id`:

            $ az account show
            {
              "environmentName": "AzureCloud",
              "id": "XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX",
              "isDefault": true,
              "name": "Pay-As-You-Go",
              "state": "Enabled",
              "tenantId": "XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX",
              "user": {
                "name": "user@organization.com",
                "type": "user"
              }
            }

        """

        super(AzureCloud, self).__init__(
            ip_address=ip_address,
            username=username,
            password=password,
            onbox=False,
            open_options=open_options,
        )

        if not open_options:
            msg = "Azure driver requires {} arguments passed".format(
                ", ".join(self.REQUIRED_ARGUMENTS)
            )
            raise MissingArgumentsError(msg)

        actual_args = set(open_options.keys())
        expected_args = set(self.REQUIRED_ARGUMENTS)
        missing = expected_args - actual_args

        if missing:
            msg = "Azure driver requires {} arguments passed".format(
                ", ".join(missing))
            raise MissingArgumentsError(msg)

        self.resource_client = None
        self.compute_client = None
        self.network_client = None
        self.credentials = None
        self.subscription_id = None

    def open(self):
        client_id = self.username
        client_secret = self.password
        tenant_id = self.open_options["tenant_id"]
        self.subscription_id = self.open_options["subscription_id"]

        if self.credentials is None:
            self.credentials = ServicePrincipalCredentials(
                client_id=client_id, secret=client_secret, tenant=tenant_id
            )

        self.resource_client = ResourceManagementClient(
            self.credentials, self.subscription_id
        )
        self.compute_client = ComputeManagementClient(
            self.credentials, self.subscription_id
        )
        self.network_client = NetworkManagementClient(
            self.credentials, self.subscription_id
        )

    def get_device_info(self):
        return {
            "serial_number": self.subscription_id,
            "vendor": "Microsoft",
            "hardware_model": "",
            "os_version": "",
            "os_family": "Azure",
            "mgmt_ipaddr": "",
        }

    def close(self):
        self.credentials = None
        self.resource_client = None
        self.compute_client = None
        self.network_client = None

    def probe(self):
        pass
