# Copyright 2020-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

"""Offbox deploment helper for Mist Cloud Controller"""

import json
import logging
from aosdevicedrivers.compat.aos.sdk.system_agent.base_telemetry_collector import (
    BaseOffBoxDeploymentHelper
)
from .payload import CREATE_WLAN_PAYLOAD
from copy import deepcopy
from collections import defaultdict

LOGGER = logging.getLogger(__name__)


class MistOffboxDeploymentHelper(BaseOffBoxDeploymentHelper):
    """Offbox Deployment helper for Mist cloud"""

    def __init__(self, sdk_device):
        super(MistOffboxDeploymentHelper, self).__init__(sdk_device)

    def setup_device_connection(self):
        """Setup connectivity to the device
        """
        self.sdk_device.open()
        return True

    def get_running_config(self):
        """Queries the device for the running config and returns it as a single
           string.
        """
        org_id = self.sdk_device.get_org_id()

        # The site_id and wireless_id returned here are the IDs from
        # the mist controller.
        # TODO(mhutt) AOS-17883
        return json.dumps({
            s['id']: {
                'site_name': s['name'],
                'wlans': {
                    w['id']: {
                        'ssid': w['ssid']
                    }
                    for w in self.sdk_device.client.sites[s['id']].wlans.list()
                }
            }
            for s in self.sdk_device.client.orgs[org_id].sites.list()
        })

    def get_system_uptime(self):
        """Returns the system uptime in seconds (float)
        """
        return 0

    def apply_complete_config(self, config_blob, pristine_config):
        """Overwrite the running config of the device with given config blob
        """
        return True, ''

    def get_site_name_site_id_map(self):
        org_id = self.sdk_device.get_org_id()
        return {
            site['name']: site['id']
            for site in (self.sdk_device.client.orgs[org_id].sites.list() or [])
        }

    def get_site_ssid_name_id_map(self, sites, site_name_site_id_map):
        site_ssid_name_id_map = defaultdict(dict)
        for site_name in sites:
            for wlan in (
                    self.sdk_device.client
                    .sites[site_name_site_id_map[site_name]].wlans.list()):
                site_ssid_name_id_map[site_name][wlan['ssid']] = wlan['id']
        return site_ssid_name_id_map

    def apply_incremental_config(self, config_blob):
        """Apply the given incremental config blob on the device
        """
        def generate_payload():
            payload = deepcopy(CREATE_WLAN_PAYLOAD)
            payload['ssid'] = wlan['ssid']
            payload['enabled'] = True
            if wlan.get('access_security_mode') == 'wpa2_eap':
                # Indicates that we need 802.1x
                # Currently only supports dynamic vlans
                payload['auth']['type'] = 'eap'
                payload['dynamic_vlan']['enabled'] = True
                payload['dynamic_vlan']['type'] = 'standard'
                payload['dynamic_vlan']['vlans'] = {
                    str(vlan): str(vlan)
                    for vlan in wlan.get('vlan_ids')
                }
                payload[
                    'dynamic_vlan']['default_vlan_id'] = wlan.get('staging_vlan')
            elif wlan.get('access_security_mode') == 'wpa2_psk':
                payload['auth']['type'] = 'psk'
                payload['auth']['psk'] = wlan['pre_shared_key']
                if len(wlan.get('vlan_ids')) == 1:
                    # vlan tagging is enabled
                    payload['vlan_enabled'] = True
                    payload['vlan_id'] = wlan.get('vlan_ids')[0]
                else:
                    # we have more than 1 vlan and need a pool
                    payload['vlan_enabled'] = True
                    payload['vlan_pooling'] = True
                    payload['vlan_ids'] = wlan.get('vlan_ids')
            else:
                # access_security_mode is not set and we have an open network.
                # This should be a guest network with only a single tagged vlan.
                payload['auth']['type'] = 'open'
                payload['vlan_enabled'] = True
                payload['vlan_id'] = wlan.get('vlan_ids')[0]
                payload['enable_mac_auth'] = True

            return payload

        LOGGER.info('incremental config %s', config_blob)
        site_name_site_id_map = self.get_site_name_site_id_map()
        LOGGER.debug('self.site_name_site_id_map %s', site_name_site_id_map)

        errors = list()
        config = json.loads(config_blob)
        wlans_added = config.get('changed', {}).get('sites', {}).get('added', {})
        for _, site in wlans_added.iteritems():
            site_name = site['site_name']
            for wlan in site['wlans'].itervalues():
                payload = generate_payload()
                try:
                    self.sdk_device.client.sites[
                        site_name_site_id_map[site_name]].wlans.create(payload)
                except Exception as e:  # pylint: disable=broad-except
                    # Process maximum possible api calls handling failures
                    LOGGER.exception("ERROR: %s adding wlan %s", e, payload)
                    errors.append("ERROR: %s adding wlan %s" % (e, payload))

        wlans_removed = config.get('changed', {}).get('sites', {}).get('removed', {})
        site_names = {
            site_data['site_name'] for _, site_data in wlans_removed.iteritems()}
        site_ssid_name_id_map = self.get_site_ssid_name_id_map(
            site_names, site_name_site_id_map)
        LOGGER.debug('site_ssid_name_id_map %s', site_ssid_name_id_map)
        for _, site in wlans_removed.iteritems():
            site_name = site['site_name']
            for wlan in site['wlans'].itervalues():
                ssid = wlan['ssid']
                try:
                    self.sdk_device.client.sites[
                        site_name_site_id_map[site_name]].wlans[
                            site_ssid_name_id_map[site_name][ssid]].delete()
                except Exception as e:  # pylint: disable=broad-except
                    # Process maximum possible api calls handling failures
                    LOGGER.exception("ERROR: %s deleting wlan %s", e, wlan['ssid'])
                    errors.append("ERROR: %s deleting wlan %s" % (e, wlan['ssid']))

        return len(errors) == 0, str(errors)
