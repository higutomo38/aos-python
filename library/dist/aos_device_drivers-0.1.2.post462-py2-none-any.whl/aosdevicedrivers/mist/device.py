# Copyright 2020-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula


from aos.sdk import schema as s
from aos.sdk.system_agent.device import Device
from aos.sdk.types import ValidationError
from mist_client import MistClient


OPEN_OPTIONS_SCHEMA = s.Object({
    'org_name': s.String(validate=s.Length(min=1),
                         description='Name of the Mist org.')
})


class MistCloud(Device):
    def __init__(
            self, ip_address, username, password, onbox=False, open_options=None):
        super(MistCloud, self).__init__(
            ip_address=ip_address,
            username=username,
            password=password,
            onbox=False,
            open_options=open_options,
        )
        assert not self.onbox, 'Only offbox is supported for Mist.'

        if open_options is None:
            raise ValidationError('org_name: Value is required')

        OPEN_OPTIONS_SCHEMA.load({
            'org_name': self.open_options.get('org_name')
        })

        self.client = None

    def open(self):
        self.client = MistClient(
            self.username, self.password)

    def get_org_id(self):
        return self.client.get_org_id(self.open_options['org_name'])

    def get_device_info(self):
        return {
            "serial_number": self.get_org_id(),
            "vendor": "Juniper Networks",
            "hardware_model": "Mist Controller",
            "os_version": "",
            "os_family": "mist",
            "mgmt_ipaddr": "",
        }

    def close(self):
        self.client = None

    def probe(self):
        return self.client.probe()
