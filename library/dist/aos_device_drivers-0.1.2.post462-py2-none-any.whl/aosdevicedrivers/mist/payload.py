# Copyright 2020-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

CREATE_WLAN_PAYLOAD = {
    "ssid": "",
    "enabled": False,
    "hide_ssid": False,
    "no_static_ip": False,
    "no_static_dns": False,
    "band": "both",
    "band_steer": False,
    "airwatch": {
        "enabled": False,
        "console_url": "",
        "api_key": "",
        "username": "",
        "password": ""
    },
    "disable_wmm": False,
    "disable_uapsd": False,
    "use_eapol_v1": False,
    "auth_servers_nas_id": "",
    "auth_servers_nas_ip": "",
    "disable_11ax": False,
    "vlan_enabled": False,
    "arp_filter": False,
    "limit_bcast": False,
    "allow_mdns": False,
    "vlan_id": None,
    "interface": "all",
    "mxtunnel_id": None,
    "wxtunnel_id": None,
    "wxtunnel_remote_id": None,
    "wlan_limit_up": 10000,
    "wlan_limit_down": 20000,
    "client_limit_up": 512,
    "client_limit_down": 1000,
    "portal": {
        "enabled": False,
        "bypass_when_cloud_down": True,
        "auth": "none",
        "privacy": False,
        "external_portal_url": "",
        "sso_issuer": "",
        "sso_nameid_format": "email",
        "sso_idp_sign_algo": "sha1",
        "sso_idp_cert": "",
        "sso_idp_sso_url": "",
        "sso_default_role": "",
        "sso_forced_role": "",
        "password": "",
        "expire": 480,
        "forward": False,
        "forward_url": "",
        "passphrase_enabled": False,
        "email_enabled": False,
        "sms_enabled": False,
        "smsMessageFormat": "Code {{code}} expires in {{duration}} minutes.",
        "sms_provider": "manual",
        "sponsor_enabled": False,
        "sponsor_email_domains": [],
        "sponsor_link_validity_duration": "60",
        "google_enabled": False,
        "google_client_id": "",
        "google_client_secret": "",
        "google_email_domains": [],
        "facebook_enabled": False,
        "facebook_client_id": "",
        "facebook_client_secret": "",
        "facebook_email_domains": [],
        "amazon_enabled": False,
        "amazon_client_id": "",
        "amazon_client_secret": "",
        "amazon_email_domains": [],
        "microsoft_enabled": False,
        "microsoft_client_id": "",
        "microsoft_client_secret": "",
        "microsoft_email_domains": [],
        "azure_enabled": False,
        "azure_client_id": "",
        "azure_client_secret": "",
        "azure_tenant_id": ""
    },
    "portal_allowed_subnets": [],
    "portal_allowed_hostnames": [],
    "portal_denied_hostnames": [],
    "portal_api_secret": "",
    "cisco_cwa": {
        "enabled": False,
        "allowed_subnets": [],
        "allowed_hostnames": []
    },
    "auth_servers": [],
    "acct_servers": [],
    "schedule": {
        "enabled": False,
        "hours": None
    },
    "radsec": {
        "enabled": False,
        "server_name": "",
        "servers": []
    },
    "dtim": 2,
    "app_qos": {
        "enabled": False,
        "apps": None
    },
    "auth": {
        "type": "psk",
        "enable_mac_auth": False,
        "private_wlan": False,
        "keys": [
            None,
            None,
            None,
            None
        ],
        "key_idx": 1,
        "multi_psk_only": False,
        "eap_reauth": False,
        "psk": ""
    },
    "dynamic_vlan": None,
    "dns_server_rewrite": None,
    "qos": {
        "overwrite": False,
        "class": "best_effort"
    },
    "coa_server": None,
    "rateset": {
        "5": {
            "template": "compatible",
            "min_rssi": 0
        },
        "24": {
            "template": "compatible",
            "min_rssi": 0
        }
    },
    "app_limit": {
        "enabled": False,
        "apps": None,
        "wxtag_ids": None
    },
    "max_idletime": 1800,
    "vlan_pooling": False,
    "vlan_ids": [],
    "wxtag_ids": None,
    "ap_ids": None,
    "apply_to": "site"
}
