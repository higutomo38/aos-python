# Copyright 2020-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

"""
Platform: Mist API: https://api.mist.com/api/v1/
Usage: off-box only

An apitoken for an account can be created from:
https://api.mist.com/api/v1/self/apitokens
The token is only displayed when it is initally created by clicking post

200 OK
400 Bad Request. The API endpoint exists but its syntax/payload is incorrect,
detail may be given
401 Unauthorized
403 Permission Denied
404 Not found. The API endpoint doesn't exist or resource doesn't exist

"""

# pylint: disable=invalid-name
# pylint: disable=arguments-differ
# pylint: disable=no-value-for-parameter

import base64
import http_test_client
import logging
from http_test_client import Api, api, RestResources, ClientError

# Internet access is required to reach the Mist api
MIST_API_SERVER = 'https://api.mist.com'
MIST_API_PREFIX = '/api/v1'

LOGGER = logging.getLogger(__name__)


class HttpTransport(http_test_client.HttpTransport):
    def __init__(self, base_url, verify_certificates=True):
        super(HttpTransport, self).__init__(base_url)
        self._session.verify = verify_certificates


class MistClient(http_test_client.Client):
    def __init__(self, username, password):
        self._transport = HttpTransport(MIST_API_SERVER, verify_certificates=True)
        self.username = username
        self.password = password
        self._headers = None
        super(MistClient, self).__init__(self._transport)

        auth = base64.b64encode('{}:{}'.format(self.username, self.password))
        self._headers = dict(
            {"Authorization": "Basic {}".format(auth), "Accept": "*/*"})

    def raw_request(self, *args, **kwargs):
        headers = kwargs.pop('headers', None) or {}
        headers = dict(self._headers, **headers)

        return super(MistClient, self).raw_request(
            *args, headers=headers, **kwargs)

    def probe(self):
        response = self.raw_request(
            method='GET', url="{}/self".format(MIST_API_PREFIX))
        if response.status_code == 200:
            return True
        return False

    def get_org_id(self, org_name):
        resp = self.privileges.get()
        for i in resp['privileges']:
            if i.get('name') == org_name:
                return i['org_id']
        return None

    # The Mist API includes an endpoint called self
    # Get 'whoami' and privileges (which org and which
    # sites I have access to)
    @api(MIST_API_PREFIX+'/self')
    class privileges(Api):
        def get(self, **kwargs):
            try:
                return self._request(method='GET', **kwargs)
            except ClientError as ce:
                if ce.status_code != 404:
                    raise ce
            return None

    @api(MIST_API_PREFIX+'/orgs')
    class orgs(RestResources):
        @api('/{org_id}')
        class resource(Api):
            @api('/sites')
            class sites(RestResources):
                pass

    @api(MIST_API_PREFIX+'/sites')
    class sites(RestResources):
        @api('/{site_id}')
        class resource(Api):
            @api('/wlans')
            class wlans(RestResources):
                pass

    @api(MIST_API_PREFIX+'/sites')
    # site get, update, delete
    class site_mgmt(RestResources):
        pass
