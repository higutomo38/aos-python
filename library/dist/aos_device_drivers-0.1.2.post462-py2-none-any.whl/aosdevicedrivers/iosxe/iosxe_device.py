# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

"""
Platform: Cisco Catalyst IOS-XE
Usage: off-box only
"""

import netmiko

from aos.sdk.system_agent.device import Device

from .iosxe_facts import iosxe_gather_facts


class IosxeDevice(Device):

    # ###   ---------------------------------------------------------
    # ###   Required 'Device' Methods
    # ###   ---------------------------------------------------------

    def open(self):

        # open a SSH connection to the device using the
        # Netmiko library

        self.driver = netmiko.ConnectHandler(
            device_type='cisco_xe',
            ip=self.ip_address,
            username=self.username,
            password=self.password)

        # put the device into 'enable' mode
        self.driver.enable()

    def get_device_info(self):
        facts = {
            'vendor': 'Cisco',
            'mgmt_ipaddr': self.ip_address
        }

        return iosxe_gather_facts(self.driver, facts)

    def probe(self):
        # TODO: need to implement
        return True

    def close(self):
        self.driver.disconnect()

    # ###   ---------------------------------------------------------
    # ###   Required for Text based collectors
    # ###   ---------------------------------------------------------

    def get_text(self, command):
        return self.driver.send_command_expect(command)
