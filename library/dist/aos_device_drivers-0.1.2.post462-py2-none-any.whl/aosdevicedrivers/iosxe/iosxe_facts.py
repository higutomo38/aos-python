# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

"""
This file contains the functions required to retrieve the AOS device 'facts'
from a Cisco IOS-XE based device.
"""

import retrying

from aosdevicedrivers.utils.textparsing import TextFsmParser


_route_template = r""" #
Value Interface (\S+)

Start
  ^Routing entry for %s/32
  ^Known via "connected", distance 0, metric 0 (connected)
  ^.*, via ${Interface} -> Record

EOF
"""

_intf_template = r"""#
Value Required Interface (\S+.*)
Value State (\S+.*)
Value Line (\S+.*)
Value MACAddress (\S+)
Value IPAddress (\S+)
Value OutputErrors (\d+)
Value InputErrors (\d+)

Start
  ^${Interface} is ${State}, line protocol is ${Line}
  ^  Hardware is .*, address is ${MACAddress}
  ^  Internet address is ${IPAddress}
  ^\s+${OutputErrors} output errors
  ^\s+${InputErrors} input errors -> Record

EOF
"""


def facts_mgmt_info(dev, facts):
    ipaddr = facts['management_ip']

    sh_rt = dev.send_command_expect('show ip route vrf mgmtVrf %s' % ipaddr)
    parser = TextFsmParser(_route_template % ipaddr)
    data = parser.parse(sh_rt)

    facts['mgmt_ifname'] = data[0][0]

    sh_int = dev.send_command_expect('show int %s' % facts['management_interface'])
    parser = TextFsmParser(_intf_template)
    data = parser.parse(sh_int)

    # example:
    # [['FastEthernet1', 'up', 'up ', '002a.109c.4113', '172.20.60.6/24', '', '0']]

    macaddr = data[0][3].replace('.', '').upper()

    facts['mgmt_macaddr'] = macaddr


def facts_from_version(dev, facts):

    line = dev.send_command_expect('show version').split('\n')[0]
    version = str(line.partition('Version')[-1].split()[0])
    ver_splits = version.split('.', 2)

    facts['os_family'] = 'IOS-XE'
    facts['os_version'] = version
    facts['os_version_info'] = {
        'major': ver_splits[0],
        'minor': ver_splits[1],
        'build': ver_splits[2]
    }


_inventory_parser = r""" # TextFSM
Value Name (.+)
Value Description (.+)
Value Pid (\S+)
Value Vid (\S+)
Value Serialnumber (\S+)

Start
  ^NAME: "${Name}", DESCR: "${Description}"
  ^PID: ${Pid}\s+, VID: ${Vid}\s+, SN: ${Serialnumber} -> Record

EOF
"""


def facts_from_inventory(dev, facts):

    inv_parser = TextFsmParser(template=_inventory_parser)

    @retrying.retry(wait_fixed=1000, stop_max_delay=5000)
    def get_system():
        inv_text = dev.send_command_expect('show inventory')
        assert inv_text
        inv_data = inv_parser.parse(inv_text)
        system = [item for item in inv_data if item[0] == 'Switch System'][0]
        return system

    system = get_system()

    # exmaple results:
    # [['Switch System',
    #   'Cisco Systems, Inc. WS-C4503-E 3 slot switch ',
    #   'WS-C4503-E',
    #   'V01',
    #   'SPE1145018T'],

    facts['hw_model'] = system[2]
    facts['hw_version'] = system[3]
    facts['serial_number'] = system[4]
    facts['os_arch'] = 'cisco'       # TODO: investigate
    facts['chassis_mac_ranges'] = ''


def iosxe_gather_facts(dev, facts):

    facts_from_inventory(dev, facts)
    facts_from_version(dev, facts)
    facts_mgmt_info(dev, facts)

    return facts
