# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula


import json
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.nxosn7k_util import get_tree, get_value


class MacCollector(BaseTelemetryCollector):

    def _process(self, data):
        tree, nsmap = get_tree(data)

        def get_mac_address(mac_entry):
            mac = get_value(mac_entry, nsmap, 'disp_mac_addr')
            if mac:
                mac = mac.replace('.', '')
                return ':'.join(mac[c:c + 2] for c in xrange(0, 12, 2))
            return mac

        def get_mac_type(mac_entry):
            # TODO(mahi): the type field in the dump has "(G)", Gateway mac,
            # hence using is_static field for determining if mac is static or not.
            # However the onbox collector is using type field to determine the
            # mac type. Need to revisit this again when proper mac table dump
            # is available.
            mac_type = get_value(mac_entry, nsmap, 'disp_is_static')
            return 'staticMac' if mac_type == 'enabled' else 'dynamicMac'

        def get_interface_name(mac_entry):
            ifname = get_value(mac_entry, nsmap, 'disp_port')
            if ifname:
                ifname = ifname.replace("(R)", "")
            return ifname

        def get_mac_rec(mac_entry):
            mac = {
                'mac_address': get_mac_address(mac_entry),
                'vlan': int(get_value(mac_entry, nsmap, 'disp_vlan')),
                'interface_name': get_interface_name(mac_entry),
                'type': get_mac_type(mac_entry)
            }
            # Filtering out mac entries with vlan 0 due to schema validation failure
            if mac['vlan']:
                return mac
            return None

        mac_entries = tree.xpath('//aos:ROW_mac_address', namespaces=nsmap)
        result = [get_mac_rec(row) for row in mac_entries]
        result = [m for m in result if m is not None]
        return json.dumps({
            'items': result
        })

    def collect(self):
        data = self.device.get_text('show mac address-table | xml')
        parsed_data = self._process(data)
        self.post_data(parsed_data)


def collector_plugin(_device):
    return MacCollector
