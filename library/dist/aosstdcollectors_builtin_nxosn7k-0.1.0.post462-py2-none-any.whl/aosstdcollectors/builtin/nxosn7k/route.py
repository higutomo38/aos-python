# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

import json
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.nxosn7k_util import get_tree, get_value
from netaddr import IPNetwork


class RouteCollector(BaseTelemetryCollector):

    def _process_routes(self, data):
        tree, nsmap = get_tree(data)

        def get_route_type(nexthop):
            route_types = {
                'local': 'direct',
                'direct': 'direct'
            }
            client_name = get_value(nexthop, nsmap, 'clientname')
            if 'bgp' in client_name:
                route_type = 'bgp'
            # TODO(mahi): The onbox collector is checking for 'stat' instead of
            # static. Currently, we don't have output with static routes or
            # unknown routes; hence following what was implemented in cisco on box
            # collector and EOS off box collector.
            elif 'stat' in client_name:
                route_type = 'stat'
            else:
                route_type = route_types.get(client_name, 'unknown')
            return route_type

        def make_nexthop_item(nexthop):
            nexthop_addr = get_value(nexthop, nsmap, 'ipnexthop')
            nexthop_info = None
            if nexthop_addr:
                nexthop_info = {
                    'prefix': nexthop_addr,
                    # the show ip route dump has ip address for nexthop
                    # without prefix length; hence setting prefix len as
                    # 32, as the nexthop always will be a host route.
                    'prefix_len': '32',
                    'tag': get_value(nexthop, nsmap, 'ifname'),
                    'type': get_route_type(nexthop),
                    # TODO(mahi): the "show ip route" don't have the nexthop
                    # status. EOS collector is setting status as up and
                    # hence following the same here.
                    'status': 'up'
                }
            return nexthop_info

        def get_nexthops(prefix):
            nexthops = prefix.xpath('.//aos:ROW_path', namespaces=nsmap) or []
            return [nh
                    for nh in (make_nexthop_item(item) for item in nexthops)
                    if nh is not None]

        def get_route(prefix):
            value = get_value(prefix, nsmap, 'ipprefix')
            if value:
                ipprefix = IPNetwork(value)
                route = {
                    'prefix': str(ipprefix.ip),
                    'prefix_len': str(ipprefix.prefixlen),
                    'next_hops': get_nexthops(prefix)
                }
                # There is no route status in "show ip route". EOS offbox
                # collector is setting route_status to 'up' if next hops
                # doesn't exist, hence following the same here.
                if route['next_hops']:
                    route['route_status'] = 'up'
                    return route
            return None

        afs = tree.xpath('//aos:ROW_addrf', namespaces=nsmap)
        routes = [
            get_route(row_prefix)
            for af in afs
            for row_prefix in af.xpath('.//aos:ROW_prefix', namespaces=nsmap)
            # TODO(mahi): need to support ipv4 once ipv6 dumps are available
            if get_value(af, nsmap, 'addrf') == 'ipv4'
        ]
        routes = [r for r in routes if r is not None]
        return json.dumps({
            'items': routes
        })

    def collect(self):
        data = self.device.get_text('show ip route | xml')
        self.post_data(self._process_routes(data))


def collector_plugin(_device):
    return RouteCollector
