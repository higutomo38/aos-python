# Copyright 2019-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

import json
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector


class BgpCollector(BaseTelemetryCollector):

    def parse_bgp(self, data):
        vrfs = data['TABLE_vrf']['ROW_vrf']

        def _get_neighbors(vrf):
            return vrf['TABLE_af'][
                'ROW_af'][0]['TABLE_saf'][
                    'ROW_saf'][0][
                        'TABLE_neighbor'][
                            'ROW_neighbor']

        return json.dumps({
            'items': [
                {
                    'source_ip': vrf['vrf-router-id'],
                    'source_asn': vrf['vrf-local-as'],
                    'dest_ip': neighbor['neighborid'],
                    'dest_asn': neighbor['neighboras'],
                    'vrf_name': vrf['vrf-name-out'],
                    'addr_family': 'ipv4' if neighbor['neighborversion'] == '4'
                                   else 'ipv6',
                    'fsm_state': neighbor['state'].lower(),
                    'value': 'up' if neighbor['state'] == 'Established' else 'down'
                }
                for vrf in vrfs
                for neighbor in _get_neighbors(vrf)
            ]
        })

    def collect(self):
        # TODO: IPv6 and EVPN BGP sessions once the data is available.
        data = self.device.get_json('show bgp ipv4 unicast summary vrf all')
        self.post_data(self.parse_bgp(data))


def collector_plugin(_device):
    return BgpCollector
