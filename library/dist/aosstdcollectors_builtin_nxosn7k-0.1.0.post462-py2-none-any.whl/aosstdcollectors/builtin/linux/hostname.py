# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

import json
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector


class HostnameCollector(BaseTelemetryCollector):
    def collect(self):
        self.post_data(json.dumps({
            'items': [{
                'domain': '',  # reporting fqdn under hostname to match builtin ones
                'hostname': self.device.get_text('hostname -f')
            }]
        }))


def collector_plugin(_device):
    return HostnameCollector
