# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

import json
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.nxos_util import MANAGEMENT_VRF_NAME


class HostnameCollector(BaseTelemetryCollector):
    def _get_domain(self, data):
        # TODO(chiahui): AOS-9964 need to figure out how domain is used in AOS
        vrfs = data.get('TABLE_vrf', {}).get('ROW_vrf', [])
        if not isinstance(vrfs, list):
            vrfs = [vrfs]

        for vrf in vrfs:
            if vrf.get('vrfname') == MANAGEMENT_VRF_NAME:
                return vrf.get('defaultdomains', '')
        return ''

    def collect(self):
        hostname = self.device.get_json('show hostname')
        domain = self._get_domain(
            self.device.get_json('show hosts'))

        self.post_data(json.dumps(
            {
                'items': [
                    {
                        'hostname': hostname.get('hostname', ''),
                        'domain': domain,
                    }
                ]
            }))


def collector_plugin(_device):
    return HostnameCollector
