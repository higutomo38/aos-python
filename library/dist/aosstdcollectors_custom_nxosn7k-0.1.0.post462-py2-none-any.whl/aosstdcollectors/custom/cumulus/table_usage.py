# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

import json
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.cumulus_vrf_util import read_vrfs
from aosstdcollectors.utils.textparsing import TextFsmParser
from collections import defaultdict

template = r''' #TextFSM
Value TOTAL_COUNT (\d+)

Start
  ^show ip route vrf.*summary -> TotalRoutes

TotalRoutes
  ^Totals\s+${TOTAL_COUNT}\s+\d+ -> Start
'''

NET_IP_ROUTE_parser = TextFsmParser(template)


class TableUsageCollector(BaseTelemetryCollector):
    """
    iproute, arp entry, counts for cumulus
    """
    def __get_mcast_table(self, vrfs):
        """
            For Cumulus, PIM is not enabled in Hitachi case and no example
            output is found in Cumulus's documents. Set all mroutes
            related data to -1 if multicast mode is enabled otherwise return
            nothing. Consider this function as mock by now.

            In the future when mroute are needed when seeing -1 data,
            using the following command
            to get the mroutes information
            > sudo net show mroute vrf <vrf> count|json
        """
        results = defaultdict(lambda: dict(
            num_mcast_routes=-1,
            num_mcast_sources=-1,
            num_mcast_groups=-1
        ))

        return [
            {
                'identity': '%s|%s' % (vrf, metric),
                'value': str(results[vrf][metric])
            }
            for vrf, vrf_field in vrfs.iteritems()
            if vrf_field['multicast_mode'] == 'enabled'
            for metric in results[vrf]
        ]

    def get_arp_entries(self, vrfs):
        results = defaultdict(lambda: dict(num_arp_entries=0))

        for vrf in vrfs:
            ip_command = 'ip -4 neighbor'
            if vrf != 'default':
                ip_command += ' show vrf {}'.format(vrf)

            total_entries = len(list(filter(
                None, self.device.get_text(ip_command).splitlines())))

            results[vrf]['num_arp_entries'] = total_entries
            results['total']['num_arp_entries'] += total_entries

        return [
            {
                'identity': '%s|num_arp_entries' % vrf,
                'value': str(results[vrf]['num_arp_entries'])
            }
            for vrf in results
        ]

    def get_ip_routes(self, vrfs):
        results = defaultdict(lambda: dict(num_ip_routes=0))

        for vrf in vrfs:
            net_route_output = self.device.get_text(
                'sudo net show route vrf ' + vrf + ' summary')

            ip_routes = int(NET_IP_ROUTE_parser.parse(net_route_output)[0][0])

            results[vrf]['num_ip_routes'] = ip_routes
            results['total']['num_ip_routes'] += ip_routes

        return [
            {
                'identity': '%s|num_ip_routes' % vrf,
                'value': str(results[vrf]['num_ip_routes'])
            }
            for vrf in results
        ]

    def create_breakdown(self, data, key):
        breakdown = defaultdict(dict)

        for e in data:
            vrf = e['identity'].split('|')[0]
            value = e['value']
            breakdown[vrf] = value

        return [
            {
                'identity': key,
                'value': json.dumps(breakdown, indent=2, sort_keys=True)
            }
        ]

    def create_mcast_breakdown(self, data):
        breakdown = defaultdict(dict)
        for e in data:
            key, metric = e['identity'].split('|')
            value = e['value']
            breakdown[metric][key] = value

        return [
            {
                'identity': 'mcast_data',
                'value': json.dumps(breakdown, indent=2, sort_keys=True)
            }
        ]

    def collect(self):
        vrfs = read_vrfs(self.device)
        mcast_data = self.__get_mcast_table(vrfs)
        arp_entries = self.get_arp_entries(vrfs.keys())
        ip_routes = self.get_ip_routes(vrfs.keys())
        arp_breakdown = self.create_breakdown(arp_entries, 'arp_entries')
        ip_route_breakdown = self.create_breakdown(ip_routes, 'ip_routes')
        mcast_breakdown = self.create_mcast_breakdown(mcast_data)

        self.post_data(json.dumps({
            'items':
                mcast_data + arp_entries + ip_routes +
                arp_breakdown + ip_route_breakdown + mcast_breakdown
        }))


def collector_plugin(_device):
    return TableUsageCollector
