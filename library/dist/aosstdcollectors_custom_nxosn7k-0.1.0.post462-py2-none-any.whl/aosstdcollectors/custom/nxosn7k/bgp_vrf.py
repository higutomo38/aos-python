# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula


import json

from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.compat.aos.sdk.system_agent.device import \
    get_running_aos_version
from aosstdcollectors.utils.data_util import format_generic_value
from aosstdcollectors.utils.nxosn7k_util import get_tree
from aosstdcollectors.utils.platform_independent import DEFAULT_VRF_NAME


class BgpVrfCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(BgpVrfCollector, self).__init__(*args, **kwargs)
        self.aos_version = get_running_aos_version()

    def process(self, vrfs, nsmap, my_asn):
        return {
            'items': [
                {
                    'identity': '%s_%s' % (v.find('./aos:vrf-name-out', nsmap).text,
                                           n.find('./aos:neighborid', nsmap).text),
                    'value': format_generic_value(self.aos_version, {
                        'vrf': v.find('./aos:vrf-name-out', nsmap).text,
                        'dest_ip': n.find('./aos:neighborid', nsmap).text,
                        'dest_asn': n.find('./aos:neighboras', nsmap).text,
                        'value': 'up' if n.find('./aos:state', nsmap).text ==
                                 'Established' else 'down',
                        'source_asn': v.find('./aos:vrf-local-as', nsmap).text
                    })
                }
                for v in vrfs
                for n in v.xpath('.//aos:ROW_neighbor', namespaces=nsmap)
            ],
            'global': json.dumps({
                'asn': int(my_asn) if my_asn else None
            })
        }

    def collect(self):
        data = self.device.get_text('show bgp ipv4 unicast summary vrf all | xml')
        tree, nsmap = get_tree(data)
        vrf_name_xpath = ('.//aos:ROW_vrf[./aos:vrf-name-out['
                          'contains(text(),"%s")]]' % DEFAULT_VRF_NAME)
        default_vrf = tree.xpath(vrf_name_xpath, namespaces=nsmap)
        my_asn = default_vrf[0].find('./aos:vrf-local-as', nsmap).text or None
        vrfs = tree.xpath('//aos:show/aos:bgp//aos:ROW_vrf', namespaces=nsmap)

        self.post_data(
            json.dumps(
                self.process(vrfs, nsmap, my_asn)
            )
        )


def collector_plugin(_device):
    return BgpVrfCollector
