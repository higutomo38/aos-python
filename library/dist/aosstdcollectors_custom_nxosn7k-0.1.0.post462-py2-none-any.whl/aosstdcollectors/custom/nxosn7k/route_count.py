# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula


import json
from aosstdcollectors.utils.nxosn7k_util import get_tree
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector


def _find_xpath(element, namespace_map, xpath):
    text = element.find(xpath, namespaces=namespace_map)
    if hasattr(text, 'text'):
        return text.text
    return None


# XPATH values for search
BASE = './aos:TABLE_addrf/aos:ROW_addrf/aos:TABLE_prefix/aos:ROW_prefix'
PREFIX = './aos:ipprefix'
COUNT = './aos:ucast-nhops'
VRF_NAME = './aos:vrf-name-out'
ALL_VRF = '//aos:ROW_vrf'


class RouteCountCollector(BaseTelemetryCollector):
    """
    Returns number of default routes for all networks contextualized by VRFs.
    """

    def parse_xml(self, xml):
        result = {}
        tree, ns = get_tree(xml)

        def process_row(row):
            networks = self.service_config.input.split(
                ',') if self.service_config.input else ['0.0.0.0/0']
            vrf = _find_xpath(row, ns, VRF_NAME)
            entries = row.findall(BASE, namespaces=ns)

            for entry in entries:
                prefix = _find_xpath(entry, ns, PREFIX)
                count = _find_xpath(entry, ns, COUNT)
                if prefix in networks:
                    result['{}|{}'.format(vrf, prefix)] = count

        matches = tree.xpath(ALL_VRF, namespaces=ns)
        for m in matches:
            process_row(m)

        return result

    def collect(self):
        self.post_data(json.dumps({
            'items': [
                {
                    'identity': key,
                    'value': value
                }
                for key, value in self.parse_xml(
                    self.device.get_text('show ip route vrf all | xml')
                ).iteritems()
            ]
        }))


def collector_plugin(_device):
    return RouteCountCollector
