# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

NXOS_INTERFACE_ABBRV = {
    'Po': 'port-channel',
    'Eth': "Ethernet"
}
PORT_TYPE_MAC_NUMBER = "3"
PORT_TYPE_MAC_STRING = "Mac Address"
MANAGEMENT_VRF_NAME = "management"
BGP_STATE_ESTABLISHED = "Established"
PATTERN_ANYCAST_GATEWAY = r"^interface|anycast-gateway"


def _neighbor_interface_name(neighbor):
    port_type = neighbor.get('port_type', 'None')
    if ((port_type == PORT_TYPE_MAC_NUMBER or
         port_type == PORT_TYPE_MAC_STRING)):
        return neighbor.get('port_desc', 'None')
    return neighbor.get('port_id', 'None')


def get_interface_fullname(interface):
    """ Take an abbreviated interface name and convert to full name.
        e.g. Eth1/1 => Ethernet1/1
    """
    for key in NXOS_INTERFACE_ABBRV:
        if interface and interface.startswith(key):
            return interface.replace(key, NXOS_INTERFACE_ABBRV[key])
    return interface


def build_lldp_neighbor(neighbor):
    return {
        'neighbor_system_id': neighbor.get('sys_name', 'None'),
        'neighbor_interface_name': _neighbor_interface_name(neighbor),
        'sys_description': neighbor.get('sys_desc', 'None'),
        'interface_name': get_interface_fullname(neighbor.get('l_port_id', 'None'))
    }


def build_bgp_neighbors(data, addr_family):
    def get_vrfs():
        vrfs = data.get('TABLE_vrf', {}).get('ROW_vrf', [])
        return vrfs if isinstance(vrfs, list) else [vrfs]

    def get_peers(vrf):
        try:
            neighbors = vrf["TABLE_af"]["ROW_af"]["TABLE_saf"]["ROW_saf"][
                "TABLE_neighbor"]["ROW_neighbor"]
        except KeyError:
            # No neighbors
            return []

        return neighbors if isinstance(neighbors, list) else [neighbors]

    return [
        {
            'source_ip': vrf.get('vrf-router-id'),
            'source_asn': vrf.get('vrf-local-as'),
            'dest_ip': peer.get('neighborid'),
            'dest_asn': peer.get('neighboras'),
            'vrf_name': vrf.get('vrf-name-out'),
            'addr_family': addr_family,
            'fsm_state': peer.get("state").lower(),
            'value': 'up' if peer.get("state") == BGP_STATE_ESTABLISHED else 'down'
        }
        for vrf in get_vrfs()
        for peer in get_peers(vrf)
    ]


def listify(items):
    return items if isinstance(items, list) else [items]
