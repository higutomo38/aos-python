# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula


# This file parses CLI text output of the Cumulus command: net show vrf

# VRF              Table
# ---------------- -----
# mgmt              1001

from aosstdcollectors.utils.textparsing import TextFsmParser
from collections import namedtuple

template = r''' #TextFSM
Value Filldown VRF ([\w+-]+)
Value Filldown TABLE ([\d+-]+)

Start
  ^.*----- -> VRFs

VRFs
  ^\s*${VRF}\s+${TABLE} -> Record

EOF
'''

VRF_parser = TextFsmParser(template)
VRFcols = namedtuple('VRFcols', VRF_parser.headers)


# TODO: Output provided by command 'sudo net show vrf' doesn't contain enough
# information, so this file might be considered as mock by now.
def process(collected):
    vrf_data = dict()
    for header in VRF_parser.parse(collected):
        row = VRFcols(*header)
        vrf_data[row.VRF] = {
            'rd': '',
            # TODO: multicast_mode should be populated.
            'multicast_mode': 'disabled',
            'role': 'management' if row.VRF == 'mgmt' else 'data',
            # TODO: interfaces should be populated, but for 'mgmt' vrf at least
            # 'eth0' can always be added according to cumulus documentation
            # https://docs.cumulusnetworks.com/display/DOCS/Quick+Start+Guide
            # "Switches supported in Cumulus Linux always contain at least one
            # dedicated Ethernet management port, which is named eth0"
            'interfaces': ['eth0'] if row.VRF == 'mgmt' else list()
        }

    vrf_data['default'] = {
        'role': 'data',
        'multicast_mode': 'disabled',
        'rd': '',
        'interfaces': list()
    }

    return vrf_data


def read_vrfs(device):
    return process(device.get_text('sudo net show vrf'))
