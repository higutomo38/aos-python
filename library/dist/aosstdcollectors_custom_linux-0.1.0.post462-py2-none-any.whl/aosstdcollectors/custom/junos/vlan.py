# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula
import re

from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.compat.aos.sdk.system_agent.device import \
    get_running_aos_version
from aosstdcollectors.utils.data_util import to_extensible_postdata


class VlanCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(VlanCollector, self).__init__(*args, **kwargs)
        self._spec = None
        self.aos_version = get_running_aos_version()

    @property
    def spec(self):
        if self._spec:
            return self._spec

        # With xpath set to "l2ng-l2rtb-vlan-member/l2ng-l2rtb-vlan-member-interface"
        # vlan.interfaces would be set to "l2ng-l2rtb-vlan-member-interface" string
        # for XML below:
        #   <l2ng-l2rtb-vlan-member>
        #       <l2ng-l2rtb-vlan-member-interface/>
        #   </l2ng-l2rtb-vlan-member>
        # Thus xpath needs to be more complex to take care of cases when
        # `vlan-member-interface` node has no value.
        interface_xpath = (
            "l2ng-l2rtb-vlan-member/"
            "l2ng-l2rtb-vlan-member-interface"
            "[string-length(text()) > 0]"
        )
        self._spec = self.device.load_table_view_spec(
            {
                "VlanTable": {
                    "rpc": "get-vlan-information",
                    "item": "l2ng-l2ald-vlan-instance-group",
                    "view": "VlanView",
                },
                "VlanView": {
                    "fields": {
                        "tag": "l2ng-l2rtb-vlan-tag",
                        "name": "l2ng-l2rtb-vlan-name",
                        "interfaces": interface_xpath,
                    }
                },
            }
        )

        return self._spec

    def collect(self):
        def remove_logical_device(iface):
            # Remove logical portion of interface to match interface_details
            # collector. Only done for logical devices with ".0" to keep full
            # interface names for irb.7, for example.
            return re.sub(r"\.0$", "", iface)

        def remove_asterisk(iface):
            # An asterisk (*) beside the interface indicates that the interface
            # is UP. Ignore it.
            # https://www.juniper.net/documentation/en_US/junos/topics/
            # reference/command-summary/show-vlans-bridging-ex-series.html
            return iface.rstrip("*")

        def vlan_interfaces(_vlan):
            if isinstance(_vlan.interfaces, list):
                return _vlan.interfaces
            if isinstance(_vlan.interfaces, basestring):
                return [_vlan.interfaces]
            return []

        def interfaces(_vlan):
            return [
                remove_logical_device(remove_asterisk(iface))
                for iface in vlan_interfaces(_vlan)
            ]

        items = {
            vlan.tag: {
                "vlan_id": int(vlan.tag),
                "name": vlan.name,
                "interfaces": interfaces(vlan),
            }
            for vlan in self.device.create_table(self.spec["VlanTable"]).get()
        }

        self.post_data(to_extensible_postdata(items, aos_version=self.aos_version))


def collector_plugin(_):
    return VlanCollector
