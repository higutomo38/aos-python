# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.data_util import to_extensible_postdata
from aosstdcollectors.utils.textparsing import TextFsmParser

# traceroute to 8.8.8.8 (8.8.8.8), 64 hops max, 52 byte packets
#  1  12.250.179.10 (12.250.179.10)  1.914 ms  1.792 ms  3.676 ms
#  2  12.250.179.9 (12.250.179.9)  2.124 ms  1.860 ms  3.175 ms
#  3  cr81.sj2ca.ip.att.net (12.122.110.62)  8.750 ms  6.656 ms  9.230 ms
#  4  sffca21crs.ip.att.net (12.122.1.117)  8.516 ms  4.068 ms  3.822 ms
#  5  12.122.137.213 (12.122.137.213)  4.307 ms  3.581 ms  4.410 ms
#  6  206.121.188.42 (206.121.188.42)  5.033 ms
#     206.121.188.66 (206.121.188.66)  4.856 ms
#     206.121.188.42 (206.121.188.42)  5.017 ms
#  7  108.170.242.225 (108.170.242.225)  6.039 ms
#     108.170.242.241 (108.170.242.241)  7.746 ms
#     108.170.242.225 (108.170.242.225)  5.578 ms
#  8  108.170.232.65 (108.170.232.65)  5.445 ms
#     108.170.232.81 (108.170.232.81)  5.780 ms
#     108.170.232.83 (108.170.232.83)  5.874 ms
#  9  google-public-dns-a.google.com (8.8.8.8)  6.966 ms  5.300 ms  5.792 ms


trace_route_template = r''' #TextFSM
Value Hop (\d+)

Start
  ^.*traceroute -> TABLE

TABLE
  ^\s*${Hop}\s+ -> Record

EOF
'''

trace_route_parser = TextFsmParser(trace_route_template)


def parse_text(collected_trace_route):

    # prefix = ip.replace('.', '_')
    def key(k):
        # We don't want to add target-ip to key as different servers maybe configured
        # to ping a different IP and having different keys makes it not ingestable
        # into probes. In future, when we allow multiple target ips, one idea is to
        # add ip qualified keys for each ip but one set of keys without any IP with
        # a summary of information..
        return k

    parsed_data = {}
    if collected_trace_route:
        trace_route_data = trace_route_parser.parse(collected_trace_route)
        parsed_data[key('hop_count')] = len(trace_route_data)
    return parsed_data


class TraceRouteCollector(BaseTelemetryCollector):
    def collect(self):
        def safe_exec(cmd):
            try:
                return self.device.get_text(cmd)
            except RuntimeError:
                return None

        ip = self.service_config.input or '8.8.8.8'
        self.post_data(
            to_extensible_postdata(
                parse_text(
                    # traceroute may fail if it's not available on the box
                    safe_exec('traceroute -n %s' % ip)))
        )


def collector_plugin(_device):
    return TraceRouteCollector
