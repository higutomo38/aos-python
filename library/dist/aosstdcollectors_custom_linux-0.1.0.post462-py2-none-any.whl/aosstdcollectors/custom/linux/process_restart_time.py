# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

import json
import logging
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector

LOG = logging.getLogger(__name__)
SERVICE_NOT_RUNNING = '-1'
MULTIPLE_INSTANCE_OF_SERVICE_RUNNING = '-2'


class SecondsSinceProcessRestart(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(SecondsSinceProcessRestart, self).__init__(*args, **kwargs)
        self.json_input = self.normalize_input(self.service_config.input)

    def get_seconds_since_last_restart(self, service_name):
        try:
            pid = self.device.get_text('pidof {}'.format(service_name))
        except RuntimeError:
            return SERVICE_NOT_RUNNING
        pid_count = len(pid.split())
        if pid_count != 1:
            LOG.error("More than one instance of service %s running."
                      " PIDs are %s", service_name, pid)
            return MULTIPLE_INSTANCE_OF_SERVICE_RUNNING
        output = self.device.get_text(
            'ps -p {} -o etimes | grep -v ELAPSED'.format(pid))
        if not output:
            return SERVICE_NOT_RUNNING
        return output.strip()

    def normalize_input(self, service_input):
        if service_input:
            expected_format = '{"services":["switchd"]}'
            try:
                json_input = json.loads(service_input)
            except ValueError as error:
                raise ValueError("Failed to load service input. {0}\n"
                                 "Expected service input format is {1}"
                                 .format(error, expected_format))
            if not isinstance(json_input['services'], list):
                raise ValueError('Services must be a list %s' % json_input)
        return json_input

    def collect(self):
        collected = {'items': []}
        services = self.json_input['services']
        for service in services:
            key = "seconds_since_last_{}_restart".format(service)
            seconds = self.get_seconds_since_last_restart(service)
            collected['items'].append({"identity": key, "value": seconds})
        self.post_data(collected)


def collector_plugin(_device):
    """
    Collects information about all VLANs on a box
    """
    return SecondsSinceProcessRestart
