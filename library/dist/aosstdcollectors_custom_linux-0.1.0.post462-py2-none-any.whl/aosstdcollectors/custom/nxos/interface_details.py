# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

import re
import netaddr
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.utils.data_util import to_extensible_postdata
from aosstdcollectors.utils.nxos_util import get_interface_fullname, \
    PATTERN_ANYCAST_GATEWAY
from aosstdcollectors.utils.cisco_util import convert_mac_address
from aosstdcollectors.compat.aos.sdk.system_agent.device import \
    get_running_aos_version


class InterfaceDetailsCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(InterfaceDetailsCollector, self).__init__(*args, **kwargs)
        self.aos_version = get_running_aos_version()

    def _get_primary_ip(self, interface):
        if interface.get('eth_ip_addr'):
            addr = interface.get('eth_ip_addr')
            mask = interface.get('eth_ip_mask')
        elif interface.get('svi_ip_addr'):
            addr = interface.get('svi_ip_addr')
            mask = interface.get('svi_ip_mask')
        else:
            return None

        return str(netaddr.IPNetwork(
            '/'.join((addr, str(mask))) if mask else addr
        ))

    def _get_speed(self, interface):
        return int(interface.get('eth_bw')) if 'eth_bw' in interface else (
            int(interface.get('svi_bw', 0)))

    def _get_vlan_id(self, interface):
        try:
            return int(interface.get('interface').lstrip('Vlan'))
        except ValueError:
            pass
        return None

    def _get_allowed_vlans(self, interface_switchport_data, active_vlans):
        # Return access vlan for access port
        if interface_switchport_data.get('oper_mode', 'access') == 'access':
            return [int(interface_switchport_data.get('access_vlan')) or int(
                interface_switchport_data.get('native_vlan'))]

        # Return allowed, active vlans for trunk port
        allowed_vlans = []
        ranges = interface_switchport_data.get('trunk_vlans').split(',')
        for vlan_range in ranges:
            range_split = vlan_range.split('-')
            allowed_vlans.extend(
                range(int(range_split[0]), int(range_split[-1]) + 1)
            )
        return list(set(allowed_vlans) & set(active_vlans))

    def _get_type(self, interface_detail, interface_switchport_data):
        if interface_detail.get('name', '').startswith('mgmt'):
            interface_type = 'management'
        elif interface_detail.get('subinterface_id'):
            interface_type = 'subinterface'
        elif interface_detail.get('vlan_id') or \
                interface_detail.get('name', '').startswith('nve'):
            interface_type = 'svi'
        elif interface_detail.get('name', '').startswith('loopback'):
            interface_type = 'loopback'
        elif interface_detail.get('name', '').startswith('port-channel'):
            interface_type = 'port_channel'
        elif interface_detail.get('name', '').startswith('Ethernet'):
            interface_type = 'ethernet' if interface_switchport_data else 'ip'
        return interface_type

    def _get_mlag_id(self, interface):
        status = interface.get('vpc_status')
        if not status:
            return None
        match = re.search(r'vPC Status: \w+, vPC number: (\d+)', status)
        return int(match.group(1)) if match else None

    def _parse_interfaces(self, data):
        interfaces = data.get('TABLE_interface', {}).get('ROW_interface', [])
        if not isinstance(interfaces, list):
            interfaces = [interfaces]

        return {
            entry.get('interface'): {
                'name': entry.get('interface'),
                'ipv4_addr': self._get_primary_ip(entry),
                'description': entry.get('desc'),
                'speed_mbps': self._get_speed(entry)/1000,
                'vlan_id': self._get_vlan_id(entry),
                'mlag_id': self._get_mlag_id(entry),
                'parent': get_interface_fullname(entry.get('eth_bundle')) or (
                    entry.get('parent_interface')),
                'subinterface_id': entry.get('interface').split('.')[-1] if (
                    entry.get('parent_interface')) else None
            }
            for entry in interfaces
        }

    def _parse_switchports(self, data, active_vlans):
        if not isinstance(data, dict):
            # get_json returns empty string when no switchport configuration
            return {}

        interfaces = data.get('TABLE_interface', {}).get('ROW_interface', [])
        if not isinstance(interfaces, list):
            interfaces = [interfaces]

        return {
            entry.get('interface'): {
                'mode': entry.get('oper_mode', 'access'),
                'native_vlan': int(
                    entry.get('access_vlan') if entry.get('oper_mode') == 'access'
                    else entry.get('native_vlan')
                ),
                'allowed_vlans': self._get_allowed_vlans(entry, active_vlans)
            }
            for entry in interfaces
        }

    def _parse_vrrp(self, data):
        if not isinstance(data, dict):
            # get_json returns empty string when vrrp enabled but has no data
            return {}

        vrrp_groups = data.get('TABLE_vrrp_group', {}).get('ROW_vrrp_group', [])
        if not isinstance(vrrp_groups, list):
            vrrp_groups = [vrrp_groups]

        return {
            vrrp.get('sh_if_index'): {
                'virtual_ips': [x for x in [vrrp.get('sh_vip_addr')] if x],
                'virtual_macs': [
                    convert_mac_address(x) for x in [vrrp.get('sh_vmac')] if x
                ]
            }
            for vrrp in vrrp_groups
        }

    def _parse_anycast_gateway(self, text):
        """
        Anycast gateway interfaces info are only available via 'show run'.
        Extract anycast gateway relevant config by piping show run to egrep.

        ==== Sample text ====

        fabric forwarding anycast-gateway-mac 001c.7300.0001
        interface Vlan1
        interface Vlan10
          fabric forwarding mode anycast-gateway
        interface Vlan12
          fabric forwarding mode anycast-gateway

        ==== End of sample text ===="""

        mac_pattern = r"^fabric forwarding anycast-gateway-mac ([\w.:\-]+)\n"
        interface_pattern = \
            r"interface ([\w\-/]+)\n  fabric forwarding mode anycast-gateway"

        macs = [
            convert_mac_address(x) for x in re.findall(mac_pattern, text) or []
        ]
        return {
            interface: {
                'virtual_macs': macs
            }
            for interface in re.findall(interface_pattern, text) or []
        }

    def _parse_and_get_active_vlans(self, data):
        vlans = data.get('TABLE_vlanbriefxbrief', {}).get('ROW_vlanbriefxbrief', [])
        if not isinstance(vlans, list):
            vlans = [vlans]

        return [
            int(vlan.get('vlanshowbr-vlanid'))
            for vlan in vlans
            if vlan.get('vlanshowbr-vlanstate') == 'active'
        ]

    def _merge_interface_details(self, detail, switchport, vrrp, gw_macs):
        def _network_addr(vrrp_addr, interface_addr):
            addr = netaddr.IPNetwork(vrrp_addr)
            addr.prefixlen = netaddr.IPNetwork(interface_addr).prefixlen
            return str(addr)

        if vrrp:
            # We don't have a netmask for the virtual_ip but it should
            # match the mask of the interfaces ip.
            vrrp['virtual_ips'] = [
                _network_addr(addr, detail['ipv4_addr'])
                for addr in vrrp['virtual_ips']]

        detail['type'] = self._get_type(detail, switchport)
        detail.update(
            switchport or dict(mode='access', native_vlan=None, allowed_vlans=[]))
        detail.update(vrrp or dict(virtual_ips=[], virtual_macs=[]))
        if gw_macs:
            detail['virtual_macs'].extend(gw_macs.get('virtual_macs', []))

        return detail

    def _safe_get_json(self, cmd):
        try:
            output = self.device.get_json(cmd)
        except RuntimeError:
            return None
        return output

    def collect(self):
        interfaces = self._parse_interfaces(self.device.get_json('show interface'))
        active_vlans = self._parse_and_get_active_vlans(
            self.device.get_json('show vlan brief')
        )

        switchports = self._parse_switchports(
            self.device.get_json('show interface switchport'), active_vlans)
        anycast_gateway = self._parse_anycast_gateway(
            self.device.get_text('show run | egrep ' + PATTERN_ANYCAST_GATEWAY))
        vrrp = self._parse_vrrp(self._safe_get_json('show vrrp detail'))

        self.post_data(to_extensible_postdata(
            {
                interface: self._merge_interface_details(
                    details,
                    switchports.get(interface),
                    vrrp.get(interface),
                    anycast_gateway.get(interface)
                )
                for interface, details in interfaces.iteritems()
            }, aos_version=self.aos_version
        ))


def collector_plugin(_device):
    return InterfaceDetailsCollector
