# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

import json
import datetime
import math
import logging
from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from collections import defaultdict
from aosstdcollectors.utils.data_util import format_generic_value


logging.basicConfig(level=logging.DEBUG)


class AclStatsCollector(BaseTelemetryCollector):

    def __init__(self, *args, **kwargs):
        super(AclStatsCollector, self).__init__(*args, **kwargs)
        self.acl_prev = defaultdict(int)
        self.prev_timestamp = None

    def process(self, info, acl_name):
        acl_delta = defaultdict(int)
        timestamp = datetime.datetime.now()

        acl = [i for i in info['aclList'] if i['name'] == acl_name][0]
        for rule in acl['sequence']:
            rule_key = '{}|{}'.format(acl_name, rule['text'])
            if 'packetCount' not in rule['counterData']:
                acl_delta[rule_key] = -1
                self.acl_prev[rule_key] = -1
                continue

            packet_count = rule['counterData']['packetCount']

            if self.prev_timestamp:
                delta_seconds = (timestamp - self.prev_timestamp).total_seconds()

                # if previous value > current value, reset to 0
                # this can happen when counters are reset

                prev_count = self.acl_prev[rule_key]\
                    if self.acl_prev[rule_key] <= packet_count else 0
                packet_delta = packet_count - prev_count

                acl_delta[rule_key] = int(math.ceil(packet_delta / delta_seconds))

            else:

                acl_delta[rule_key] = 0
            self.acl_prev[rule_key] = packet_count

            # special key for last rule
            if rule == acl['sequence'][-1]:
                last_key = '{}|last_rule'.format(acl_name)
                acl_delta[last_key] = acl_delta[rule_key]

        return acl_delta

    def collect(self):
        if not self.service_config.input:
            raise ValueError('Missing ACL name(s) in service configuration input')

        timestamp = datetime.datetime.now()

        in_acl_names = self.service_config.input

        acl_names = [i.strip() for i in in_acl_names.split(',')]

        post_data = {
            'items': [
                {
                    'identity': str(key),
                    'value': str(value),
                }
                for acl_name in acl_names
                for key, value in self.process(
                    self.device.get_json(
                        'show ip access-list %s' % acl_name), acl_name
                    ).iteritems()
                ]
            }

        if not self.prev_timestamp:
            # do not post the data from the first collection
            # self.acl_prev has been set by the call
            # to self.process() above
            self.prev_timestamp = timestamp
            return

        self.post_data(format_generic_value(
            self.aos_version,
            json.dumps(post_data))
                      )

        self.prev_timestamp = timestamp


def collector_plugin(device):
    return AclStatsCollector
