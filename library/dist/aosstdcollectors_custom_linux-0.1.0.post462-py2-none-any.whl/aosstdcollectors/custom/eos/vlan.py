# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula
import json
import logging

from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.compat.aos.sdk.system_agent.device import \
    get_running_aos_version
from aosstdcollectors.utils.data_util import format_generic_value
from pyeapi.eapilib import CommandError

LOGGER = logging.getLogger('vlan')


class VlanCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(VlanCollector, self).__init__(*args, **kwargs)
        self.aos_version = get_running_aos_version()

    def process_show_vlans(self, collected, vxlan_intf):
        vlan_to_vni_map = {}
        if isinstance(vxlan_intf, dict):
            vlan_to_vni_map = vxlan_intf.get(
                'interfaces', {}).get('Vxlan1', {}).get('vlanToVniMap', {})

        return [
            {
                'identity': vlan_id,
                'value': format_generic_value(self.aos_version, {
                    'vlan_id': int(vlan_id),
                    'name': vlan_data['name'],
                    'interfaces': [iface for iface in vlan_data.get('interfaces', {})
                                   if iface != 'Cpu'],
                    'vni': vlan_to_vni_map.get(vlan_id, {}).get('vni', None)
                })
            } for vlan_id, vlan_data in collected.iteritems()
        ]

    def collect(self):
        show_vlans = self.device.get_json('show vlan')['vlans']
        vxlan_intf = None
        try:
            vxlan_intf = self.device.get_json('show interfaces vxlan 1')
        except CommandError:
            LOGGER.warn("VXLAN is not setup on device.")
        self.post_data(json.dumps({
            'items': self.process_show_vlans(show_vlans, vxlan_intf)
        }))


def collector_plugin(_device):
    """
    Collects information about all VLANs on a box
    """

    return VlanCollector
