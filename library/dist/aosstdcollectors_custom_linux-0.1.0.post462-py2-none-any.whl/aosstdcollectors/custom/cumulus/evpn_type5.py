# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula


from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
import re
import logging
from aosstdcollectors.utils.data_util import to_extensible_postdata, \
    format_generic_value
from aosstdcollectors.compat.aos.sdk.system_agent.device import \
    get_running_aos_version


LOG = logging.getLogger(__name__)


class EVPNType5Collector(BaseTelemetryCollector):

    def __init__(self, *args, **kwargs):
        super(EVPNType5Collector, self).__init__(*args, **kwargs)
        self.aos_version = get_running_aos_version()

    def collect(self):

        data = self.device.get_json(
            'vtysh -c "show bgp l2vpn evpn route type prefix json"')
        pattern = re.compile(
            r'\[5\]:\[0\]:\[0\]:\[(?P<prefix_len>\d+)\]:\[(?P<subnet>.+)\]')

        def get_subnet(prefix):
            match = re.match(pattern, prefix)
            if not match:
                return None
            return '%s/%s' % (match.group('subnet'), match.group('prefix_len'))
        vteps = {}

        for rd, rd_data in data.iteritems():
            # Top level keys in command output include the RD: {dict}, and some
            # unused keys numPrefix and numPaths.
            if not isinstance(rd_data, dict) or not rd_data.get('rd'):
                continue
            for prefix, prefix_item in rd_data.iteritems():
                # k,v is not structured very well from FRR, so be defensive
                # and only check if a prefix entry exists.
                if not isinstance(prefix_item, dict) or \
                        not prefix_item.get('prefix'):
                    continue

                # Not an EVPN route
                if 'prefixLen' not in prefix_item:
                    continue

                subnet = get_subnet(prefix)
                if not subnet:
                    continue

                # There is a bug with prefix len on FRR where the response for a v6
                # entry is always 224, so we cannot rely on prefixlen to tell us
                # what version this route is.

                # "[5]:[0]:[0]:[128]:[fc01:a05:fab::10]":{
                #    "prefix": "[5]:[0]:[0]:[128]:[fc01:a05:fab::10]",
                #    "prefixLen": 224,

                # So instead, just check if a colon is in the string, this is the
                # least expensive computationally to check version. netaddr may be
                # more accurate, but is also slower, and we anticiapte processing
                #                 # thousands upon thousands of routes.

                # When (or if ever,) it is fixed, use this instead.
                # if int(prefix_item['prefixLen']) == 224:
                #     ip_version = 'ipv4'
                # elif int(prefix_item['prefixLen']) == 416:
                #     ip_version = 'ipv6'
                # else:
                #     continue

                if ':' in subnet:
                    ip_version = 'ipv6'
                else:
                    ip_version = 'ipv4'

                identity = '%s|%s|%s' % (rd, ip_version, subnet)
                # Leave this here for future use.
                # value = {
                #     'rd': rd,
                #     'vtep': get_prefix(prefix),
                #     'next_hops': list(set([
                #         entry.get('peerId')
                #         for path in prefix_item.get('paths', [])
                #         for entry in path
                #     ])),
                # }
                value = "1"
                vteps[identity] = format_generic_value(self.aos_version, value)

        self.post_data(to_extensible_postdata(vteps, aos_version=self.aos_version))


def collector_plugin(_device):
    return EVPNType5Collector

# EOF
