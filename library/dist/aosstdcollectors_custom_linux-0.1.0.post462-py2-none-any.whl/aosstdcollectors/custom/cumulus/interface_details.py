# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
from aosstdcollectors.compat.aos.sdk.system_agent.device import \
    get_running_aos_version
from aosstdcollectors.utils.data_util import format_generic_value
from aosstdcollectors.utils.platform_independent import valid_ipv4_addr
import re
import json

SPEED_PATTERN_G = re.compile('G')
SPEED_PATTERN_M = re.compile('M')
DOT = re.compile(r'\.')


def get_allowed_vlans(if_name, parent, vlans):
    return [
        int(vlan)
        for vlan, vlan_data in vlans.iteritems()
        for interface in vlan_data
        if interface['interface'] == if_name or interface['interface'] == parent
    ]


# pylint: disable=inconsistent-return-statements
def get_type(mode, if_name):
    if mode.startswith('Mgmt'):
        return 'management'
    if mode.startswith('Loopback'):
        return 'loopback'
    if mode.startswith('Interface') or mode in ['NotConfigured', 'VRF', 'Default']:
        return 'ip'
    if mode.startswith('Trunk') or mode.startswith('Bridge') or \
            mode.startswith('BondMember') or mode.startswith('Access/L2'):
        return 'ethernet'
    if mode.startswith('SVI') or mode.startswith('SubInt') or \
            if_name.startswith('vlan'):
        return 'svi'
    if mode.startswith('LACP') or mode.startswith('802.3ad'):
        return 'port_channel'
    assert False, "Unexpected interface type (mode): '{}'".format(mode)


def get_addr(entries):
    if not entries:
        return None

    if len(entries) == 1:
        return str(entries[0])

    default_addr = '127.0.0.1/8'
    found_default = False
    final_addr = None
    for addr in entries:
        if addr == default_addr:
            found_default = True
            continue

        if valid_ipv4_addr(addr):
            final_addr = addr
            break

    if final_addr:
        return final_addr

    if found_default:
        return default_addr

    return None


def get_speed(speed):
    # TODO: output from 'net show interface json' command says that speed on devices
    # is 1G but in blueprint it's shown 10000 (10G), because of that discrepancy
    # blueprint can't be built. Thus, setting default value.
    match_gigabits = SPEED_PATTERN_G.search(speed)
    match_megabits = SPEED_PATTERN_M.search(speed)

    if match_gigabits:
        return 1000 * int(speed[:match_gigabits.start()])
    elif match_megabits:
        return int(speed[:match_megabits.start()])
    return None


def get_vlan_id(if_name):
    # according to Cumulus documentations there are 2 ways to configure vlans:
    # 1. through NCLU, e.g.
    #   'net add bridge bridge ports swp1-2'
    #   'net add vlan 10 ip address 10.100.100.1/24'
    # 2. by manually editing /etc/network/interfaces file with bridge.VLAN-ID naming
    # https://docs.cumulusnetworks.com/display/DOCS/Ethernet+Bridging+-+VLANs
    match = DOT.search(if_name)
    if match:
        return int(if_name[match.end():])
    if if_name.startswith('vlan'):
        return int(if_name.lstrip('vlan'))
    return None


def get_parent(if_name, if_data, ifaces):
    if get_type(if_data['mode'], if_name) == 'svi':
        return None

    if if_data['mode'].startswith('SubInt'):
        parent = if_name.split('.')[0]
        if parent in ifaces:
            return parent

    if if_data['mode'].startswith('BondMember'):
        for parent_name, parent_data in ifaces.iteritems():
            if if_name in parent_data['iface_obj']['members']:
                return parent_name
    return None


def get_subinterface_id(if_name, if_data, parent):
    if parent and if_data['mode'].startswith('SubInt'):
        return if_name[len(parent) + 1:]
    return None


def get_virtual_ips(if_name, collected):
    virtual_ips = []
    if if_name.startswith('bridge.'):
        vlan_id = if_name.lstrip('bridge.')
        for sub_if_name, if_data in collected.iteritems():
            if sub_if_name.startswith('bridge-' + vlan_id):
                virtual_ips = if_data['iface_obj']['ip_address'].get('allentries')
    return virtual_ips


def get_virtual_macs(if_name, collected):
    virtual_macs = []
    if if_name.startswith('bridge.'):
        vlan_id = if_name.lstrip('bridge.')
        for sub_if_name, if_data in collected.iteritems():
            if sub_if_name.startswith('bridge-' + vlan_id):
                virtual_macs.append(if_data['iface_obj']['mac'])
    return virtual_macs


def get_mlag_id(if_name, mlag):
    if not mlag:
        return None
    return mlag['clagIntfs'].get(if_name, {}).get('clagId', None)


class InterfaceDetailsCollector(BaseTelemetryCollector):
    def __init__(self, *args, **kwargs):
        super(InterfaceDetailsCollector, self).__init__(*args, **kwargs)
        self.aos_version = get_running_aos_version()

    def process(self, collected, mlag, vlans):
        def build(if_name, if_data):
            parent = get_parent(if_name, if_data, collected)
            return {
                'name': if_name,
                'allowed_vlans': sorted(get_allowed_vlans(if_name, parent, vlans)),
                'description': if_data['iface_obj'].get('description', ''),
                'speed_mbps': get_speed(if_data['speed']),
                'ipv4_addr': get_addr(if_data['iface_obj']
                                      ['ip_address']['allentries']),
                'type': get_type(if_data['mode'], if_name),
                'parent': parent,
                'native_vlan': if_data['iface_obj']['native_vlan'],
                'mlag_id': get_mlag_id(if_name, mlag),
                'subinterface_id': get_subinterface_id(if_name, if_data, parent),
                'mode': 'trunk',  # TODO: how to get this field?
                'virtual_ips': sorted(get_virtual_ips(if_name, collected)),
                'virtual_macs': sorted(get_virtual_macs(if_name, collected)),
                'vlan_id': get_vlan_id(if_name)
            }

        return {
            'items': [
                {
                    'identity': if_name,
                    'value': format_generic_value(self.aos_version,
                                                  build(if_name, if_data))
                }
                for if_name, if_data in collected.iteritems()
                if not if_name.startswith('bridge-')
                # TODO: bridge-X-vX seems to
                # contain data about virtual mac and ip for bridge.X. Should skip it?
            ]
        }

    def collect(self):
        mlag = self.device.get_text('sudo net show clag json')
        if mlag:
            mlag = json.loads(mlag)
        collected = self.device.get_json('sudo net show interface json')
        vlans = self.device.get_json('netshow vlan json')['vlans']
        self.post_data(json.dumps(self.process(collected, mlag, vlans)))


def collector_plugin(_device):
    return InterfaceDetailsCollector
