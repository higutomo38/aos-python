# Copyright 2020-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

from aos.sdk.system_agent.base_telemetry_collector import BaseTelemetryCollector
import logging

LOGGER = logging.getLogger(__name__)


class SdwanPolicyRuleCollector(BaseTelemetryCollector):
    def collect(self):
        self.post_data([
            {
                'key': {
                    'device_id': appl_summary['name'],
                    'rule_name': stat_brief['name'],
                    'metric': metric,
                },
                'value': stat_brief.get(metric, 1),
            }
            for appl_summary in self.device.client.appliance_summaries.list()
            if appl_summary['org'] == self.device.org_uuid
            for stat_brief in self.device.client.list_sdwan_policy_rule_brief_stats(
                appl_summary, self.device.org_name)
            for metric in ['hit-count', 'exists']
        ])


def collector_plugin(device):
    return SdwanPolicyRuleCollector
