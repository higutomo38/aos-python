# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

import logging
import re
from lxml import etree

LOGGER = logging.getLogger(__name__)


class CiscoXML(object):
    def __init__(self, device, command):
        self.data = None
        self.tree = None
        self.nsmap = None

        self.data = device.get_text(command)
        self.__sanitize_xml()

    def __sanitize_xml(self):
        # Cisco sets the XML encoding to ISO-8859-1
        # If we don't decode and re-encode as utf-8 we get the following error:
        # ValueError: Unicode strings with encoding declaration are not
        # supported. Please use bytes input or XML fragments without
        # declaration.
        # pylint: disable=c-extension-no-member
        self.tree = etree.fromstring(self.data.decode('ISO-8859-1').encode('utf-8'))

        # Give a name to the default namespace, otherwise we will get
        # TypeError: empty namespace prefix is not supported in XPath
        self.nsmap = self.tree.nsmap.copy()
        self.nsmap['aos'] = self.nsmap.pop(None)


def get_mgmt_info(device, facts):
    mgmt_xml = CiscoXML(device, 'show interface mgmt0 | xml')
    facts['mgmt_ifname'] = 'mgmt0'

    got = mgmt_xml.tree.xpath('//aos:show/aos:interface//aos:eth_hw_addr',
                              namespaces=mgmt_xml.nsmap)
    assert got, locals()

    if got and got[0].text is not None:
        facts['mgmt_macaddr'] = got[0].text
    else:
        LOGGER.warn('cannot fetch mac address - may be a loopback intf')


def get_hardware_info(device, facts):
    hw_xml = CiscoXML(device, 'show hardware | xml')
    got = hw_xml.tree.xpath('.//aos:ROW_slot_info[./aos:type[contains(text(), \
                            "Chassis")]]', namespaces=hw_xml.nsmap)
    assert got, locals()

    facts['hw_model'] = got[0].find('./aos:model_num', hw_xml.nsmap).text or \
        'TITANIUM'

    facts['hw_version'] = got[0].find('./aos:hw_ver', hw_xml.nsmap).text

    facts['serial_number'] = got[0].find('./aos:serial_num', hw_xml.nsmap).text or \
        facts['mgmt_macaddr'].replace('.', '').upper()
    facts['chassis_mac_ranges'] = ''


def get_version(device, facts):
    version_xml = CiscoXML(device, 'show version | xml')
    got = version_xml.tree.xpath('//aos:show/aos:version//aos:rr_ver_str',
                                 namespaces=version_xml.nsmap)

    if got:
        assert len(got) == 1, locals
        version = got[0].text
    else:
        # may be a virtual device
        got = version_xml.tree.xpath('//aos:show/aos:version//aos:sys_ver_str',
                                     namespaces=version_xml.nsmap)
        if got:
            assert len(got) == 1, locals
            version = got[0].text

    assert version, locals()
    version_pattern = re.compile(r'(\d+)\.(\d+)\((\d+\w?)\)')
    m = version_pattern.match(version)
    assert m, locals()

    facts['os_version'] = version
    facts['os_version_info'] = {
        'major': m.group(1),
        'minor': m.group(2),
        'build': m.group(3)
    }

    return facts


def nxosn7k_gather_facts(device, facts):
    try:
        get_version(device, facts)
        get_mgmt_info(device, facts)
        get_hardware_info(device, facts)
    except Exception:  # pylint: disable=broad-except
        LOGGER.exception('device_info exception')
        device.close()
    return facts
