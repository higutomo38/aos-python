# Copyright 2020-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

# pylint: disable=invalid-name

import base64
import logging
from collections import namedtuple
import http_test_client
from http_test_client import (
    api, Api, RestResources, RestResource, ClientError, resources
)
from aos.sdk.client import HttpTransport
from aos.sdk.utils import wait_for
from aos.sdk.collection_utils import find

LOGGER = logging.getLogger(__name__)

MAX_TASK_POLL_RETRIES = 5

TaskStatus = namedtuple(
    'TaskStatus', ['status', 'response', 'percentage_completion'])


def split_base_and_param(_api):
    return _api._url.rsplit('/', 1)


class VersaDirectorClient(http_test_client.Client):
    def __init__(self, director_ip, port, username, password, org_name):
        self._auth_token = base64.b64encode('{}:{}'.format(username, password))
        self._transport = HttpTransport(
            'https://{}:{}'.format(director_ip, port), verify_certificates=False)
        self.org_name = org_name
        super(VersaDirectorClient, self).__init__(self._transport)
        self.logger.setLevel(logging.DEBUG)

    def _get_task_status(self, task_id):
        # TODO(Mahi): Find API for querying task status by task_id
        response = self.request(
            '/vnms/tasks?deep=true&orderBy=id%20desc&offset=0&limit=1', method='GET')
        task = response['versanms.tasks']['versanms.task'][0]
        percentage_completion = task['versa-tasks.percentage-completion']
        LOGGER.info(
            'Task %s, Completion: %s', task['versa-tasks.id'], percentage_completion)

        if percentage_completion != 100:
            return TaskStatus('inprogress', response, percentage_completion)

        LOGGER.info('Task %s: %s', task_id, task['versa-tasks.task-status'])

        return (
            TaskStatus('success', response, percentage_completion)
            if task['versa-tasks.task-status'] != 'FAILED' else
            TaskStatus('failed', response, percentage_completion))

    def _poll_task(self, task_id):
        class Nonlocal(object):
            task_status = None

        def task_completed():
            Nonlocal.task_status = self._get_task_status(task_id)
            return Nonlocal.task_status.status != 'inprogress'
        try:
            wait_for(task_completed, timeout=120)
        except AssertionError:
            raise ClientError(
                500, 'Task completion client-side timeout. Response: {}'.format(
                    Nonlocal.task_status.response if Nonlocal.task_status else None))

        return Nonlocal.task_status.response

    # pylint: disable=arguments-differ
    def raw_request(self, *args, **kwargs):
        headers = dict({
            'Authorization': 'Basic {}'.format(self._auth_token),
            'Accept': 'application/json',
            'Content-type': 'application/json'
        }, **kwargs.pop('headers', None) or {})
        return super(VersaDirectorClient, self).raw_request(
            *args, headers=headers, **kwargs)

    # pylint: disable=arguments-differ
    def request(self, *args, **kwargs):
        response = super(VersaDirectorClient, self).request(*args, **kwargs)
        # TODO(Mahi): The key seems to be based on the rest API. Need to explore
        # if there are other API that needs task handling and handle all of them
        # generically.
        if response and isinstance(response, dict) and response.get(
                'versanms.templateResponse', {}).get('taskId'):
            return self._poll_task(response['versanms.templateResponse']['taskId'])
        return response

    @api('/vnms/dashboard/vdStatus')
    class status(Api):
        def get(self, **kwargs):
            try:
                return self._request(method='GET', **kwargs)
            except ClientError as ce:
                if ce.status_code != 404:
                    raise ce
            return None

    @api('/vnms/organization/orgs')
    class orgs(RestResources):
        def list(self, **kwargs):
            return self._request(**kwargs)['organizations']

        def get_org_by_name(self, org_name):
            return find(lambda o: o['name'] == org_name, self.list())

    appliance_summaries = resources('/vnms/appliance/summary')

    def list_sdwan_policy_rule_brief_stats(self, appl_summary, org_name):
        # this request returns no content if there is no data to display
        response = self.request(
            url=(
                '/vnms/dashboard/appliance/{}/live?uuid={}&command=orgs/org-services'
                '/{}/sd-wan/policies/sdwan-policy-group/Default-Policy/rules'
                '/statistics/brief/stats-brief'
            ).format(appl_summary['name'], appl_summary['uuid'], org_name)
        ) or {}
        return response.get('collection', {}).get('sdwan:stats-brief', [])

    @api('/nextgen/applicationServiceTemplate')
    class service_workflow_templates(RestResources):

        @api('/{template_name}')
        class Resource(RestResource):

            def deploy(self, **kwargs):
                # The REST url for get, update and delete service template is
                # GET, UPDATE, DELETE /nextgen/applicationServiceTemplate
                # /<template_name> and these API's are exposed as
                # client.service_workflow_template['template_name'].get()
                # client.service_workflow_template['template_name'].update()
                # client.service_workflow_template['template_name'].delete()
                # However the url for deploy is
                # POST /nextgen/applicationServiceTemplate/deploy/<template_name>.
                # and to expose this API similar to GET, UPDATE and DELETE as
                # client.service_workflow_template['template_name'].deploy()
                # map the user defined URL
                # /nextgen/applicationServiceTemplate/<template_name> to
                # actual url /nextgen/applicationServiceTemplate/deploy/
                # <template_name>
                base, param = split_base_and_param(self)
                url = base + '/deploy/' + param
                return self._client.request(url, method='POST', **kwargs)

    @api('/api/config/devices/device')
    class devices(RestResources):

        @api('/{device_name}')
        class Resource(RestResource):

            @api('/config/system/sd-wan/site')
            class site(Api):
                def get(self, **kwargs):
                    return self._request(method='GET', **kwargs)['site']

    @api('/vnms/cloud/systems/getAllApplianceNames')
    class appliances(Api):
        def list(self, **kwargs):
            return self._request(method='GET', **kwargs)['appliance-list']

        @api('/{appliance_name}')
        class Resource(Api):
            def get(self, **kwargs):
                return self._request(method='GET', **kwargs)['appliance']

    @api('/nextgen/deviceGroup')
    class device_groups(RestResources):
        def list(self, **kwargs):
            url = self._url + '?organization=' + self._client.org_name
            return self._client.request(
                url, method='GET', **kwargs).get('device-group', {})

        @api('/{device_group}')
        class Resource(RestResource):
            def put(self, data, **kwargs):
                return self._client.request(
                    self._url, method='PUT', data=data, **kwargs)

            @api('/template')
            class template(RestResources):

                @api('/{template_name}')
                class Resource(RestResource):
                    def get(self, **kwargs):
                        return self._request(method='GET', **kwargs)

    @api('/vnms/sdwan/workflow/templates')
    class workflow_templates(RestResources):

        @api('/template')
        class template(RestResources):

            @api('/{template_name}')
            class Resource(RestResource):
                def get(self, **kwargs):
                    return self._request(
                        method='GET', **kwargs)['versanms.sdwan-template-workflow']

    @api('/nextgen/template')
    class device_templates(RestResources):

        @api('/{template_name}')
        class Resource(RestResource):

            def apply(self, data, **kwargs):
                # Expose apply device template as
                # client.device_template['template_name'].apply()
                # The url - '/vnms/template/applyTemplate/{}/devices'
                # for apply device template is different from device
                # template REST API - /nextgen/template/template_name.
                # Hence map apply device template user defined url to
                # actual url '/vnms/template/applyTemplate/{}/devices'
                _, param = split_base_and_param(self)
                url = '/vnms/template/applyTemplate/{}/devices'.format(param)
                return self._client.request(
                    url, method='POST', data=data, **kwargs)

            @api('/associations')
            class associations(RestResources):

                @api('/{association_id}')
                class Resource(RestResource):

                    def delete(self, **kwargs):
                        # expose DELETE /nextgen/template/{}/associations/?id={}'
                        # as client.device_template['device_template'].association
                        # ['association_id'].delete()
                        base, param = split_base_and_param(self)
                        url = base + '/?id=' + param
                        return self._client.request(url, method='DELETE', **kwargs)

    def close(self):
        if self._transport:
            self._transport._session.close()
            self._transport = None
