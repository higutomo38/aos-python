# Copyright 2020-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://www.apstra.com/eula

from aos.sdk import schema as s
from aos.sdk.system_agent.device import Device
from aos.sdk.types import ValidationError
from aosdevicedrivers.utils.datautils import dictmixin_to_dict
from versa_director_client import VersaDirectorClient


VERSA_DIRECTORY_DEFAULT_PORT = 9182
OPEN_OPTIONS_SCHEMA = s.Object({
    'org_name': s.String(validate=[s.Length(min=1)]),
    'port': s.Optional(s.Integer(validate=[s.Range(min=0)]),
                       load_default=VERSA_DIRECTORY_DEFAULT_PORT)})


class VersaDirectorDevice(Device):
    def __init__(self, *args, **kwargs):
        super(VersaDirectorDevice, self).__init__(*args, **kwargs)
        assert not self.onbox, 'Only offbox is supported for Versa Director'

        if self.open_options is None:
            raise ValidationError('org_name: Value is required')

        self.vd_open_options = OPEN_OPTIONS_SCHEMA.load(
            dictmixin_to_dict(self.open_options))

        self.client = None
        self._org_uuid = None

    def open(self):
        self.client = VersaDirectorClient(
            self.ip_address, self.vd_open_options['port'],
            self.username, self.password, self.org_name)

    @property
    def org_name(self):
        return self.vd_open_options['org_name']

    @property
    def org_uuid(self):
        if not self._org_uuid:
            # pylint: disable=no-value-for-parameter
            self._org_uuid = self.client.orgs.get_org_by_name(self.org_name)['uuid']

        return self._org_uuid

    def get_device_info(self):
        def sanitize_serial_number(serial_number):
            return serial_number.replace('.', '-')

        # pylint: disable=no-value-for-parameter
        vd_status = self.client.status.get()

        return {
            "serial_number": sanitize_serial_number(
                vd_status['versanms.VDStatus']['pkgInfo']['name']),
            "vendor": "Versa Networks",
            "hardware_model": "Versa Director",
            "os_family": "versa_director",
            "os_version": (
                vd_status['versanms.VDStatus']['pkgInfo']['version']),
            "mgmt_ipaddr": self.ip_address
        }

    def close(self):
        if self.client:
            self.client.close()
        self.client = None

    def probe(self):
        # pylint: disable=no-value-for-parameter
        self.client.status.get()
